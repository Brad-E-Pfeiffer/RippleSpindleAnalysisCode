%PURPOSE: Plot distribution of Ripple-Spindle offsets
%
%INPUT: 
% Spindle_Events
% Ripple_Data
% 
% OUTPUT: 
% 
%Authors/origin creds
% LD Quigley
%
% Volk & Pfeiffer Lab
%========================================================================== 
WT_TimeLags1 = []
WT_SpindleTimelags1 = [];

WT_TimeLags2 = []
WT_SpindleTimeLags2 = [];

tic
D = dir('G:\Current_Kc_Analysis\WT');
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));
for k = 1:numel(D)
    currD = D(k).name;
    cd(currD)

    if exist('Spindle_Events_PreExp.mat','file')  
        %load SWR data for SWRs that occured during NREM periods
         load('SWS_Ripples_PreExp_Calc.mat','Ripple_Data_Cat')
         
        %load Spindle events
         load('Spindle_Events_PreExp.mat')
         load('Spindle_Events','Complete_Sigma_Data')
    Timelags1 = zeros(length(Ripple_Data_Cat),1);
    parfor i = 1:size(Ripple_Data_Cat,1)
        Ripple_Start=(Ripple_Data_Cat(i,1));
        Ripple_End=(Ripple_Data_Cat(i,2));
    %Sigma_During_Ripple = Complete_Sigma_Data(find(Complete_Sigma_Data(:,1)>Ripple_Start & Complete_Sigma_Data(:,1)<Ripple_End),6);
   %Peak_Spindle_Power_Ripple = [Peak_Spindle_Power_Ripple;max(Sigma_During_Ripple)];
   
   % Find the closest spindle start time to the ripple start time 
    [~,Timeidx] = min(abs(Spindle_Events(:,1)-Ripple_Start));
    RippleTimeLags1(i) = Ripple_Start-Spindle_Events(Timeidx);
    end
     WT_TimeLags1 = [WT_TimeLags1;RippleTimeLags1'];
   
    
   for i = 1:size(Spindle_Events,1)
    Spindle_Start=(Spindle_Events(i,1));
    Spindle_Times= find(Complete_Sigma_Data(:,1)>=Spindle_Events(i,1) & Complete_Sigma_Data(:,1)<=Spindle_Events(i,2));
    %[Spindle_Troughs,P] = islocalmin(Complete_Sigma_Data(Spindle_Times,2));
    %Min_Trough_Time = Complete_Sigma_Data(Spindle_Times(find(P==max(P))),1)
    [~,Timeidx] = min(abs(Ripple_Data_Cat(:,1)-Spindle_Start));
    SpindleTimelags1(i) = Spindle_Start-Ripple_Data_Cat(Timeidx,1);
   end 
    % Find the closest ripple start time to the spindle start time 
  WT_SpindleTimelags1 = [WT_SpindleTimelags1;SpindleTimelags1'];
    end
    clearvars -except WT* D WT*
    if exist('Spindle_Events_PostExp.mat')
         load('Spindle-Ripple-Lags.mat', 'RippleTimeLags2')
         WT_TimeLags2 = [WT_TimeLags2;RippleTimeLags2'];
        load('Spindle-Ripple-Lags.mat', 'SpindleTimeLags2')
        WT_SpindleTimeLags2 = [WT_SpindleTimeLags2;SpindleTimeLags2'];
    
     
    end

end
cd ..
end

%% Plotting Histograms for Spindle-ripple lag
   %%% Time Lags Ripple start to nearest spindle start Histogram %%%
   %... Thought wonder if I should do peak..
    h(1)=figure;
    Lags = abs(WT_TimeLags1);
    %bins = [[min(WT_TimeLags1)*0.5]:2:[max(WT_TimeLags1)]];
    %bins = [-50:1:50];
    %bins = [0:2:50];
    bins = [0:.5:50];
     hs = histogram(Lags, bins,'Normalization','probability','FaceColor','k');
    %hs = histogram(Lags, bins,'Normalization','probability','FaceColor',[.5 0 .5]);
    xlabel('Time Lags (s)')
    ylabel('Probabilty')
    xlim([0 50]);

    hold on
 
     Lags = abs(WT_TimeLags2);
    %bins = [[min(WT_TimeLags1)*0.5]:2:[max(WT_TimeLags1)]];
    %bins = [-50:1:50];
   % bins = [0:2:50];
     bins = [0:.5:50];
    hs = histogram(Lags, bins,'Normalization','probability','FaceColor','w');
    xlabel('Time Lags (s)')
    ylabel('Probabilty')
    xlim([0 50]);
   % ylim= get(gca,'YLim')
    %ylim= ylim(2)
    %legend({'SWS-Pre','SWS-Post'})Spindle-Ripple WT kstest 6.7111e-09

    ylima= get(gca,'YLim')
    ylima= ylima(2)
   % line([mean(WT_TimeLags1) mean(WT_TimeLags1)],[ylima 0],'color','b');
   % line([mean(WT_TimeLags2) mean(WT_TimeLags2)],[ylima 0],'color','r');
    
    %ylim([0 .3])
     title('Time Lag from Ripple to Nearest Spindle')
    savefig('WT_TimeLag_Ripple2Spindle')
    
 %STATS
   Lags1 = abs(WT_TimeLags1);
   Lags2 = abs(WT_TimeLags2);
   
   [p,h,stats] = ranksum(Lags1,Lags2)
   
   Lags1 = abs(WT_TimeLags1);
   Lags2 = abs(WT_TimeLags2);
   
   [p,h,stats] = ranksum(Lags1,Lags2)
    [corrected_p, h]=bonf_holm([0.1063 2.1585e-31])
    
%     %% Plotting for Spindles
%    %%% Time Lags Ripple start to nearest spindle start Histogram %%%
%    %... Thought wonder if I should do peak..
%     h(1)=figure;
%     Lags = abs(WT_SpindleTimelags1);
%     %bins = [[min(WT_TimeLags1)*0.5]:2:[max(WT_TimeLags1)]];
%     %bins = [-25:.5:25];
%     bins = [0:.5:25];
%     hs = histogram(Lags, bins,'Normalization','probability','FaceColor','b');
%     xlabel('Time Lags (s)')
%     ylabel('Probabilty')
%     %xlim([-15 15]);
%     xlim([0 15]);
% 
%     hold on
%  
%      Lags = abs(WT_SpindleTimeLags2);
%     %bins = [[min(WT_TimeLags1)*0.5]:2:[max(WT_TimeLags1)]];
%     %bins = [-25:.5:25];
%     bins = [0:.5:25];
%     hs = histogram(Lags, bins,'Normalization','probability','FaceColor',[0.3010 0.7450 0.9330]);
%     xlabel('Time Lags (s)')
%     ylabel('Probabilty')
%     %xlim([-15 15]);
%      xlim([0 15]);
%    % ylim= get(gca,'YLim')
%     %ylim= ylim(2)
%     %legend({'SWS-Pre','SWS-Post'})
%    % ylima= get(gca,'YLim')
%     %ylima= ylima(2)
%    % line([mean(WT_TimeLags1) mean(WT_TimeLags1)],[ylima 0],'color','b');
%    % line([mean(WT_TimeLags2) mean(WT_TimeLags2)],[ylima 0],'color',[0.3010 0.7450 0.9330]);
%     
%     ylim([0 .25])
%     
%     title('Time Lag from Spindle to Nearest Ripple')
%     %savefig('WT_TimeLag_Spindle2Ripple')
%     
%     
%  %% % Spindle Duration Histogram %%%
%  %Duration and amp of ripples inside a spindle or outside a spindle
%  % Then same for spindles without a ripple inside
%     %h(1)=figure;
%     Durations = WT6_Spindle_Ripple_Free(:,2)-WT6_Spindle_Ripple_Free(:,1);
%     bins = 0:0.25:10;
%     histogram(Durations, bins,'Normalization','probability');
%     xlabel('Duration (s)')
%     ylabel('Frequency (#)')
%     xlim([0 10]);
%     % ylim([0 35]);
%     %title(['SpindleDur_', savename],'Interpreter', 'none')
%    % med_SpDur = median(duration_State/fs);
%     %ave_SpDur = mean(duration_State/fs);
%     %saveas(h(1),['SpindleDur_', savename,'.fig'])
%     
%     %%% Spindle Amplitude Histogram (raw, based on transformed data) %%%
%     h(2)=figure;
%     bins = min(spiAmp_State)*0.5:min(spiAmp_State)*0.1:max(spiAmp_State*1.5);
%     hist(spiAmp_State,bins);
%     xlabel('Amplitude (AU)')
%     ylabel('Frequency (#)')
%     % xlim([min(spiAmp_State)*0.8 max(spiAmp_State)*1.2]);
%     % ylim([0 350]);
%     title(['SpindleAmp_', savename],'Interpreter', 'none')
%     med_spiAmp = median(spiAmp_State);
%     ave_spiAmp = mean(spiAmp_State);
%     saveas(h(2),['SpindleAmp_', savename,'.fig'])
%     
%     %%% Spindle Frequency Histogram %%%
%     %Freq =
%     h(3)=figure;
%     bins = 5:.5:20;
%     hist(spiHz_State,bins);
%     xlabel('Frequency (Hz)')
%     ylabel('Frequency (#)')
%     xlim([5 20]);
%     % ylim([0 350]);
%     title(['SpindleHz_', savename],'Interpreter', 'none')
%     med_spiHz = median(spiHz_State);
%     ave_spiHz = mean(spiHz_State);
%     saveas(h(3),['SpindleHz_', savename,'.fig'])
%     
%   nfig = 3
%   
