
function Multitaper_Spectrogram_Sleep(LFP)
params.fpass=[0 20];% frequency band range: 0 - 80 Hz 
movingwin=[2,.2]; % time bins: 1-second long windows with 0.1 second advancement
params.Fs=3200; % sampling frequency of your LFP data
params.trialave=1;params.tapers=[5 9];
%LFP= CSC5;
%start_time =sleep6(1,1); end_time=sleep6(1,2);
%lfp=LFP(LFP(:,1)>=start_time & LFP(:,1)<=end_time,: ); % LFP is the raw LFP data; here we select a specific period as lfp
lfp = LFP;
[S,SpecTime,SpecFreq] = mtspecgramc(lfp(:,2),movingwin,params); % here using multitaper method to calculate spectrogram for this certain period; only need to put in LFP power and the output time will always start from 0
% S is the spectrogram, is a 2D image where rows are time and columns are frequency;
% SpecTime: binned time vector, each value corresponds to each row;
% SpecFreq: binned frequency vector, each value corresponds to each column;
S=10*log10(S);
%S=zscore(S,0,1); % here we transform values of S into decibels and Z-score it across time.
%figure; imagesc([SpecTime(1) SpecTime(end)],[SpecFreq(1),SpecFreq(end)],S'); set(gca,'YDir','normal'); colormap jet
subplot(2,1,1)
imagesc([SpecTime(1) SpecTime(end)],[SpecFreq(1),SpecFreq(end)],S'); set(gca,'YDir','normal'); colormap jet
% Here we display the spectrogram 
end
