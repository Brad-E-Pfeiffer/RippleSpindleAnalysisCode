%% Plot Phase coherence data
% Load vector of mean phase offset during each SWR, for all detected SWRs
% of a genotype and plot

figure
polarhistogram(WT_Ripple_LowG_Coherence_Angle_Pre,36,'Normalization','Probability','FaceColor','k');
hold on
polarhistogram(KO_Ripple_LowG_Coherence_Angle_Pre,36,'Normalization','Probability','FaceColor',[0.4940, 0.1840, 0.5560]);
set(gca,'FontSize',14);
set(gca,'FontWeight','bold');

figure
polarhistogram(WT_Ripple_LowG_Coherence_Angle_Post,36,'Normalization','Probability','FaceColor','k');
hold on
polarhistogram(KO_Ripple_LowG_Coherence_Angle_Post,36,'Normalization','Probability','FaceColor',[0.4940, 0.1840, 0.5560]);
set(gca,'FontSize',14);
set(gca,'FontWeight','bold');
rlim([0 .08])


