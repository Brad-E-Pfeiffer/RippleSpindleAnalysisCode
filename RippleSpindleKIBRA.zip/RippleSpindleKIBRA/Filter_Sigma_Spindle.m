function Sigma_Filtered_LFP_Data=Filter_Sigma_Spindle(raw_Data,LFP_Frequency,lfpind)
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This program loads the LFP data saved by the LOAD_RAW_LFP_DATA function.
% It then filters this raw LFP trace in the Sigma band and saves that
% information for every electrode in the directory.
% 
% Sigma_Data
% 
% |   1  |        2       |        3       |   4   |    5
% | Time | Sigma-Filtered |     Cubed      | Sigma |  
% |      |      Trace     |      RMS       | Phase |  Sigma amplitude
% 
% Start_Time and End_Time are the timepoints (in seconds) that you want the
% function to analyze.  If these are left empty or are given the value
% 'start' and 'end', respectively, the function will load the entire
% experimental dataset from the file defined by Save_Label.
% 
% Load_Label is a string that is attached to the beginning of the filename
% for the previously saved LFP Data (the data to be loaded prior to
% analysis).  Save_Label is a string that is attached to the beginning of
% the filename for the current date prior to saving it.
% 
% Load_Directory is a string that defines the drive location of the raw
% Neuralynx.ncs files, such as 'G:\Experiments\_Data\Rat1'. Save_Directory
% is a string that defines the drive location where the user wants the
% MatLab files saved.  If these values arent entered, the load and save
% directory is assumed to be the current directory.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------


% If the user did not fully define the input variables, the most likely
% values are either searched for or automatically provided.

%%% Bandpass filter data from 10-15Hz %%%
%bpSpiFiltIIR = designfilt('bandpassiir','DesignMethod','butter','MatchExactly', 'stopband','StopbandFrequency1', 3, 'PassbandFrequency1', 10,...
  %  'PassbandFrequency2', 15, 'StopbandFrequency2', 22, 'StopbandAttenuation1', 24, 'PassbandRipple', 1, 'StopbandAttenuation2', 24, 'SampleRate', fs);
%BandFiltered_DataAll=filtfilt(bpSpiFiltIIR,DataAll); % Zero-phase delay
%RMS_DataAll = fastrms(BandFiltered_DataAll,fs*rmsWindow);
%Transformed_DataAll = RMS_DataAll'.^3;
%clear RMS_DataAll


% The following values are used to build the bandpass filter for Sigma detection
Sigma_Stop_Low=3;                
Sigma_Pass_Low=10;                % This low cutoff is based on validation paper
Sigma_Pass_High=15;              % This high cutoff is based on validation paper
Sigma_Stop_High=22;              
Stop_Band_Attenuation_One=24;    % Changed this value based on validation paper
Pass_Band=1;                     % Unsure about this, unspecified in paper
Stop_Band_Attenuation_Two=24;    % Changed this value based on validation paper
Filter_Design_For_Sigma=fdesign.bandpass(Sigma_Stop_Low, Sigma_Pass_Low, Sigma_Pass_High, Sigma_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Sigma_Filter=design(Filter_Design_For_Sigma,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

% This begins the actual Sigma filtering function
  Sigma_Filtered_LFP_Data=zeros(size(raw_Data,1),4);
    Sigma_Filtered_LFP_Data(:,1)=raw_Data(:,1);
    Sigma_Filtered_LFP_Data(:,2)=filter(Sigma_Filter,raw_Data(:,2));
    %a=Theta_Filtered_LFP_Data(:,2);
    Sigma_Filtered_LFP_Data(:,2)=Sigma_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
    Sigma_Filtered_LFP_Data(:,2)=filter(Sigma_Filter,Sigma_Filtered_LFP_Data(:,2));
    Sigma_Filtered_LFP_Data(:,2)=Sigma_Filtered_LFP_Data(end:-1:1,2);
    %b=Theta_Filtered_LFP_Data(:,2);
    for M=1:2000000:size(Sigma_Filtered_LFP_Data,1),  % The program crashes if much more than about 2000000 samples are transformed at once
        %Theta_Filtered_LFP_Data(:,3)=hilbert(Theta_Filtered_LFP_Data(:,2));
        Sigma_Filtered_LFP_Data(M:min([size(Sigma_Filtered_LFP_Data,1),M+2000000]),3)=hilbert(Sigma_Filtered_LFP_Data(M:min([size(Sigma_Filtered_LFP_Data,1),M+2000000]),2));
    end
    %Theta_Filtered_LFP_Data(:,4)=(angle(Theta_Filtered_LFP_Data(:,3))*180/pi)+180;% here using trough to segment theta cycles
    Sigma_Filtered_LFP_Data(:,4)=(angle(Sigma_Filtered_LFP_Data(:,3))*180/pi);
    Sigma_Filtered_LFP_Data(:,4)=(Sigma_Filtered_LFP_Data(:,4)<0)*360+Sigma_Filtered_LFP_Data(:,4);
    Sigma_Filtered_LFP_Data(:,5)=abs(Sigma_Filtered_LFP_Data(:,3));

    % This gives us the phase of the oscillation 
    %Sigma_Filtered_LFP_Data(:,4)=(angle(Sigma_Filtered_LFP_Data(:,3))*180/pi)+180;
    
    % This will give us the amplitude but moving due to RMS
   %Sigma_Filtered_LFP_Data(:,3)=abs(Sigma_Filtered_LFP_Data(:,3));
    % Now we want to compute RMS using a moving window of 750 ms-- can use
    % DSP toolbox mov_RMS create moving RMS object with specified window
    % length, here we want 750ms
    rmsWindow = .750;
     %Sigma_Filtered_LFP_Data(:,5) = Sigma_Filtered_LFP_Data(:,3);
     
    Sigma_Filtered_LFP_Data(:,3) = fastrms(Sigma_Filtered_LFP_Data(:,2),LFP_Frequency*rmsWindow);
    Sigma_Filtered_LFP_Data(:,3) = Sigma_Filtered_LFP_Data(:,3).^3;
    Sigma_Filtered_LFP_Data(:,3)   = sgolayfilt(Sigma_Filtered_LFP_Data(:,3), 4, 9);
    %Sigma_Filtered_LFP_Data(:,3) = filter(alpha, [1 alpha-1], Sigma_Filtered_LFP_Data(:,3));
    
    %movRMS = dsp.MovingRMS(2400);
    %Sigma_Filtered_LFP_Data(:,3) = movRMS(Sigma_Filtered_LFP_Data(:,3));
    %We will z-score the RMS data here in case we need it
    %Sigma_Filtered_LFP_Data(:,5)=zscore(Sigma_Filtered_LFP_Data(:,3));
    %Cube the RMS amplitude to reduce noise
    %Sigma_Filtered_LFP_Data(:,3) = Sigma_Filtered_LFP_Data(:,3).^3;
    % The following gaussian filter has a ? of 300 ms  (should we keep
    % this? -- removed but can plot signal with or without to see effect
    %Sigma_Gaussian_Filter=fspecial('gaussian',[round(3*(300/((1/LFP_Frequency)*1000))),1],round(300/((1/LFP_Frequency)*1000)));
    %Sigma_Filtered_LFP_Data(:,3)=filtfilt(Sigma_Gaussian_Filter,1,Sigma_Filtered_LFP_Data(:,3));
    clear Sigma_Gaussian_Filter;
    % The following z-scores the filtered trace but i am removing for the
    % time being as it is not critical for spindle detection can add it
    % back in later -- maybe here we will add as column 5
    %Sigma_Filtered_LFP_Data(:,3)=zscore(Sigma_Filtered_LFP_Data(:,3));
    if nargin<3
        lfpind=[];
    end
    %if isempty(lfpind)
        %Sigma_Filtered_LFP_Data(:,5)=zscore(Sigma_Filtered_LFP_Data(:,3));
   % else
       % Sigma_Filtered_LFP_Data(lfpind,5)=zscore(Sigma_Filtered_LFP_Data(lfpind,3));
    %end

end