    function Delta_Filtered_LFP_Data=deltafilt(raw_Data,LFP_Frequency,lfpind)
%    Delta_Data
% 
% |   1  |        2       |        3       |   4   |
% | Time | Delta-Filtered | Z-Scored Delta | Delta |
% |      |      Trace     |    Amplitude   | Phase |
   % The following values are used to build the bandpass filter for delta detection
Delta_Stop_Low=1;
Delta_Pass_Low=1.5;             % Most papers use between 1 and 5 Hz to identify delta oscillations
Delta_Pass_High=4;
Delta_Stop_High=5;
Stop_Band_Attenuation_One=60;    % This was the default, I think.  
Pass_Band=1;                     % This was the default, I think.
Stop_Band_Attenuation_Two=80;    % This was the default, I think.
Filter_Design_For_Delta=fdesign.bandpass(Delta_Stop_Low, Delta_Pass_Low, Delta_Pass_High, Delta_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Delta_Filter=design(Filter_Design_For_Delta,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

    Delta_Filtered_LFP_Data=zeros(size(raw_Data,1),4);
    Delta_Filtered_LFP_Data(:,1)=raw_Data(:,1);
    Delta_Filtered_LFP_Data(:,2)=filter(Delta_Filter,raw_Data(:,2));
    %a=Theta_Filtered_LFP_Data(:,2);
    Delta_Filtered_LFP_Data(:,2)=Delta_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
    Delta_Filtered_LFP_Data(:,2)=filter(Delta_Filter,Delta_Filtered_LFP_Data(:,2));
    Delta_Filtered_LFP_Data(:,2)=Delta_Filtered_LFP_Data(end:-1:1,2);
    %b=Theta_Filtered_LFP_Data(:,2);
    for M=1:2000000:size(Delta_Filtered_LFP_Data,1),  % The program crashes if much more than about 2000000 samples are transformed at once
        %Theta_Filtered_LFP_Data(:,3)=hilbert(Theta_Filtered_LFP_Data(:,2));
        Delta_Filtered_LFP_Data(M:min([size(Delta_Filtered_LFP_Data,1),M+2000000]),3)=hilbert(Delta_Filtered_LFP_Data(M:min([size(Delta_Filtered_LFP_Data,1),M+2000000]),2));
    end
    %Theta_Filtered_LFP_Data(:,4)=(angle(Theta_Filtered_LFP_Data(:,3))*180/pi)+180;% here using trough to segment theta cycles
    Delta_Filtered_LFP_Data(:,4)=(angle(Delta_Filtered_LFP_Data(:,3))*180/pi);
    Delta_Filtered_LFP_Data(:,4)=(Delta_Filtered_LFP_Data(:,4)<0)*360+Delta_Filtered_LFP_Data(:,4);
    Delta_Filtered_LFP_Data(:,3)=abs(Delta_Filtered_LFP_Data(:,3));

    % The following gaussian filter has a sigma of 1500 ms
    Delta_Gaussian_Filter=fspecial('gaussian',[round(3*(1500/((1/LFP_Frequency)*1000))),1],round(1500/((1/LFP_Frequency)*1000)));
    Delta_Filtered_LFP_Data(:,3)=filtfilt(Delta_Gaussian_Filter,1,Delta_Filtered_LFP_Data(:,3));
    Delta_Filtered_LFP_Data(:,5)=Delta_Filtered_LFP_Data(:,3);
    %clear Theta_Gaussian_Filter;
    % The following z-scores the filtered trace
    if nargin<3
        lfpind=[];
    end
    if isempty(lfpind)
        Delta_Filtered_LFP_Data(:,5)=zscore(Delta_Filtered_LFP_Data(:,3));
    else
        Delta_Filtered_LFP_Data(lfpind,5)=zscore(Delta_Filtered_LFP_Data(lfpind,3));
    end
    
 