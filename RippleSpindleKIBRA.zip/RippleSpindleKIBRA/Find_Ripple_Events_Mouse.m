function []=Find_Ripple_Events_Mouse(Electrode_ID,Velocity_Cutoff)
% %% FUNCTION:
%  This program calculates the z-scored slow-gamma power during all SWRs 
%  To do this, for each ripple,it finds the z-scored slow-gamma power for each SWR on the electrode of
% interest.
% This assumes LFP data has been filtered in low gamma range
% If velocity cutoff>0, animal position data is required containing 
% recording times and x-y positions in cm.
%
% This function identifies peaks in the ripple power (as putative
% reactivation events).  It finds the mean power of the selected
% tetrode and any time the power is greater than the mean plus the
% standard deviation times the Minimum_Peak_Height_Multiplier, the event is
% considered to be a candidate ripple event.
% 
% The program looks for ripples using a range of
% Minimum_Peak_Height_Multipliers.
% 
% Electrode_ID is the number of the CSC channel that you want to analyze.
% For example, entering 12 would analyze Ripple_CSC12.mat.  
% 
% Velocity_Cutoff is the maximum speed of the rat (in cm/s) for analysis of
% ripple events.  If the rat is moving faster than this value, the ripple
% data for those times are excluded from analysis.  If you don't want to
% use a velocity cutoff (or just haven't finished processing the video data
% yet, enter a value of 0.  If Velocity_Cutoff is greater than 0, the
% program will look for a file called Position_Data in the same folder
% which would contain the rat's X- and Y- position across time.
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% INPUT: 
%  Electrode_ID = ID of hippocampal electrode of interest
%  Velocity_Cutoff = velocity cutoff to limit analysis 

% OUTPUT: Ripple_Events.mat
%  
%
% LDQ 2022
% Volk Lab & Pfeiffer Lab

%==========================================================================
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 

% First, I define several values that can be changed if necessary

if ~exist('Velocity_Cutoff','var')
    Velocity_Cutoff=0;
end
Minimum_Peak_Height_Multiplier=3;
Maximum_Ripple_Time_Length=2;       %The maximum time (in seconds) that a ripple can last for and still be considered a real ripple
Minimum_Ripple_Time_Length=0.04;    %The minimum time (in seconds) that a ripple must last for to be counted as a real ripple
%Minimum_Peak_Separation=0.04;       %The minimum time (in seconds) that two ripples have to be apart to be counted as separate ripples -- otherwise they are concatenated as one ripple
Minimum_Inter_Ripple_Interval=0.025;  %The minimum time (in seconds) that two ripples have to be apart to be counted as separate ripples -- otherwise they are concatenated as one ripple

Load_Label=sprintf('Ripple_CSC%d',Electrode_ID);

% This loads the ripple-filtered data.
load(Load_Label);
eval(sprintf('Complete_Ripple_Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));


% Next will remove timepoints with saturated signal from the filtered data

LFP1_Name=sprintf('CSC%d.ncs',Electrode_ID);
LFP1_Frequency=Nlx2MatCSC(LFP1_Name,[0 0 1 0 0],0,3,1);
LFP_Frequency=LFP1_Frequency;
clear LFP1_Frequency;

LFP1_Samples=Nlx2MatCSC(LFP1_Name,[0 0 0 0 1],0,1);
LFP1_Samples=LFP1_Samples(:);
%LFP_Samples=LFP_Samples(:)*(Max_Range/Max_Value);

%If the recording frequency and total sample number are the same, the program assumes the timepoint of each sample is the same, so it only loads the timestamps of the first electrode and uses that for both 
LFP_Times=Nlx2MatCSC(LFP1_Name,[1 0 0 0 0],0,1)/1000000;
Times=zeros(512,size(LFP_Times,2));
for B=1:length(LFP_Times)-1
    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';   
end
 clear B;   
Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
LFP_Times=Times(:);
clear Times;

LFP1_Header=Nlx2MatCSC(LFP1_Name,[0 0 0 0 0],1,1,0);
for Header_Line=1:length(LFP1_Header)
    Header_Info=cell2mat(LFP1_Header(Header_Line));
    if length(Header_Info)>12
        if strcmp(Header_Info(1:11),'-ADMaxValue')
            LFP1_Max_Value=str2num(Header_Info(13:end));
        end
        if strcmp(Header_Info(1:11),'-InputRange')
            LFP1_Max_Range=str2num(Header_Info(13:end));
        end
    end
end

%This identifies segments of the recording where either the signal or the reference electrode is clipped (above or below the maximum recording value) 
%These segments aren't removed yet because it would interfere with the filtering to append two distant segments, so these are removed after filtering 
Timepoints_To_Remove=LFP_Times(LFP1_Samples==LFP1_Max_Value | LFP1_Samples==(-LFP1_Max_Value)); %| LFP2_Samples==LFP2_Max_Value | LFP2_Samples==(-LFP2_Max_Value));
Timepoints_To_Remove=[Timepoints_To_Remove-1,Timepoints_To_Remove+1];
Timepoints_To_Remove(:,3)=1;
for N=1:(size(Timepoints_To_Remove,1)-1)
    if Timepoints_To_Remove((N+1),1)<=Timepoints_To_Remove(N,2)
        Timepoints_To_Remove(N,3)=0;
        Timepoints_To_Remove((N+1),1)=Timepoints_To_Remove(N,1);
    end
end
Timepoints_To_Remove=Timepoints_To_Remove(Timepoints_To_Remove(:,3)==1,1:2);

for N=1:size(Timepoints_To_Remove,1)
    Complete_Ripple_Data=Complete_Ripple_Data(Complete_Ripple_Data(:,1)<Timepoints_To_Remove(N,1) | Complete_Ripple_Data(:,1)>Timepoints_To_Remove(N,2),:);      
end

%This loads the Times variable that lists the various experimental time epochs
load TimesSession

%This section was added to calculate the mean ripple amplitude  for all
%Epochs, when the mouse was moving less than Velocity_Cutoff
% This applies the velocity cutoff so that only ripple data when the rat is moving below a certain threshold is analyzed.
    if Velocity_Cutoff>0
        LFP_Velocity=[];
        load('Processed_Position_Data_Smoothed','Position_Data')
        Velocity=CALCULATE_VELOCITY(Position_Data);Velocity=Velocity(:);
        %Added 6/8/2020
        Velocity = smoothdata(Velocity);
        template=Complete_Ripple_Data(:,1);ruler=Position_Data(:,1);[outputindex,error]=match(template,ruler,0);
        LFP_Velocity(:,1:2)=[Velocity(outputindex),abs(error)];
        if 0,
            for N=1:size(Complete_Ripple_Data,1)
                LFP_Velocity(N,1)=Velocity(find(abs(Position_Data(:,1)-Complete_Ripple_Data(N,1))==min(abs(Position_Data(:,1)-Complete_Ripple_Data(N,1))),1,'first'));
            end
        end
        Ripple_Data=Complete_Ripple_Data( (LFP_Velocity(:,1)<=Velocity_Cutoff & LFP_Velocity(:,2)<0.5),:);
    else
        Ripple_Data=Complete_Ripple_Data;
    end
    

% Find mean and standard deviation of ripple amplitude during baseline period  
        %Ripple_Data = [Ripple_Data((Ripple_Data(:,1)>=Times(1,1) & Ripple_Data(:,1)<=Times(1,2)),:); Ripple_Data((Ripple_Data(:,1)>=Times(6,1) & Ripple_Data(:,1)<=Times(6,2)),:)];
        Ripple_Data = Ripple_Data((Ripple_Data(:,1)>=Times(1,1) & Ripple_Data(:,1)<=Times(1,2)),:);

        Mean_Ripple_Amplitude = mean(Ripple_Data(:,5)); % 
        STD_Ripple_Amplitude=std(Ripple_Data(:,5));
        
        Complete_Ripple_Data(:,6) = (Complete_Ripple_Data(:,5)-Mean_Ripple_Amplitude)/(STD_Ripple_Amplitude);
        %Ripple_Data(:,6) = (Ripple_Data(:,5)-Mean_Ripple_Amplitude)/(STD_Ripple_Amplitude);
       
        %find column 6 when times in Complete Ripple data match
        %
        %Mean_Ripple_Amplitude = mean(Ripple_Data(:,6)); % 
        %STD_Ripple_Amplitude=std(Ripple_Data(:,6));
        
        
         clear Ripple_Data;
        clear LFP_Velocity;
        clear template;
for Epoch=1:size(Times,1)    
    %This restricts the analyis to the current epoch only
    Ripple_Data=Complete_Ripple_Data((Complete_Ripple_Data(:,1)>=Times(Epoch,1) & Complete_Ripple_Data(:,1)<=Times(Epoch,2)),:);
    %This restricts analysis to times when the mouse is not moving
    %<Velocity_Cutoff
    if Velocity_Cutoff>0
        LFP_Velocity=[];
        %load Processed_Position_Data_Smoothed
        %Velocity=CALCULATE_VELOCITY(Position_Data);Velocity=Velocity(:);
        template=Ripple_Data(:,1);ruler=Position_Data(:,1);[outputindex,error]=match(template,ruler,0);
        LFP_Velocity(:,1:2)=[Velocity(outputindex),abs(error)];
        if 0,
            for N=1:size(Ripple_Data,1)
                LFP_Velocity(N,1)=Velocity(find(abs(Position_Data(:,1)-Ripple_Data(N,1))==min(abs(Position_Data(:,1)-Ripple_Data(N,1))),1,'first'));
            end
        end
        Ripple_Data=Ripple_Data( (LFP_Velocity(:,1)<=Velocity_Cutoff & LFP_Velocity(:,2)<0.5),:);
    end
    
    % This next section finds all of the peaks in the ripple amplitude data.
    %
    % Ripple_Events
    % |     1      |    2     |         3        |
    % | Start Time | End Time | Center Peak Time |
    %
    %
    % Ripple_Power
    % |        1            |          2             |       3          |
    % | Mean Z Ripple Power | Maximum Z Ripple Power |  Raw_Mean_Amp     |
    % |        4            |          5             |       6           |
    % | Raw_Max_Amp         | Raw_Mean_Env_Power     |  Raw_Max_Env_Power|
       % |        7            |          8             |       9           |
    % | Raw_Max_Amp         | Raw_Mean_Env_Power     |  Raw_Max_Env_Power|
    
    % First, it finds the mean and standard deviation of the ripple amplitude.
    
    % Next, it finds peaks in the ripple amplitude greater than a threshold of
    % the mean plus X times the standard deviation (X ranges from 2 to 7 in
    % this analysis.  It defines the start and stop of each event as when the
    % amplitude crosses back below the mean.  Once it's found all of the
    % events, it combines events in which the peaks are less than X sec from
    % one another (X is defined at the start of this function as the
    % "Minimum_Peak_Distance").
 for Minimum_Peak_Height_Multiplier=2:7
        if max(Ripple_Data(:,5))>=Mean_Ripple_Amplitude+(STD_Ripple_Amplitude*Minimum_Peak_Height_Multiplier) %& max(Ripple_Data(:,3))<=Mean_Ripple_Amplitude+(STD_Ripple_Amplitude*Maximum_Peak_Height_Multiplier),
            [~,Locations]=findpeaks(Ripple_Data(:,5),'minpeakheight',Mean_Ripple_Amplitude+(STD_Ripple_Amplitude*Minimum_Peak_Height_Multiplier));
        else
            Locations=find(Ripple_Data(:,5)==max(Ripple_Data(:,5)),1,'first');
        end
        
        % This finds the start and end timepoints for each event.
        Ripple_Events=zeros(length(Locations),3);
        Ripple_Events(:,3)=Ripple_Data(Locations,1);
        for N=1:size(Ripple_Events,1)
            L=Locations(N);
            while Ripple_Data(L,5)>Mean_Ripple_Amplitude+(.75*STD_Ripple_Amplitude) && L>1 %this finds the closest timepoint prior to the current peak that crosses the mean 
                                                                                         % 
                L=L-1;
            end
            Ripple_Events(N,1)=Ripple_Data(L,1);
            L=Locations(N);
            while Ripple_Data(L,5)>Mean_Ripple_Amplitude+(.75*STD_Ripple_Amplitude) && L<size(Ripple_Data,1) %this finds the closest timepoint after the current peak that crosses the mean
                L=L+1;
            end
            Ripple_Events(N,2)=Ripple_Data(L,1);
        end
        
        for N=2:size(Ripple_Events,1)
            if Ripple_Events(N,1)-Ripple_Events(N-1,2)<=Minimum_Inter_Ripple_Interval
                Ripple_Events(N,1)=Ripple_Events(N-1,1);
                Ripple_Events(N-1,1)=0;
            end
        end
        Ripple_Events=Ripple_Events((Ripple_Events(:,1)>0),:);
        Ripple_Events=Ripple_Events(((Ripple_Events(:,2)-Ripple_Events(:,1))>=Minimum_Ripple_Time_Length & (Ripple_Events(:,2)-Ripple_Events(:,1))<=Maximum_Ripple_Time_Length),:);
        
% This finds the mean power for each ripple event
        if size(Ripple_Events,1)>0
            %Ripple_Power=zeros(size(Ripple_Events,1),2);
            Ripple_Power=zeros(size(Ripple_Events,1),8);
            for N=1:size(Ripple_Events,1)
                %Ripple_Subset_Data=Ripple_Data(find(Ripple_Data(:,1)>=Ripple_Events(N,1) & Ripple_Data(:,1)<=Ripple_Events(N,2)),[2,3,5,6,7]);% also check this
                Ripple_Subset_Data=Ripple_Data(find(Ripple_Data(:,1)>=Ripple_Events(N,1) & Ripple_Data(:,1)<=Ripple_Events(N,2)),[2,3,5,6,]);% also check this
                zMean_Power=mean(Ripple_Subset_Data(:,2));
                zMax_Power=max(Ripple_Subset_Data(:,2));
                Raw_Mean_Power=mean(abs(Ripple_Subset_Data(:,1)));
                Raw_Max_Power=max(abs(Ripple_Subset_Data(:,1)));
                Raw_Mean_Env_Power=mean(Ripple_Subset_Data(:,3));
                Raw_Max_Env_Power=max((Ripple_Subset_Data(:,3)));
                NewZ_Mean_Power=mean((Ripple_Subset_Data(:,4)));
                NewZ_Max_Power=max((Ripple_Subset_Data(:,4)));
                Ripple_Power(N,1:8)=[zMean_Power,zMax_Power,Raw_Mean_Power,Raw_Max_Power,Raw_Mean_Env_Power,Raw_Max_Env_Power,NewZ_Mean_Power,NewZ_Max_Power];
                clear Ripple_Subset_Data;
            end
        end
        
        if exist('Ripple_Power','VAR')
        eval(sprintf('Ripple_Events_Epoch%d_%dSD=Ripple_Events;Ripple_Power_Epoch%d_%dSD=Ripple_Power;',Epoch,Minimum_Peak_Height_Multiplier,Epoch,Minimum_Peak_Height_Multiplier));
        clear Ripple_Events;
        %if exist('Ripple_Power','VAR')
        clear Ripple_Power;
        end
  end
end

save('Ripple_Events','Ripple_Events_*','Ripple_Power_*');
