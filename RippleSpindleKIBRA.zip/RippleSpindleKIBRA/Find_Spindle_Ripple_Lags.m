%PURPOSE: Calculate several measures related to Spindle-Ripple Coupling
%sigma power during SWRS, Ripple-spindle offset, Spindle-nested SWRs,
%SWRs outside of spindles, etc.
%
%INPUT: 
% Spindle_Events
% Ripple_Data
% Load Detected SWRS
% OUTPUT: 
% 
%Authors/origin creds
% LD Quigley
%
% Volk & Pfeiffer Lab
%========================================================================== 
load('Spindle_Events','Complete_Sigma_Data')
load('Spindle_Events_PreExp.mat')
% Load Detected Spindles
load('SWS_Ripples_PreExp_Calc.mat','Ripple_Data_Cat')

Timelags1 = zeros(length(Ripple_Data_Cat),1);
Nested_Ripples1 = [];
Nested_Ripples_Duration1 = [];
Nested_Ripple_Lags1 = []
Spindle_Nest1 = [];
Outside_Ripples1 = [];
Outside_Ripples_Duration1 = [];
Outside_Ripple_Lags1 = [];
Spindle_Out1 = [];
Peak_Spindle_Power_Ripple = []
Nested_Ripples_Duration1 = []
Outside_Ripples_Duration1 = []
All_Ripples_Duration1 = []

% Calculate properties for each SWR event
for i = 1:size(Ripple_Data_Cat)
    Ripple_Start=(Ripple_Data_Cat(i,1));
    Ripple_End=(Ripple_Data_Cat(i,2));
    Sigma_During_Ripple = Complete_Sigma_Data(find(Complete_Sigma_Data(:,1)>Ripple_Start & Complete_Sigma_Data(:,1)<Ripple_End),6);
   Peak_Spindle_Power_Ripple = [Peak_Spindle_Power_Ripple;max(Sigma_During_Ripple)];
   % Find the closest spindle start time to the ripple start time 
    [~,Timeidx] = min(abs(Spindle_Events(:,1)-Ripple_Start));
    RippleTimelags1(i) = Ripple_Start-Spindle_Events(Timeidx);
    %Find ripples that occured during a spindle before or after 
          All_Ripples_Duration1 = [All_Ripples_Duration1;Ripple_End-Ripple_Start];
        %Ripples Nested within spindles 
        if Ripple_Start>Spindle_Events(Timeidx,1) && Ripple_Start<Spindle_Events(Timeidx,2)
            Nested_Ripples1 = [Nested_Ripples1;(Ripple_Data_Cat(i,:))];
            Nested_Ripples_Duration1 = [Nested_Ripples_Duration1;Ripple_End-Ripple_Start];
            Nested_Ripple_Lags1 = [Nested_Ripple_Lags1;[Ripple_Data_Cat(i,:) RippleTimelags1(i)]];
            Spindle_Nest1 = [Spindle_Nest1;Spindle_Events(Timeidx,:)];
        end
        
        % Ripples occuring outside of spindles 
        if Ripple_Start<Spindle_Events(Timeidx,1) || Ripple_Start>Spindle_Events(Timeidx,2)
        Outside_Ripples1 = [Outside_Ripples1;(Ripple_Data_Cat(i,:))];
        Outside_Ripples_Duration1 = [Outside_Ripples_Duration1;Ripple_End-Ripple_Start];
        Outside_Ripple_Lags1 = [Outside_Ripple_Lags1;[Ripple_Data_Cat(i,:) RippleTimelags1(i)]];
        Spindle_Out1 = [Spindle_Out1;Spindle_Events(Timeidx,:)];
        end
               
   
end

       RippleFreeSpindles1 = [];
       RippleFreeSpindleLags1 = [];
       Nested_Spindle_Lags1 = []
       MinTroughTimelags1 = []
       NearestTroughOffset = []
      
for i = 1:size(Spindle_Events,1)
    Spindle_Start=(Spindle_Events(i,1));
    Spindle_Times= find(Complete_Sigma_Data(:,1)>=Spindle_Events(i,1) & Complete_Sigma_Data(:,1)<=Spindle_Events(i,2));
    [Spindle_Troughs,P] = islocalmin(Complete_Sigma_Data(Spindle_Times,2));
    Min_Trough_Time = Complete_Sigma_Data(Spindle_Times(find(P==max(P))),1)
    
    % Find the closest ripple start time to the spindle start time 
    [~,Timeidx] = min(abs(Ripple_Data_Cat(:,1)-Spindle_Start));
    SpindleTimelags1(i) = Spindle_Start-Ripple_Data_Cat(Timeidx,1);
    
    if Ripple_Data_Cat(Timeidx,1)>Spindle_Events(i,1) && Ripple_Data_Cat(Timeidx,1)<Spindle_Events(i,2)
         %Nested_Ripples1 = [Nested_Ripples1;(Ripple_Data_Cat(i,:))];
            Nested_Spindle_Lags1 = [Nested_Spindle_Lags1;[Spindle_Events(i,:) SpindleTimelags1(i)]];
            %Spindle_Nest1 = [Spindle_Nest1;Spindle_Events(Timeidx,:)];
    %Find offset from abs spindle trough
    [~,Timeidx] = min(abs(Ripple_Data_Cat(:,1)-Min_Trough_Time));
    MinTroughTimelags1 =  [MinTroughTimelags1;Min_Trough_Time-Ripple_Data_Cat(Timeidx,1)];
    %Find offset from nearest spindle trough
    Spindle_Troughs = Spindle_Times(Spindle_Troughs>0);
    for s = 1:size(Spindle_Troughs,1)
     %find the closest ripple start to each trough
    [~,Timeidx] = min(abs(Ripple_Data_Cat(:,1)-Complete_Sigma_Data(Spindle_Troughs(s),1)));
    NearestTroughTimelags1(s,1) = Complete_Sigma_Data(Spindle_Troughs(s),1)-Ripple_Data_Cat(Timeidx,1);
    end
    NearestTroughOffset = [NearestTroughOffset;min(abs(NearestTroughTimelags1))]
    
    elseif Ripple_Data_Cat(Timeidx,1)<Spindle_Events(i,1) || Ripple_Data_Cat(Timeidx,1)>Spindle_Events(i,2)
        RippleFreeSpindles1 = [RippleFreeSpindles1 ;(Spindle_Events(i,:))];
       RippleFreeSpindleLags1 = [RippleFreeSpindleLags1; [Spindle_Events(i,:) SpindleTimelags1(i)]];
        %Spindle_Out1 = [Spindle_Out1;Spindle_Events(Timeidx,:)];
        
    end
end

clearvars -except D k WT* Nested_Ripples* Outside_Ripples* Spindle_Nest* Spindle_Out*

save('Spindle-Ripple-Lags')
%clearvars -except D k WT*
c%d ..


%figure
%histogram(Outside_Ripples1(:,11),16,'BinWidth',1,'Normalization','probability','FaceColor','b')
%hold on 
%histogram(Outside_Ripples6(:,11),16,'BinWidth',1,'Normalization','probability','FaceColor',[0.3010 0.7450 0.9330])

%[uniqueA i j] = unique(Spindle_Nest6,'rows');
 %indexToDupes = find(not(ismember(1:numel(Spindle_Nest6),i)))

%

