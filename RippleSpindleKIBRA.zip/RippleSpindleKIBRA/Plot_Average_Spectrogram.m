%%
D = dir('G:\Current_Kc_Analysis\WT');
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));

for k = 1:numel(D)
    currD = D(k).name;
    cd(currD);
    tic

load LFP_Electrodes
load Ripple_Data_Imm1_5SD.mat
Generate_SWR_Spectrogram(Ripple_Data_Cat,LFP_Electrodes, .2, .19,'New','PreExp')
clearvars -except D k LFP_Electrodes

load Ripple_Data_Imm6_5SD.mat
Generate_SWR_Spectrogram(Ripple_Data_Cat,LFP_Electrodes, .2, .19,'New','PostExp')
%fprintf('Done With Mouse %d\n',k) 
cd ..

clearvars -except D k
toc
end
%%
WT_Spec_Pre = zeros(151,201);
WT_Spec_Post = zeros(151,201);
WT_Spec_OnTask = zeros(151,201);

counter1 = 0
counter2 = 0
counter3 = 0

D = dir('G:\Current_Kc_Analysis\WT');
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));

for k = 1:numel(D)
    currD = D(k).name;
    cd(currD);
    tic


cd ./Ripple_Spectrograms/New
load('Ripple_Spectrogram_Sum_PreExp.mat')


WT_Spec_Pre = WT_Spec_Pre+Ripple_Spectrogram_Sum;
counter1 = counter1+1
 %cd ..
%cd ..
clearvars Ripple_Spectrogram_Sum


load('Ripple_Spectrogram_Sum_PostExp.mat')
WT_Spec_Post = WT_Spec_Post+Ripple_Spectrogram_Sum;
counter2 = counter2+1
%cd ..
%cd ..
load Vars
clearvars Ripple_Spectrogram_Sum


%load('Ripple_Data_On_Task_ThreshAll_Imm-2nd5SD.mat')
%if  exist('ACC_Electrode.mat','file') && size(Ripple_Data_Cat,1)>1
%cd ./Ripple_Spectrograms/OnTask
%load('Ripple_Triggered_Average_TF_PowerOnTask_CA1_.mat', 'tf','frex')
%WT_ACC_Spec_OnTask = WT_ACC_Spec_OnTask+tf(:,3200:9600-1);
%counter3 = counter3+1
%cd ..
%cd ..
clearvars Ripple_Spectrogram_Sum

clearvars -except D k counter* WT* Phase* Amp* frex SpecTime f
cd ..
cd ..
cd ..
end


WT_Spec_Pre  =WT_Spec_Pre/counter1;
WT_Spec_Post =WT_Spec_Post /counter2;
%WT_ACC_Spec_OnTask =WT_ACC_Spec_OnTask/counter3;

%% Plot

figure
clf
contourf(SpecTime,frex,WT_Spec_Pre',30,'LineStyle','none')
set(gca,'fontsize',14)
%set(gca,'xlim',[0 20])
colormap(jet)
ylabel('Amplitude Frequency (Hz)')
xlabel('Phase Frequency (Hz)')
colorbar

% SpecTime = [-1:1/100:(1)]%-(1/100)];
% %Spectrogram_TimesPre=Times-((0:(length(Times)-1)*0.001));
% figure;
% %hold on;
% %subplot('Position',[0 0 1 1]);
% %hold on;
% %imagesc(WT_Spec_Pre);set(gca,'YDir','normal');
% imagesc(SpecTime,f,WT_Spec_Pre); set(gca,'YDir','normal');
% %yticks([6 12 17 22 27 32 37 42 47])
% %yticklabels({'10','25','50','100','150','200','250','300','350'})
% %frex = [0:2:20,25:5:50,60:10:350];
% %imagesc([SpecTime(1) SpecTime(end)],[frex(1) frex(end)],WT_Spec_Pre); set(gca,'YDir','normal');
% set(gca,'YLim',[100 300]);

% %set(gca,'clim',[0 2.5])
% %set(gca,'YTick',[]);
% colormap('hot');
 contourf(SpecTime,frex,tf,32,'LineWidth',.05,'LineStyle',':')
 set(gca,'XLim',[-.4 .4]);
% %figure
% %contourf(WT_Spec_Post,25,'linecolor','none')
% %colormap(jet)
% %colormap('hot');
figure
%clf
%surface(SpecTime,f,WT_Spec_Pre,'EdgeColor','none')
imagesc(SpecTime,f,WT_Spec_Post); set(gca,'YDir','normal');
 colormap(inferno)
 set(gca,'XLim',[-.4 .4]);
 
 

% %set(gca,'YLim',[0 350]);
% %set(gca,'XLim',[SpecTime(1) SpecTime(end)]);
% %set(gca,'CLim',[SpecTime(1) SpecTime(end)]);
% %set(gca,'YLim',[0 size(Ripple_Spectrogram_Sum,1)]);
% %set(gca,'XLim',[0 size(Ripple_Spectrogram_Sum,2)]);
% %set(gca,'XTick',frex);
% %set(gca,'YTick',[]);
% 
% % 
% % Start_Time = -1
% % End_Time = 1
% % EEG.Times = Start_Time:1/3200:End_Time-(1/3200);
% % %contourf(EEG.Times,frex,tf,32,'LineWidth',.05,'LineStyle',':')
% % figure
% % contourf(EEG.Times,frex,WT_ACC_Spec_SWSPost,40,'linecolor','none')
% % set(gca,'fontsize',14)
% % set(gca,'xlim',[-1 1])
% % %set(gca,'clim',[-.5 1.4])
% % %set(gca,'clim',[-3.5 12])
% % %set(gca,'clim',[-.8 5.1])
% % colormap(jet)
% % ylabel('Frequency (Hz)')
% % xlabel('Time From Ripple Peak (s)')
% % colorbar