%PURPOSE: TO GENERATE SPECTROGRAMS FOR VALIDATION OF DETECTED NREMSLEEP PERIODS
%
%INPUT: 
%       LFP - data as nx2 matrix of times and signal
%       SleepFile - nx3 start-end-duration
% OUTPUT: SERIES OF .FIG FILES WITH PLOTTED SPECTROGRAMS AND T2D RATIO
% 

%Authors/origin creds
% LD Quigley M. WANG & Friends
% 06 /2021
% Volk & Pfeiffer Lab
% CHRONUX


LFP_Frequency = 3200;
%load('Sleep60_1.mat')%SleepFile nx3 start-end-duration
Electrode_ID = %Indicate Electrode #
SleepFile =  %Define SleepFile

tic

%load Raw LFP data
Load_Label1=sprintf('CSC%d',LFP_Electrodes);
load(Load_Label1);
eval(sprintf('LFP=%s;',Load_Label1));
eval(sprintf('clear %s;',Load_Label1));


%filter theta and delta using hilbert transform
theta=thetafilt6_12(LFP,LFP_Frequency);delta=deltafilt(LFP,LFP_Frequency);

    binmean(:,1) = LFP(:,1);
    binmean(:,2) = movmean(theta(:,5),16000);
    binmean(:,3) = movmean(delta(:,5),40000);
    binmean(:,4)=binmean(:,2)./binmean(:,3); % theta-to-delta ratio
    T2D = [binmean(:,1),binmean(:,4)];
    %T2Dz = zscore(T2D);
%% This is to zscore only during sleep periods, to match thresholds set by observer

    
   for k = 1:size(SleepFile,1)
        SleepT2D =  T2D(T2D(:,1)>=SleepFile(k,1) & T2D(:,1)<=SleepFile(k,2),:); 
        if k==1
        ComSleepT2D = [];
        end
        ComSleepT2D = [ComSleepT2D;SleepT2D];
        clearvars SleepT2D
   end
   
    T2Dz = [ComSleepT2D(:,1),zscore(ComSleepT2D(:,2))];



%% This for loop isolates the LFP and calculates theta to delta ratio to plot
%for each REM  and SWS episode
    load SWSepochs


%% Now calculating SWS Pre Experience
for i = 1:size(SWSepochs,1)

    %extract lfp for sleep period
    slplfp = LFP(LFP(:,1)>=SWSepochs(i,1) & LFP(:,1)<=SWSepochs(i,2),:);
    Multitaper_Spectrogram_Sleep(slplfp);
     xlabel('Time Sec')
    ylabel('Frequency Hz')
    subplot(2,1,2)
    %times = binmean(binmean(:,1)>SWSepochs(i,1) & binmean(:,1)<=SWSepochs(i,2),1);
    %times = binmean(:,1);

    %times = times-times(1,1);
   % plot(times,T2Dz(binmean(:,1)>SWSepochs(i,1) & binmean(:,1)<=SWSepochs(i,2),2));
       times = T2Dz(T2Dz(:,1)>SWSepochs(i,1) & T2Dz(:,1)<=SWSepochs(i,2),1);
    %times = binmean(:,1);
    times = times-times(1,1);
    plot(times,T2Dz(T2Dz(:,1)>SWSepochs(i,1) & T2Dz(:,1)<=SWSepochs(i,2),2));
    xlim([0 times(end)])
    title('CA1 Spectrogram SWSepochs')
    xlabel('Time Sec')
    ylabel('Theta/Delta Ratio')


 
 if exist('.\Spectral_Analysis\REM-NREM','dir')==7
             cd .\Spectral_Analysis\REM-NREM
        else
            disp('Spectral Analysis REM-NREM does n1t exist')
            mkdir('.\Spectral_Analysis\REM-NREM')
            cd .\Spectral_Analysis\REM-NREM
 end
    
 saveas(gcf,sprintf('Sleep-Spectrogram-CA1-SWSepochs-epoch%d.fig',i));   
 close
 cd .. 
 cd ..
 clearvars -except REMepochsPreExp SWSepochs theta  delta  LFP sleep1 sleep6 T2Dz binmean
end


