
%% Perform Circular ANOVA
Data1 = WT_Ripple_LowG_Coherence_Angle_Pre(:,1);
Data2 = WT_Ripple_LowG_Coherence_Angle_Post(:,1);
Data3 = WT_Ripple_LowG_Coherence_Angle_OnTask(:,1);


WT_Pre = Data1;
WT_Post = Data2;
WT_OnTask = Data3;

WT = [Data1;Data2;Data3];
idq1 = zeros(1,length(Data1));idq1(:) = 1;
idq2 = zeros(1,length(Data2));idq2(:) = 2;
idq3 = zeros(1,length(Data3));idq3(:) = 3;
WT_idq = [idq1';idq2';idq3'];
WT_idp = zeros(1,length(WT)); WT_idp(:) = 1; WT_idp = WT_idp';


Data1 = KO_Ripple_LowG_Coherence_Angle_Pre(:,1);
Data2 = KO_Ripple_LowG_Coherence_Angle_Post(:,1);
Data3 = KO_Ripple_LowG_Coherence_Angle_OnTask(:,1);

KO_Pre = Data1;
KO_Post = Data2;
KO_OnTask = Data3;
KO = [Data1;Data2;Data3];
idq1 = zeros(1,length(Data1));idq1(:) = 1;
idq2 = zeros(1,length(Data2));idq2(:) = 2;
idq3 = zeros(1,length(Data3));idq3(:) = 3;
KO_idq = [idq1';idq2';idq3'];
KO_idp = zeros(1,length(KO)); KO_idp(:) = 2; KO_idp=KO_idp';

Data = [WT',KO'];
idq = [WT_idq',KO_idq'];
idp = [WT_idp',KO_idp'];
%clearvars -except WT WT_i* KO KO_i* Data idq idp

[pval, table]=circ_hktest(Data,idq,idp,1,[{'Session'},{'Genotype'}])


%% Kuiper test
[pval, k, K] = circ_kuipertest(WT_Ripple_LowG_Coherence_Angle_Pre,WT_Ripple_LowG_Coherence_Angle_Post)


% WT_Pre = Data1;
% WT_Post = Data2;
% WT_OnTask = Data3;
% 
% WT = [Data1];%;Data2]%;Data3];
% idq1 = zeros(1,length(Data1));idq1(:) = 1;
% idq2 = zeros(1,length(Data2));idq2(:) = 2;
% idq3 = zeros(1,length(Data3));idq3(:) = 3;
% WT_idq = [idq1';idq2']%;idq3'];
% WT_idp = zeros(1,length(WT)); WT_idp(:) = 1; WT_idp = WT_idp';
% 
% 
% Data1 = KO_Ripple_LowG_Coherence_Angle_Pre(:,1);
% Data2 = KO_Ripple_LowG_Coherence_Angle_Post(:,1);
% Data3 = KO_Ripple_LowG_Coherence_Angle_OnTask(:,1);
% 
% KO = [Data1];%;Data2]
% KO_idp = zeros(1,length(KO)); KO_idp(:) = 2; KO_idp=KO_idp';
% 
% 
% Data = [WT',KO'];
% idq = [WT_idq',KO_idq'];
% idp = [WT_idp',KO_idp'];
% 
% [h,p] = ConcentrationTest(Data,idp,.05)
% 
% [p,F] = CircularANOVA(angles,[factor1 factor2],method)
