    function Theta_Filtered_LFP_Data=thetafilt(raw_Data,LFP_Frequency,lfpind)
%    Theta_Data
% 
% |   1  |        2       |        3       |   4   |
% | Time | Theta-Filtered | Z-Scored Theta | Theta |
% |      |      Trace     |    Amplitude   | Phase |
    % The following values are used to build the bandpass filter for theta detection
Theta_Stop_Low=5;                
Theta_Pass_Low=6;                % Some papers use as low as 4 Hz as the low cutoff
Theta_Pass_High=12;              % Some papers use as high as 12 Hz as the high cutoff
Theta_Stop_High=14;               % Original settings 1: Theta Stop_Low 5 Theta Pass_Low 6 Theta_Pass_High 12 Theta_Stop_High_14
% changing upper bound to 10 9.11.20
Stop_Band_Attenuation_One=60;    % This was the default, I think.  
Pass_Band=1;                     % This was the default, I think.
Stop_Band_Attenuation_Two=80;    % This was the default, I think.
Filter_Design_For_Theta=fdesign.bandpass(Theta_Stop_Low, Theta_Pass_Low, Theta_Pass_High, Theta_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Theta_Filter=design(Filter_Design_For_Theta,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

    Theta_Filtered_LFP_Data=zeros(size(raw_Data,1),4);
    Theta_Filtered_LFP_Data(:,1)=raw_Data(:,1);
    Theta_Filtered_LFP_Data(:,2)=filter(Theta_Filter,raw_Data(:,2));
    %a=Theta_Filtered_LFP_Data(:,2);
    Theta_Filtered_LFP_Data(:,2)=Theta_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
    Theta_Filtered_LFP_Data(:,2)=filter(Theta_Filter,Theta_Filtered_LFP_Data(:,2));
    Theta_Filtered_LFP_Data(:,2)=Theta_Filtered_LFP_Data(end:-1:1,2);
    %b=Theta_Filtered_LFP_Data(:,2);
    for M=1:2000000:size(Theta_Filtered_LFP_Data,1),  % The program crashes if much more than about 2000000 samples are transformed at once
        %Theta_Filtered_LFP_Data(:,3)=hilbert(Theta_Filtered_LFP_Data(:,2));
        Theta_Filtered_LFP_Data(M:min([size(Theta_Filtered_LFP_Data,1),M+2000000]),3)=hilbert(Theta_Filtered_LFP_Data(M:min([size(Theta_Filtered_LFP_Data,1),M+2000000]),2));
    end
    %Theta_Filtered_LFP_Data(:,4)=(angle(Theta_Filtered_LFP_Data(:,3))*180/pi)+180;% here using trough to segment theta cycles
    Theta_Filtered_LFP_Data(:,4)=(angle(Theta_Filtered_LFP_Data(:,3))*180/pi);
    Theta_Filtered_LFP_Data(:,4)=(Theta_Filtered_LFP_Data(:,4)<0)*360+Theta_Filtered_LFP_Data(:,4);
    Theta_Filtered_LFP_Data(:,3)=abs(Theta_Filtered_LFP_Data(:,3));
    %c=Theta_Filtered_LFP_Data(:,3);
    % The following gaussian filter has a sigma of 300 ms
    Theta_Gaussian_Filter=fspecial('gaussian',[round(3*(300/((1/LFP_Frequency)*1000))),1],round(300/((1/LFP_Frequency)*1000)));
    Theta_Filtered_LFP_Data(:,3)=filtfilt(Theta_Gaussian_Filter,1,Theta_Filtered_LFP_Data(:,3));
    Theta_Filtered_LFP_Data(:,5)=Theta_Filtered_LFP_Data(:,3);
    % The following z-scores the filtered trace
    if nargin<3 | isempty(lfpind)
        Theta_Filtered_LFP_Data(:,3)=zscore(Theta_Filtered_LFP_Data(:,3));
        %Theta_Filtered_LFP_Data(:,6)=zscore(Theta_Filtered_LFP_Data(:,5));
    else
        Theta_Filtered_LFP_Data(lfpind,3)=zscore(Theta_Filtered_LFP_Data(lfpind,3));
        %Theta_Filtered_LFP_Data(lfpind,6)=zscore(Theta_Filtered_LFP_Data(lfpind,5));
    end
    
   % if 0
        %lfppwr=Theta_Filtered_LFP_Data(:,[1,5]);
        %lfp_acceleration=diff(lfppwr(:,2))./diff(lfppwr(:,1));
        %lfp_acceleration(end+1)=lfp_acceleration(end);
        %Theta_Filtered_LFP_Data(:,6)=lfp_acceleration(:);
    %Theta_Filtered_LFP_Data(:,6)=Theta_Filtered_LFP_Data(:,3);
    %d=Theta_Filtered_LFP_Data(:,3)
    %clear Theta_Gaussian_Filter;
    % below look at power's changing regulation
       % for M=1:2000000:size(Theta_Filtered_LFP_Data,1),  % The program crashes if much more than about 2000000 samples are transformed at once
            Theta_Filtered_LFP_Data(M:min([size(Theta_Filtered_LFP_Data,1),M+2000000]),7)=hilbert(Theta_Filtered_LFP_Data(M:min([size(Theta_Filtered_LFP_Data,1),M+2000000]),5));
       % end
    
        %Theta_Filtered_LFP_Data(:,8)=(angle(Theta_Filtered_LFP_Data(:,7))*180/pi);
        %Theta_Filtered_LFP_Data(:,8)=(Theta_Filtered_LFP_Data(:,8)<0)*360+Theta_Filtered_LFP_Data(:,8);
        %Theta_Filtered_LFP_Data(:,7)=abs(Theta_Filtered_LFP_Data(:,7));
    end