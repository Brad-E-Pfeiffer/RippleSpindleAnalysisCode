function L_Ratios=KRSA_CALCULATE_L_RATIO(Cluster_Directory,Raw_Directory,Number_Of_Cluster_Divisions,Cluster_Name)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This program pulls up all of the clusters for this session and calculates
% the L-ratio, which is a measure of cluster isolation.  The lower the
% score the better.  Well-isolated clusters should have values near 0.005.
%
% Inputs:
%  Times - n x 2 matrix [start end] of each session 
%  Tetrodes_To_Examine - vector with tetrode numbers of interest
%  
% Outputs: 
%  L_Ratios
%
% Volk and Pfeiffer Lab 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%Cluster_Directory='D:\ClusteringData\KO\KcSep19-1\Converted';                                           %This is the full name of the directory in which the xclust2 cluster files are located
%Raw_Directory='D:\ClusteringData\KO\KcSep19-1';                                                         %This is the full name of the directory where the raw Neuralynx spike data (the *.ntt files) are located
%Number_Of_Cluster_Divisions=3;                                                                          %If you clustered the entire session as one, this number would be 1; if you clustered pre-sleep, run, and post-sleep as three separate pieces, this number would be 3
%Cluster_Name='*cl-*';

%L_Ratios
%|    1    |           2           |             3           |            4            |
%| L_Ratio | Total Spikes In Noise | Total Spikes In Cluster | Total Spikes On Tetrode |

Current_Directory=pwd;

for Current_Tetrode=Tetrodes_To_Examine
    cd(Cluster_Directory);
    if eval(sprintf('exist(''tt%d'',''dir'')',Current_Tetrode))==7
        eval(sprintf('cd(''tt%d'');',Current_Tetrode));
        Directory_List=dir(Cluster_Name);        %This finds all files with "cl-" in the file name.  If you named your clusters something else, change this accordingly
        if ~isempty(Directory_List)
            cd(Raw_Directory);
            eval(sprintf('[Times,Spike_Parameters]=(Nlx2MatSpike(''TT%d.ntt'',[1 0 0 1 0],0,1));',Current_Tetrode));
            Spike_Parameters=Spike_Parameters';
            Times=(Times/1000000)';
            cd(Cluster_Directory);
            eval(sprintf('cd(''tt%d'');',Current_Tetrode));
            Number_Of_Clusters=length(Directory_List)/Number_Of_Cluster_Divisions;
            if Number_Of_Clusters~=round(Number_Of_Clusters)
                error('Number of actual clusters is not compatible with number of cluster divisions.')
            end
            for Current_Cluster=1:Number_Of_Clusters
                clear Loaded_Spike_Data;
                for Current_Cluster_Division=1:Number_Of_Cluster_Divisions
                    Temp_Loaded_Spike_Data=load(Directory_List(Current_Cluster+((Current_Cluster_Division-1)*Number_Of_Clusters)).name);
                    if ~isempty(Temp_Loaded_Spike_Data)
                        if exist('Loaded_Spike_Data','var')
                            Loaded_Spike_Data=[Loaded_Spike_Data;Temp_Loaded_Spike_Data(:,1:5)];
                        else
                            Loaded_Spike_Data=Temp_Loaded_Spike_Data(:,1:5);
                        end
                        clear Temp_Loaded_Spike_Data;
                    end
                end
                clear Current_Cluster_Division;
                if 1 %size(Loaded_Spike_Data,1)/(max(Times)-min(Times))<10, %if the average firing rate is less than 10 Hz -- this keeps the program from analyzing inhibitory neurons, which might have worse L-ratios
                    Temp_Spike_Parameters=Spike_Parameters;
                    Temp_Spike_Parameters(:,9)=1;
                    Temp_Spike_Parameters(Loaded_Spike_Data(:,1),9)=0;
                    Temp_Spike_Parameters=Temp_Spike_Parameters(Temp_Spike_Parameters(:,9)==1,1:4);  %Temp_Spike_Parameters is now the values of all the spikes from this tetrode that are NOT in the current cluster
                    New_L_Ratio=[(sum(1-cdf('chi2',mahal(Temp_Spike_Parameters(:,1:4),Loaded_Spike_Data(:,2:5)),4)))/length(Times),size(Temp_Spike_Parameters,1),size(Loaded_Spike_Data,1)];
                    if exist('L_Ratios','var')
                        L_Ratios=[L_Ratios;New_L_Ratio];
                    else
                        L_Ratios=New_L_Ratio;
                    end
                    clear New_L_Ratio;
                    clear Temp_Spike_Parameters;
                    clear Loaded_Spike_Data;
                end
            end
            clear Current_Cluster;
            clear Times;
            clear Spike_Parameters;
        end
        clear Directory_List
    end
    disp(sprintf('Finished calculating L-ratios for all clusters on tetrode %d of %d.',Current_Tetrode,40));
end
cd(Current_Directory)
save('L_Ratios','L_Ratios')
        
        
end
