%% 
%PURPOSE: Calculate percent of SWRs within 2 secs of a spindle
%
%INPUT: 
% Spindle_Events
% Ripple_Data
%
% 
% 
% L. Quigley
% Volk & Pfeiffer Lab
%========================================================================== 
PercentSWR_2sec1 = [];
PercentSWR_2sec6 = [];


tic
D = dir('G:\Current_Kc_Analysis\WT');
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));
for k = 1:numel(D)
    currD = D(k).name;
    cd(currD)
   %First calculate for Pre-experience 
   if exist('Spindle_Events_PreExp.mat','file')    
     load('SWS_Ripples_PreExp_Calc.mat','Ripple_Data_Cat')
     load('Spindle_Events_PreExp.mat')
     %load('Spindle_Events','Complete_Sigma_Data')
     Timelags1 = zeros(length(Ripple_Data_Cat),1);
        parfor i = 1:size(Ripple_Data_Cat,1)
            Ripple_Start=(Ripple_Data_Cat(i,1));
            Ripple_End=(Ripple_Data_Cat(i,2));

        [~,Timeidx] = min(abs(Spindle_Events(:,1)-Ripple_Start));
        RippleTimeLags1(i) = Ripple_Start-Spindle_Events(Timeidx);
        end
        RippleTimeLags1= abs(RippleTimeLags1)
        Ripples = find(RippleTimeLags1<2);
    PercentSWR_2sec1 = [PercentSWR_2sec1;length(Ripples)/length(RippleTimeLags1)];
   clearvars -except D k Percent*
   end
   
       if exist('Spindle_Events_PostExp.mat')
           load('Spindle-Ripple-Lags.mat', 'RippleTimeLags6')
           RippleTimeLags6= abs(RippleTimeLags6)
           Ripples = find(RippleTimeLags6<2);
           PercentSWR_2sec6 = [PercentSWR_2sec6;length(Ripples)/length(RippleTimeLags6)];
           clearvars -except D k Percent*
       end
   
cd ..
end