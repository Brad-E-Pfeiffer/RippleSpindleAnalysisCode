
%% Plot Raw and Filtered traces for detected ripples

load Ripple_Data_Imm1_5SD.mat
Electrode_ID = 5;


figure
Plot_Ripple_Traces_for_fig(Ripple_Data_Cat(33,1)-.5,Electrode_ID,Ripple_Data_Cat,1)
set(gca,'YLim',[-300 300]);
set(gca,'XLim',[0 1]);

%set(gca,'YTick',[]);
%colormap('jet');
%PLOT_RIPPLES(Ripple_Data_Cat,Electrode_ID,Ripple_Number)


load Ripple_Data_Imm6_5SD.mat
load Electrode_ID


figure
Plot_Ripple_Traces_for_fig(Ripple_Data_Cat(8,1)-.4,Electrode_ID,Ripple_Data_Cat,1)
set(gca,'YLim',[-300 300]);
set(gca,'XLim',[0 1]);

%set(gca,'YTick',[]);
%colormap('jet');
%PLOT_RIPPLES(Ripple_Data_Cat,Electrode_ID,Ripple_Number)


%% Plot HeatMap Visualization for ripple rate 
load CSC9
load TimesSession
load Ripple_Data_Imm1_5SD.mat
Ripples1=Ripple_Data_Cat;
%figure
%set(gcf, 'renderer', 'painters')
t = 0:1:Times(end,2)-CSC9(1,1);
y = zeros(1,length(t));

load TimesSession
load Ripple_Data_Imm6_5SD.mat

Ripples2 = Ripple_Data_Cat;


Ripples=[Ripples1;Ripples2]
figure
[bincounts,ind]=histc(Ripples1(:,3)-CSC9(1,1),0:300:Times(1,2)-CSC9(1,1));
bins = [0:300:Times(1,2)-CSC9(1,1)];
%set(gca,'xcolor','w','ycolor','w','xtick',[],'ytick',[])
%set(gca,'box','off')
clf
bincounts=bincounts./length(Ripple_Data_Cat);
heatmap(bins,1,bincounts','GridVisible', 'off')%'colorlimit',[0 .18])
%set(gca,'Visible','off')
colormap(inferno)
Ax = gca;
Ax.XDisplayLabels = nan(size(Ax.XDisplayData));
Ax.YDisplayLabels = nan(size(Ax.YDisplayData));


[bincounts,ind]=histc(Ripples2(:,3)-CSC9(1,1),Times(6,1)-CSC9(1,1):300:Times(6,2)-CSC9(1,1));
bins = [Times(6,1)-CSC9(1,1):300:Times(6,2)-CSC9(1,1)];
%set(gca,'xcolor','w','ycolor','w','xtick',[],'ytick',[])
%set(gca,'box','off')
figure
clf
bincounts=bincounts./length(Ripple_Data_Cat);
heatmap(bins,1,bincounts','GridVisible', 'off')%'colorlimit',[0 .18])
%set(gca,'Visible','off')
colormap(inferno)
Ax = gca;
Ax.XDisplayLabels = nan(size(Ax.XDisplayData));
Ax.YDisplayLabels = nan(size(Ax.YDisplayData));

