function [] = KRSA_CALCULATE_PAC_DURING_EPOCHS(Epochs,lfp,Pf1,Pf2,Af1,Af2,srate)
% FUNCTION:
%Calculate phase amplitude distribution  between two frequency bands for
%all epochs using established method (See Tort et al J Neurophysiol 2010 
%and the Supp Info of Tort et al PNAS 2008)
%requires the eegfilt function from the EEGLAB toolbox 
%(Delorme and Makeig J Neurosci Methods 2004)
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% INPUT: 
%  Epoch_Times = n x 3 file containing Start, end and peak times
%  lfp = nx2 file containing times, signal
%  Phase_Band  = Pf1 Pf2
%  Amp_Band = Af1 Af2
%  srate = sampling frequency
% 


% OUTPUT: 
%  All_Mean_Amp - matrix containing phase amplitude distribution for each epoch  
%  All_MI - a vector containing a modulation index for each epoch 
%  Sum_Mean_Amp - average phase amplitude dist. for all epochs

% L. Quigley
% Volk & Pfeiffer Lab

%==========================================================================

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%

Epochs = sortrows(Epochs,1);
%dt = 1/srate;

PhaseFreq=eegfilt(lfp(:,2)',srate,Pf1,Pf2); % this is just filtering 
Phase=(angle(hilbert(PhaseFreq)));%+180; % this is getting the phase time series
AmpFreq=eegfilt(lfp(:,2)',srate,Af1,Af2); % just filtering
Amp=abs(hilbert(AmpFreq)); % getting the amplitude envelope


% Computing the mean amplitude in each phase:
nbin = 18; % number of phase bins
position=zeros(1,nbin);
winsize = 2*pi/nbin;
for j=1:nbin 
    position(j) = -pi+(j-1)*winsize; 
end
%nbin=length(position);

Sum_Mean_Amp = zeros(1,nbin);
All_MI = [];
All_Mean_Amp = [];

for i=1:size(Epochs,1)
    if Epochs(i,3)>.3
    Start_Time = Epochs(i,1);
    End_Time = Epochs(i,2);
    data_length = (abs(End_Time)-abs(Start_Time))*3200;   
    Aidx = find(lfp(:,1)>=Start_Time & lfp(:,1)<=End_Time);  
    
% Calculate Phase amplitude distribution 
 PhaseRip = Phase(Aidx);
 AmpRip = Amp(Aidx);
    
MeanAmp=zeros(1,nbin); 
for j=1:nbin   
I = find(PhaseRip <  position(j)+winsize & PhaseRip >=  position(j));
MeanAmp(j)=mean(AmpRip(I)); 
end

% Calculate modulation index
MI=(log(nbin)-(-sum((MeanAmp/sum(MeanAmp)).*log((MeanAmp/sum(MeanAmp))))))/log(nbin);
All_MI = [All_MI;MI];
Sum_Mean_Amp = Sum_Mean_Amp+MeanAmp;
All_Mean_Amp = [All_Mean_Amp;MeanAmp];
    end

end

% the center of each bin (for plotting purposes) is position+winsize/2 
% MI quantifies the amount of amp modulation by means of a
% normalized entropy index (Tort et al PNAS 2008):

%Sum_Mean_Amp = Sum_Mean_Amp/size(Epochs,1)
All_Mean_Amp(any(isnan(All_Mean_Amp), 2), :) = [];
All_MI(any(isnan(All_MI), 2), :) = [];
Sum_Mean_Amp = mean(All_Mean_Amp,1);

%Make a plot of the average distribution per epoch 
plot(Sum_Mean_Amp)

bar(10:20:720,[Sum_Mean_Amp,Sum_Mean_Amp]/sum(Sum_Mean_Amp),'k')
%bar(10:20:720,[Sum_Mean_Amp,Sum_Mean_Amp]/sum(Sum_Mean_Amp),'k')
xlim([0 720])
set(gca,'xtick',0:360:720)
xlabel('Phase (Deg)')
ylabel('Amplitude')
title(['MI = ' num2str(mean(All_MI))]);

% savefig(gcf,sprintf('CA1_%s_%s_General_%s.fig',Phase_Band,Amp_Band,Dirname));
% save(sprintf('PAC_%s_%s_General_%s',Phase_Band,Amp_Band,Dirname),'All_Mean_Amp','All_MI','Sum_Mean_Amp')
cd ..
cd ..
close

end

