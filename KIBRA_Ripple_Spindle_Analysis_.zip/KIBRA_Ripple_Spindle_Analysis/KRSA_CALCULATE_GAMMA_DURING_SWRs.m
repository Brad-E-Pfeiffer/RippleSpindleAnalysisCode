function KRSA_CALCULATE_GAMMA_DURING_SWRs(Velocity_Cutoff,Electrode_ID,Ripples,Dirname)

% %% FUNCTION:
%  This program calculates the z-scored slow-gamma power during all SWRs 
%  To do this, for each ripple,it finds the z-scored slow-gamma power for each SWR on the electrode of
% interest.
% This assumes LFP data has been filtered in low gamma range
% If velocity cutoff>0, animal position data is required containing 
% recording times and x-y positions in cm.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%
% INPUT: 
%  Electrode_ID = ID of LFP electrode of interest
%  Ripples = n x 3 file containing Start, end and peak times  
%  Dirname = Name of directory for saving files 
%  Velocity_Cutoff = velocity cutoff to limit analysis 

% OUTPUT: LowGamma_Power_Per_SWR.mat
%  
%
% L. Quigley 
% Volk & Pfeiffer Lab

%==========================================================================

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%

%load start and end times for session of interest 
load Times.mat

%load filtered low gamma data
Load_Label=sprintf('LowGamma_CSC%d',Electrode_ID);
load(Load_Label);
eval(sprintf('Complete_LowGamma_Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

% Find time points when subject velocity less than cutoff
 if Velocity_Cutoff>0
        LFP_Velocity=[];
        load('Processed_Position_Data_Smoothed','Position_Data')
        Velocity=CALCULATE_VELOCITY(Position_Data);Velocity=Velocity(:);
        %Added 6/8/2020
        Velocity = smoothdata(Velocity);
        template=Complete_LowGamma_Data(:,1);ruler=Position_Data(:,1);[outputindex,error]=match(template,ruler,0);
        LFP_Velocity(:,1:2)=[Velocity(outputindex),abs(error)];
        if 0
            for N=1:size(Complete_LowGamma_Data,1)
                LFP_Velocity(N,1)=Velocity(find(abs(Position_Data(:,1)-Complete_LowGamma_Data(N,1))==min(abs(Position_Data(:,1)-Complete_LowGamma_Data(N,1))),1,'first'));
            end
        end
        LowGamma_Data=Complete_LowGamma_Data( (LFP_Velocity(:,1)<=Velocity_Cutoff & LFP_Velocity(:,2)<0.5),:);
 end
 
 % zscore normalize using mean of baseline period
        HCidx1 = find(LowGamma_Data(:,1)>=Times(1,1) & LowGamma_Data(:,1)<=Times(1,2));
        %HCidx2 = find(LowGamma_Data(:,1)>=Times(6,1) & LowGamma_Data(:,1)<=Times(6,2));
        LowGamma_Data = [LowGamma_Data(HCidx1,:)];%;LowGamma_Data(HCidx2,:)];       
        Mean_LowGamma_Amplitude = mean(LowGamma_Data(:,3)); % changing to column 5 for power env
        STD_LowGamma_Amplitude=std(LowGamma_Data(:,3));      
        Complete_LowGamma_Data(:,3) = (Complete_LowGamma_Data(:,3)-Mean_LowGamma_Amplitude)/(STD_LowGamma_Amplitude);
         

% Set the size of desired time bin and how far out to look 
Bin_Size=0.1;           % The size of each time bin (in seconds)
Start_Time=-0.450;        % The time (in seconds) from the start of each event to start calculating gamma power
End_Time=0.450;           % The time (in seconds) from the start of each even to stop calculating gamma power
Time_Bins=Start_Time:Bin_Size:End_Time;

Gamma_Power_Per_SWR=zeros(size(Ripples,1),length(Time_Bins)-1);

Mean_Gamma_Power_Per_SWR=zeros(size(Ripples,1),1);
Peak_Gamma_Power_Per_SWR=zeros(size(Ripples,1),1);

 % Find SWR-triggered low gamma for each SWR
            for Ripple=1:size(Ripples,1)

                    Ripple_Gamma_Power=Complete_LowGamma_Data(find(Complete_LowGamma_Data(:,1)>=(Ripples(Ripple,1)+Start_Time) & Complete_LowGamma_Data(:,1)<=(Ripples(Ripple,1)+End_Time)),[1,3]);                          
                    Just_The_Ripple_Gamma_Power=Ripple_Gamma_Power(find(Ripple_Gamma_Power(:,1)>=Ripples(Ripple,1) & Ripple_Gamma_Power(:,1)<=Ripples(Ripple,2)),:);
                    Ripple_Gamma_Power(:,1)=Ripple_Gamma_Power(:,1)-Ripples(Ripple,1);
                    
                    Mean_Gamma_Power_Per_SWR(Ripple,1)=Mean_Gamma_Power_Per_SWR(Ripple,1)+mean(Just_The_Ripple_Gamma_Power(:,2));
                    Peak_Gamma_Power_Per_SWR(Ripple,1)=Peak_Gamma_Power_Per_SWR(Ripple,1)+max(Just_The_Ripple_Gamma_Power(:,2));
   
                  for Current_Bin=1:(length(Time_Bins)-1)
                        Gamma_Power_Per_SWR(Ripple,Current_Bin)=Gamma_Power_Per_SWR(Ripple,Current_Bin)+mean(Ripple_Gamma_Power(find(Ripple_Gamma_Power(:,1)>=Time_Bins(Current_Bin) & Ripple_Gamma_Power(:,1)<=Time_Bins(Current_Bin+1)),2));        
                  end
             end


% Save to directory 
    if ~exist(sprintf('./Gamma_Power_Ripples_New_%s',Dirname),'dir')
        mkdir(sprintf('./Gamma_Power_Ripples_New_%s',Dirname))
    end
    cd(sprintf('./Gamma_Power_Ripples_New_%s',Dirname))
%cd(Dir);

save('LowGamma_Power_Per_SWR','Gamma_Power_Per_SWR','Mean_Gamma_Power_Per_SWR','Peak_Gamma_Power_Per_SWR');
clearvars -except  D
cd ..
end