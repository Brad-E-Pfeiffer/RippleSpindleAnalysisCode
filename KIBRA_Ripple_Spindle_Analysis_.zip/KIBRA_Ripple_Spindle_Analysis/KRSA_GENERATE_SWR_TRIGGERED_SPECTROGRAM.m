function KRSA_GENERATE_SWR_TRIGGERED_SPECTROGRAM(Ripple_Events,Electrode_ID, Time_Bin_Size, Time_Bin_Overlap,Dirname,Filename)
% %% FUNCTION:
% This function creates an average SWR-triggered spectrogram for each
% subject and saves associated vars to a directory
% Assumes that an nx2 matrix exists containing LFP data for 
% electrode of interest consisting of recording times and signal

% INPUT: 
%  Electrode_ID = ID of LFP electrode of interest
%  Time_Bin_Size = Size of Time Bin in sec 
%  Time_Bin_Overlap = set desired overlap 
%  Ripple_Events = n x 3 file containing Start, end and peak times  
%  Dirname = Name of directory for saving files 
%  Filename = string to append to filename

% 
%  
%
% L. Quigley
% Volk & Pfeiffer Lab

%==========================================================================

LFP_Frequency = 3200;
Load_Label=sprintf('CSC%d',Electrode_ID);
load(Load_Label);
eval(sprintf('LFP_Samples=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

load TimesSession
TimesSession = Times;
LFP_SamplesPre =LFP_Samples(find(LFP_Samples(:,1)>=Times(1,1) & LFP_Samples(:,1)<=Times(1,2)),:);



[s,f,t,Session_SpectrogramPre]=spectrogram(LFP_SamplesPre(:,2),round(LFP_Frequency*(Time_Bin_Size)),round(LFP_Frequency*(Time_Bin_Overlap)),[0:2:300],LFP_Frequency);
%LFP_Samples is the raw LFP trace.  LFP_Frequency is the sampling frequency.  For Time_Bin_Size and Time_Bin_Overlap, I usually use 0.2 and 0.19, respectively, which means the oscillations are quantified using 200 ms bins that have 190 ms overlap, meaning you have ~10 ms temporal resolution.

%The timepoint of each bin is:
Times = LFP_SamplesPre(:,1);

avg = [];
SD = [];
for Q=1:size(Session_SpectrogramPre,1)
    avg(Q) = mean(Session_SpectrogramPre(Q,:));
    SD(Q) = std(Session_SpectrogramPre(Q,:));

end

[s,f,t,Session_Spectrogram]=spectrogram(LFP_Samples(:,2),round(LFP_Frequency*(Time_Bin_Size)),round(LFP_Frequency*(Time_Bin_Overlap)),[0:2:300],LFP_Frequency);

Times  = LFP_Samples(:,1);

Start_Time=min(LFP_Samples(:,1));  %Find the first time bin
Spectrogram_Times = t;
Spectrogram_Times=Spectrogram_Times+Start_Time; 


parfor Q =1:size(Session_Spectrogram,1)
   Session_Spectrogram(Q,:) = (Session_Spectrogram(Q,:)-avg(Q))/SD(Q); 
end

Spectrogram_Sum = Session_Spectrogram;
%Then, it's pretty easy to find the spectrogram for each ripple and average them (+/- 1 second):
 i = 0;
for N=1:size(Ripple_Events,1)
    Ripple_Start=Ripple_Events(N,1);
    [~,Start_Bin] = min(abs(Spectrogram_Times-Ripple_Start));
    %Start_Bin=find(abs(Spectrogram_Times-Ripple_Start)==min(abs(Spectrogram_Times-Ripple_Start)),1,'first');
    if Start_Bin>=100
    Ripple_Spectrogram=Spectrogram_Sum(:,(Start_Bin-round(1/(Time_Bin_Size-Time_Bin_Overlap))):(Start_Bin+round(1/(Time_Bin_Size-Time_Bin_Overlap))));
    
    if exist('Ripple_Spectrogram_Sum','var')
        Ripple_Spectrogram_Sum=Ripple_Spectrogram_Sum+Ripple_Spectrogram;
    else
        Ripple_Spectrogram_Sum=Ripple_Spectrogram;
    end
    else 
       i=i+1;
    end
end
Ripple_Spectrogram_Sum=Ripple_Spectrogram_Sum/(size(Ripple_Events,1)-i);

SpecTime = [-1:1/100:(1)];%-(1/100)];

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
imagesc(Ripple_Spectrogram_Sum);
frex = [0:2:20,25:5:50,60:10:350];


if exist('Ripple_Spectrograms','dir') && ~exist(sprintf('./Ripple_Spectrograms/%s',Dirname),'dir')
mkdir('Ripple_Spectrograms',Dirname)
cd(sprintf('./Ripple_Spectrograms/%s',Dirname))
else
    mkdir('Ripple_Spectrograms',Dirname)
cd(sprintf('./Ripple_Spectrograms/%s',Dirname))
end


colormap('hot');
set(gca,'YLim',[1 size(Ripple_Spectrogram_Sum,1)]);
set(gca,'XLim',[1 size(Ripple_Spectrogram_Sum,2)]);
%set(gca,'XTick',[]);
%set(gca,'YTick',[]);
print('-djpeg',sprintf('Ripple_Spectrogram_Sum_%s.jpg',Filename));
savefig(sprintf('Ripple_Spectrogram_Sum_%s.fig',Filename));
save('Vars','SpecTime','frex','f')
save(sprintf('Ripple_Spectrogram_Sum_%s',Filename),'Ripple_Spectrogram_Sum');
close
cd ..
cd ..