function [] = KRSA_DETECT_NREM_SLEEP(SleepFile,LFP,Threshold, LFP_Frequency)
%PURPOSE: To find epochs of putative NREM sleep using theta to delta ratio
%
%INPUT: 
%       LFP_Frequency - Sampling frequency, Fs
%       SleepFile - nx3 file containing candidate sleep periods(prolonged
%       immobility)[start,end,duration]
%       Electrode_ID- Electrode used for calculation of periods
%       LFP - Data 
% OUTPUT: SWSepochs.mat
% 

%
% L. Quigley, M. WANG  
% Volk & Pfeiffer Lab
%========================================================================== 
%Identify  SWS candidate epochs using theta to delta ratio


%load Raw LFP from Electrode of interest
% load LFP_Electrodes
% Load_Label=sprintf('CSC%d',Electrode_ID);
% load(Load_Label);
% eval(sprintf('LFP=%s;',Load_Label));
% eval(sprintf('clear %s;',Load_Label));

%LFP_Frequency = 3200; %Sampling frequency
theta=thetafilt(LFP,LFP_Frequency); %filter in theta band
delta=deltafilt(LFP,LFP_Frequency); % filter in delta band

% Smoothing over window of 5 secs for theta and 12.5 secs for delta  
    binmean(:,1) = LFP(:,1);
    binmean(:,2) = movmean(theta(:,5),16000);
    binmean(:,3) = movmean(delta(:,5),40000);
 %Calculate theta to delta ratio
    binmean(:,4)=binmean(:,2)./binmean(:,3); % theta-to-delta ratio
   
    T2D = [binmean(:,1),binmean(:,4)];
    % zscore Theta to Delta ratio
  

% This is to zscore only during sleep periods, to match thresholds set by observer
%Combine all candidate sleep periods
   for k = 1:size(All_Sleep,1)
        SleepT2D =  T2D(T2D(:,1)>=SleepFile(k,1) & T2D(:,1)<=SleepFile(k,2),:); 
        if k==1
        ComSleepT2D = [];
        end
        ComSleepT2D = [ComSleepT2D;SleepT2D];
        clearvars SleepT2D
   end
   
    T2Dz = [ComSleepT2D(:,1),zscore(ComSleepT2D(:,2))];
   
% REM-NREM Detection 
    for i = 1:size(SleepFile,1)
    tic
    T2Dz1 = T2Dz(find(T2Dz(:,1)>=SleepFile(i,1) & T2Dz(:,1)<=(SleepFile(i,2))),:);
    time = T2Dz1(:,1);
    % below to detect REM Sleep epochs which are defined as an extended sleep
    % period (should be longer than a defined minimal duration, see below) where the theta-to-delta ratio is consistently higher than threshold; 
            if i == 1
                SWSepochs = [];
            end


% Detection of NREM Epochs
    tic
    SWS_min_duration=10; % minimal duration for one qualified NREM epoch; unit: seconds
    SWSepoch=[];
    indcut=find(T2Dz1(:,2)>Threshold);
    SWSepoch(:,1)=[1;indcut(:)+1];
    SWSepoch(:,2)=[indcut(:)-1;size(T2Dz1,1)];
    SWSepoch=SWSepoch(SWSepoch(:,2)-SWSepoch(:,1)>0,:);
    SWSepoch(:,1) = time(SWSepoch(:,1));
    SWSepoch(:,2) = time(SWSepoch(:,2));
    %SWSepoch(:,1)=binmean( SWSepoch(:,1),1)-timebin/2; SWSepoch(:,2)=binmean( SWSepoch(:,2),1)+timebin/2;
    SWSepoch(:,3)=SWSepoch(:,2)-SWSepoch(:,1);
    SWSepoch=SWSepoch(SWSepoch(:,3)>=SWS_min_duration,:);
    disp([num2str(size(SWSepoch,1)),' SWS Sleep epochs are detected; SWSepoch has 3 columns: | starting time | ending time | SWS epoch duration in sec |'])
    %save('SWSepochsPreExp','SWSepoch')

    SWSepochs = [SWSepochs;SWSepoch];
    clearvars SWSepoch time
    toc
    end

     save('SWSepochs','SWSepochs')
    clearvars  SWSepochs

 
end
