%PURPOSE: Calculate Mean Theta and Gamma Power pre-experience
%
%INPUT: 
% 
% Filtered Theta and Gamma Data
% Times - an nx2 matrix of start and end times for each session of
% exploration 
% OUTPUT: 
% 
%
% L. Quigley
% Volk & Pfeiffer Lab
%========================================================================== 

    
Electrode_ID = 1;
load TimesSession
 
%% Load Theta filtered data 
Band = 'Theta'
Load_Label=sprintf('%s_CSC%d',Band,Electrode_ID);
load(Load_Label);
eval(sprintf('Complete_Power_Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

Complete_Power_Data = Complete_Power_Data(find(Complete_Power_Data(:,1)>TimesSession(1,1) & Complete_Power_Data(:,1)<TimesSession(1,2)),:);

% remove any time points with clipped signal 
LFP1_Name=sprintf('CSC%d.ncs',Electrode_ID);
LFP1_Frequency=Nlx2MatCSC(LFP1_Name,[0 0 1 0 0],0,3,1);
LFP_Frequency=LFP1_Frequency;
clear LFP1_Frequency;

LFP1_Samples=Nlx2MatCSC(LFP1_Name,[0 0 0 0 1],0,1);
LFP1_Samples=LFP1_Samples(:);
%LFP_Samples=LFP_Samples(:)*(Max_Range/Max_Value);

%If the recording frequency and total sample number are the same, the program assumes the timepoint of each sample is the same, so it only loads the timestamps of the first electrode and uses that for both 
LFP_Times=Nlx2MatCSC(LFP1_Name,[1 0 0 0 0],0,1)/1000000;
Times=zeros(512,size(LFP_Times,2));
for B=1:length(LFP_Times)-1
    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';   
end
 clear B;   
Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
LFP_Times=Times(:);
clear Times;

LFP1_Header=Nlx2MatCSC(LFP1_Name,[0 0 0 0 0],1,1,0);
for Header_Line=1:length(LFP1_Header)
    Header_Info=cell2mat(LFP1_Header(Header_Line));
    if length(Header_Info)>12
        if strcmp(Header_Info(1:11),'-ADMaxValue')
            LFP1_Max_Value=str2num(Header_Info(13:end));
        end
        if strcmp(Header_Info(1:11),'-InputRange')
            LFP1_Max_Range=str2num(Header_Info(13:end));
        end
    end
end

%This identifies segments of the recording where either the signal or the reference electrode is clipped (above or below the maximum recording value) 
%These segments aren't removed yet because it would interfere with the filtering to append two distant segments, so these are removed after filtering 
Timepoints_To_Remove=LFP_Times(LFP1_Samples==LFP1_Max_Value | LFP1_Samples==(-LFP1_Max_Value)); %| LFP2_Samples==LFP2_Max_Value | LFP2_Samples==(-LFP2_Max_Value));
Timepoints_To_Remove=[Timepoints_To_Remove-1,Timepoints_To_Remove+1];
Timepoints_To_Remove(:,3)=1;
for N=1:(size(Timepoints_To_Remove,1)-1)
    if Timepoints_To_Remove((N+1),1)<=Timepoints_To_Remove(N,2)
        Timepoints_To_Remove(N,3)=0;
        Timepoints_To_Remove((N+1),1)=Timepoints_To_Remove(N,1);
    end
end
Timepoints_To_Remove=Timepoints_To_Remove(Timepoints_To_Remove(:,3)==1,1:2);

for N=1:size(Timepoints_To_Remove,1)
    Complete_Power_Data=Complete_Power_Data(Complete_Power_Data(:,1)<Timepoints_To_Remove(N,1) | Complete_Power_Data(:,1)>Timepoints_To_Remove(N,2),:);      
end
% Calculate Mean Theta Power   
save('Theta-PreExperience','Complete_Power_Data')
ThetaHomeCage = mean(Complete_Power_Data(:,3));
clearvars -except Electrode_ID TimesSession D ThetaHomeCage LowGammaHomeCage HighGammaHomeCage Timepoints_To_Remove

% Load LowGamma filtered data 
Band = 'LowGamma'
Load_Label=sprintf('%s_CSC%d',Band,Electrode_ID);
load(Load_Label);
eval(sprintf('Complete_Power_Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

Complete_Power_Data = Complete_Power_Data(find(Complete_Power_Data(:,1)>TimesSession(1,1) & Complete_Power_Data(:,1)<TimesSession(1,2)),:);

% Calculate Mean LowGamma Power  
save('LowGamma-PreExperience','Complete_Power_Data')
LowGammaHomeCage = mean(Complete_Power_Data(:,3));
clearvars -except Electrode_ID TimesSession D ThetaHomeCage LowGammaHomeCage HighGammaHomeCage Timepoints_To_Remove

% Load HighGamma filtered data 
Band = 'HighGamma'
Load_Label=sprintf('%s_CSC%d',Band,Electrode_ID);
load(Load_Label);
eval(sprintf('Complete_Power_Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

Complete_Power_Data = Complete_Power_Data(find(Complete_Power_Data(:,1)>TimesSession(1,1) & Complete_Power_Data(:,1)<TimesSession(1,2)),:);

%Calculate Mean HighGamma Power    
save('HighGamma-PreExperience','Complete_Power_Data')
HighGammaHomeCage = mean(Complete_Power_Data(:,3));
clearvars -except Electrode_ID TimesSession D ThetaHomeCage LowGammaHomeCage HighGammaHomeCage Timepoints_To_Remove
  
 toc
 clearvars -except D ThetaHomeCage LowGammaHomeCage HighGammaHomeCage 
%cd ..


