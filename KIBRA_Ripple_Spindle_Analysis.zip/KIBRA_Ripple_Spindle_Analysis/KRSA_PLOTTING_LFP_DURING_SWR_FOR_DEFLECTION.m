% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This routine assumes you have already calculated the sharp wave 
% deflection for each subject and generates a plot for a group of 
% subjects
% Inputs:
% Sharp_Wave_Deflection_Per_Tetrode
% Combined_Ripple_LFP_Data
% Outputs: 
%
% Volk & Pfeiffer Lab 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------          
 
%% Find average for each subject 

D = dir('G:\Current_Kc_Analysis\WT'); % Input directory containing files 
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));
iterCount = 0;
for k = 1:numel(D)
    currD = D(k).name;
    cd(currD);
    
% Load average LFP Data for all pre experience SWRs
load Sharp_Wave_Deflection_Per_Tetrode
load Combined_Ripple_LFP_Data

Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3),'omitnan'),[3,1,2]);

%[~,Deep_To_Superficial_Tetrode_Order]=sortrows(Sharp_Wave_Deflection_Per_Tetrode,'descend');
[Deep_To_Superficial_Tetrodes(k)]=Sharp_Wave_Deflection_Per_Tetrode;

cd ..
clearvars -except D K Deep_To_Superficial_Tetrodes

end

[~,Deep_To_Superficial_Tetrode_Order]=sortrows(Deep_To_Superficial_Tetrodes','descend');


%%


Deep_To_Superficial_Tetrode_Order = Deep_To_Superficial_Tetrode_Order'
D = dir('G:\Current_Kc_Analysis\WT');
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'})); 
for N=1:length(Deep_To_Superficial_Tetrode_Order)
    currD = D(N).name;
    cd(currD);
    load Combined_Ripple_LFP_Data
    [Combined_All_Ripple_LFP_Data_2(:,1)] = [Combined_All_Ripple_LFP_Data(:,1)];
    [Combined_All_Ripple_LFP_Data_2(:,N+1)] = [Combined_All_Ripple_LFP_Data(:,2)];
     
cd ..
end


%% Generate figure 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;

% D = dir('G:\Current_Kc_Analysis\WT');
% dirFlags = [D.isdir];
% D = D(dirFlags);
% D = D(~ismember({D.name}, {'.', '..'})); 
for N=1:length(Deep_To_Superficial_Tetrode_Order)
%     currD = D(N).name;
%     cd(currD);
    %load Combined_Ripple_LFP_Data
   plot(Combined_All_Ripple_LFP_Data_2(:,1),Combined_All_Ripple_LFP_Data_2(:,(Deep_To_Superficial_Tetrode_Order(N)+1))-(N*50),'Color',[1-(N/(length(Deep_To_Superficial_Tetrode_Order))),0,N/(length(Deep_To_Superficial_Tetrode_Order))],'LineWidth',2);
    % plot(Combined_All_Ripple_LFP_Data_2(:,1),Combined_All_Ripple_LFP_Data_2(:,N));
%cd ..
end
set(gca,'XLim',[-0.25 0.25]);
%set(gca,'XTick',[]);
%set(gca,'YTick',[]);
%Y_Lim=ylim;

















