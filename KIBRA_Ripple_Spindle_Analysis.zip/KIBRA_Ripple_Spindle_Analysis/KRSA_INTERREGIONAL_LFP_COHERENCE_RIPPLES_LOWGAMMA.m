function KRSA_INTERREGIONAL_LFP_COHERENCE_RIPPLES_LOWGAMMA(Electrode1_ID,Electrode2_ID,Ripples,Dirname)
tic
%==========================================================================
% %% FUNCTION:
% This function assumes that you have already filtered the raw LFP data in
% the ripple band and low gamma bands.  It also assumes
% that you have made a variable called Ripples that lists the start and end
% timepoint of each experimental Ripple.  Finally, it assumes that you've
% already run FIND_RIPPLE_EVENTS_MOUSE to detect the start and end of all
% ripple events for each Ripple. (This function will use the standard limit
% of 5 st. dev. for ripple detection.)
% 
% This function loads up the filtered data for the two electrodes defined
% above (if Electrode1_ID is 23, then Electrode 1 will be CSC23).  It then
% calculates phase-phase coherence low gamma coherence during detected SWRs
%
% INPUT: 
%  Electrode_ID1 = ID of first electrode of interest
%  Electrode_ID2 = ID of first electrode of interest 
%  Ripples = n x 3 file containing Start, end and peak times  
%  Dirname = Name of directory for saving files 

% OUTPUT: 
%Phase_Phase_Coherence.mat
%LowGamma_Coherence_During SWRs.mat 
%
% LDQ 01/2022
% Volk & Pfeiffer Lab

%==========================================================================

% Because these files can be very large, I need to load each file and then
% select each Ripple individually.  This slows the program down a little,
% but allows all of the filtered LFPs to be loaded at once.

%Now, I calculate the phase offset/coherence for all three frequency bands during
%each defined time window across the two brain regions.

    Bin_Size=0.1;           % The size of each time bin (in seconds)
    Start_Time= -0.45;        % The time (in seconds) from the start of each event to start calculating gamma Coherence
    End_Time= 0.45;           % The time (in seconds) from the start of each even to stop calculating gamma Coherence
    Time_Bins=Start_Time:Bin_Size:End_Time;

    Gamma_Coherence_Per_SWR_2to1=zeros(size(Ripples,1),length(Time_Bins)-1);
    Mean_Gamma_Coherence_Per_SWR_2to1=zeros(size(Ripples,1),1);
    Weighted_Mean_Gamma_Coherence_Per_SWR_2to1 = zeros(size(Ripples,1),1);
    Peak_Phase_Gamma_Offset=zeros(size(Ripples,1),1);
    Mean_Length_Gamma_Coherence_Per_SWR_2to1=zeros(size(Ripples,1),1);
    
    
    eval(sprintf('Phase_Phase_LowGamma_%d_to_%d_Ripple=[];',Electrode2_ID,Electrode1_ID));
    Just_The_Ripple_Gamma_Coherence_All = [];
    Phase_Phase_LowGamma_2to1_Ripple = [] ;
                 
    %Load Low Gamma filtered data for first electrode
    eval(sprintf('load LowGamma_CSC%d;',Electrode1_ID));
    eval(sprintf('LowGamma_1=LowGamma_CSC%d;',Electrode1_ID));
    eval(sprintf('clear LowGamma_CSC%d;',Electrode1_ID));
    
    %Load Low Gamma filtered data for second electrode
    eval(sprintf('load LowGamma_CSC%d;',Electrode2_ID));
    eval(sprintf('LowGamma_2=LowGamma_CSC%d;',Electrode2_ID));
    eval(sprintf('clear LowGamma_CSC%d;',Electrode2_ID));
    
    All_ISPCs = [];
    phaseDiffsAll = [];
    Mean_Per_Rpl = [];
    BL_Vals =[];
    
for Ripple=1:size(Ripples,1)
     
    %Find Baseline 
    % Baseline_idx = find(LowGamma_1(:,1)>=Ripples(Ripple,1)-.45 & LowGamma_1(:,1)<=Ripples(Ripple,1)-.4);
    
    %Get SWR associated Low Gamma
    LowGamma_1_Ripple=LowGamma_1(LowGamma_1(:,1)>=Ripples(Ripple,1)+Start_Time & LowGamma_1(:,1)<=Ripples(Ripple,1)+End_Time,:);
    LowGamma_2_Ripple=LowGamma_2(LowGamma_2(:,1)>=Ripples(Ripple,1)+Start_Time & LowGamma_2(:,1)<=Ripples(Ripple,1)+End_Time,:);
    
    % Obtain Phase angle Time series, Output in radians  
    LowGamma_1_Ripple(:,4) = angle(hilbert(LowGamma_1_Ripple(:,2)));%*180/pi)+180;
    LowGamma_2_Ripple(:,4) = angle(hilbert(LowGamma_2_Ripple(:,2)));%*180/pi)+180;
  
    % Restrict Gamma data only during the ripple
    LowGamma_1_JustRipple=LowGamma_1_Ripple(LowGamma_1_Ripple(:,1)>=Ripples(Ripple,1) & LowGamma_1_Ripple(:,1)<=Ripples(Ripple,2),:);
    LowGamma_2_JustRipple=LowGamma_2_Ripple(LowGamma_2_Ripple(:,1)>=Ripples(Ripple,1) & LowGamma_2_Ripple(:,1)<=Ripples(Ripple,2),:);
    
   % Create a Directory to save the data
    if exist('Phase_Coherence','dir')==0
        mkdir Phase_Coherence
    end
    cd Phase_Coherence
    if exist(sprintf('%s',Dirname),'dir')==0
         mkdir(sprintf('%s',Dirname))
    end
    cd(sprintf('%s',Dirname))
    
  % Calculate Phase difference between electrodes 1 and 2 (Radians)
    Low_Gamma_Phase_Difference=[LowGamma_1_Ripple(:,1) (LowGamma_2_Ripple(:,4)-LowGamma_1_Ripple(:,4))];
    %Low_Gamma_Phase_Difference(Low_Gamma_Phase_Difference(:,2)<0,2)=Low_Gamma_Phase_Difference(Low_Gamma_Phase_Difference(:,2)<0,2)+360;
   
   % Eulerized phase differences
    %Note: In Radians
    phaseDiffs = exp(1i*(LowGamma_2_JustRipple(:,4)-LowGamma_1_JustRipple(:,4)));
    % ISPC
    ispc = abs(mean(phaseDiffs));
   
    All_ISPCs = [All_ISPCs;ispc];
    phaseDiffsAll = [phaseDiffsAll;(LowGamma_2_JustRipple(:,4)-LowGamma_1_JustRipple(:,4))];
    Phase_Phase_LowGamma_2to1_Ripple = [Phase_Phase_LowGamma_2to1_Ripple;[LowGamma_2_JustRipple(:,4),LowGamma_1_JustRipple(:,4)]] ;

    Ripple_Gamma_Coherence= [Low_Gamma_Phase_Difference]; % Note:radians
    Just_The_Ripple_Gamma_Coherence=Ripple_Gamma_Coherence(Ripple_Gamma_Coherence(:,1)>=Ripples(Ripple,1) & Ripple_Gamma_Coherence(:,1)<=Ripples(Ripple,2),:);
    %Just_The_Ripple_Gamma_Coherence_All = [Just_The_Ripple_Gamma_Coherence_All;Just_The_Ripple_Gamma_Coherence]; % Will contain phase offsets for all timepoints
    %Ripple_Gamma_Coherence(:,1)=Ripple_Gamma_Coherence(:,1)-Ripples(Ripple,1);

    %Calculate mean phase offset during SWR
%     [Weighted_Mean,Peak_Phase] = get_weightedmean_pk(Just_The_Ripple_Gamma_Coherence(:,2),36);
%     Weighted_Mean_Gamma_Coherence_Per_SWR_2to1(Ripple,1)=Mean_Gamma_Coherence_Per_SWR_2to1(Ripple,1)+Weighted_Mean;
%     Peak_Phase_Gamma_Offset(Ripple,1) = Peak_Phase_Gamma_Offset(Ripple,1)+Peak_Phase;
    Mean_Gamma_Coherence_Per_SWR_2to1(Ripple,1)=Mean_Gamma_Coherence_Per_SWR_2to1(Ripple,1)+circ_mean(Just_The_Ripple_Gamma_Coherence(:,2));                  

     %                     % Calculate coherence for binned data using ISPC
%                     phaseDiffs = Ripple_Gamma_Coherence;
%                       for Current_Bin=1:(length(Time_Bins)-1)
%                           %bin = circ_r(circ_ang2rad(Ripple_Gamma_Coherence(Ripple_Gamma_Coherence(:,1)>=Time_Bins(Current_Bin) & Ripple_Gamma_Coherence(:,1)<=Time_Bins(Current_Bin+1),2))); 
%                           %Gamma_Coherence_Per_SWR_2to1_bin(Current_Bin,1)= bin; 
%                          phaseDiffsBin = phaseDiffs(Ripple_Gamma_Coherence(:,1)>=Time_Bins(Current_Bin) & Ripple_Gamma_Coherence(:,1)<=Time_Bins(Current_Bin+1),2);                          
%                          Eulerized_phaseDiffsBin = exp(1i*(phaseDiffsBin));                                                               
%                          ispc = abs(mean(Eulerized_phaseDiffsBin));                     
%                          Gamma_Coherence_Per_SWR_2to1_bin(:,Current_Bin)=Gamma_Coherence_Per_SWR_2to1_bin(:,Current_Bin)+ispc;    
%                              % Gamma_Coherence_Per_SWR_2to1_bin(:,Current_Bin)=Gamma_Coherence_Per_SWR_2to1_bin(:,Current_Bin)+(circ_r(circ_ang2rad(Ripple_Gamma_Coherence(Ripple_Gamma_Coherence(:,1)>=Time_Bins(Current_Bin) & Ripple_Gamma_Coherence(:,1)<=Time_Bins(Current_Bin+1),2)))); 
%                            %clearvars C
%                             %clearvars phaseDiffs
%                       end
      
  %Gamma_Coherence_Per_SWR_2to1(Ripple,:)=[Gamma_Coherence_Per_SWR_2to1_bin];               
  %clearvars C              
  cd .. 
  cd ..
end


cd Phase_Coherence
cd(sprintf('%s',Dirname))
%save('Phase_Phase_Coherence','Phase_Phase_LowGamma*','Just_The_Ripple_Gamma_Coherence_All','All_ISPCs','Test_PLIs','Test_PPC','Peak_Phase_Gamma_Offset','phaseDiffsAll','BL_Vals')
save('Phase_Phase_Coherence','Phase_Phase_LowGamma*','Just_The_Ripple_Gamma_Coherence_All','Peak_Phase_Gamma_Offset','phaseDiffsAll','BL_Vals')
save('LowGamma_Coherence_During SWRs','Gamma_Coherence_Per_SWR_2to1','Mean_Gamma_Coherence_Per_SWR_2to1','Weighted_Mean_Gamma_Coherence_Per_SWR_2to1','Mean_Length_Gamma_Coherence_Per_SWR_2to1','All_ISPCs')
clearvars -except Dirname Ripples Electrode2_ID Electrode1_ID


cd ..
cd ..
toc


    %angles1 = angle(hilbert(LowGamma_1_JustRipple(:,2)));
    %angles2 = angle(hilbert(LowGamma_2_JustRipple(:,2)));
    %phaseDiffs = exp(1i*(angles2-angles1));
    
    
     %Calculate MRVL
    %Mean_Length_Gamma_Coherence_Per_SWR_2to1(Ripple,1)=Mean_Length_Gamma_Coherence_Per_SWR_2to1(Ripple,1)+circ_r(Just_The_Ripple_Gamma_Coherence(:,2));
    %Peak_Gamma_Coherence_Per_SWR(Ripple,1)=Peak_Gamma_Coherence_Per_SWR(Ripple,1)+max(Just_The_Ripple_Gamma_Coherence(:,2));
    %clearvars C
           
    %Gamma_Coherence_Per_SWR_2to1_bin = zeros(1,length(Time_Bins)-1);
                    


