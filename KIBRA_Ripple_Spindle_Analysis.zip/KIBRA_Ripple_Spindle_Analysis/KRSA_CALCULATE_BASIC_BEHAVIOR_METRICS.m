%PURPOSE: Calculate basic exploration metrics from position data
%
%INPUT: 
% Position_Data - nx3 matrix of times, x, and y positions(cm)
% Times - an nx2 matrix of start and end times for each session of
% exploration 
% Active - nx3 matrix of start times, end times and duration of periods 
% when mouse is moving>3cm/s
% 
%
% LD Quigley
% Volk & Pfeiffer Lab
%========================================================================== 

Total_Distance = [];
Mean_Distance = [];

Overall_Mean_Velocity = [];

Overall_Mean_Time = [];
Overall_Total_Time = [];


%% Calculate distance traveled 

 tic
 load TimesSession
 load('Processed_Position_Data_Smoothed.mat')
 for s = 2:5
 Time_Start = Times(s,1);
 [Distance_Moved]=CALCULATE_DISTANCE(Position_Data,Time_Start);
 eval(sprintf('Distance_Moved%d=sum(Distance_Moved);',s));
 clearvars Distance_Moved Time_Start
 end
 % Calculate sum, calculate average distance travelled
 Session_Distance = [Distance_Moved2;Distance_Moved3;Distance_Moved4;Distance_Moved5];
 Total_Distance = sum(Session_Distance);
 Mean_Distance = mean(Session_Distance);

 clearvars s

 toc
%% Calculate mean velocity for each session 
  
load TimesSession
load('Processed_Position_Data_Smoothed.mat')
Velocity = CALCULATE_VELOCITY(Position_Data);

Smoothed_Velocity = smoothdata(Velocity);
Smoothed_Velocity = [Position_Data(:,1),Smoothed_Velocity];

for s = 2:5
Time_Start = Times(s,1);
Time_End = Times(s,2);
Velocity_Session = Smoothed_Velocity(Smoothed_Velocity(:,1)>Time_Start & Smoothed_Velocity(:,1)<=Time_End,:);
Velocity_Mean = mean(Velocity_Session(:,2));
eval(sprintf('Velocity_Mean%d=Velocity_Mean;',s));
end

Overall_Velocity  = [Velocity_Mean2;Velocity_Mean3;Velocity_Mean4;Velocity_Mean5];
Overall_Mean_Velocity = mean(Overall_Velocity);


  
%% Calculate total time spent in active state
  
 for s = 2:5
 load('Active.mat', sprintf('active%d',s));
 eval(sprintf('active=active%d;',s));
 Time_Active = sum(active(:,3));
 eval(sprintf('Time_Active%d=Time_Active;',s));
 end
  
Overall_Time  = [Time_Active2;Time_Active3;Time_Active4;Time_Active5];
Overall_Mean_Time = mean(Overall_Time);
Overall_Total_Time = sum(Overall_Time);

