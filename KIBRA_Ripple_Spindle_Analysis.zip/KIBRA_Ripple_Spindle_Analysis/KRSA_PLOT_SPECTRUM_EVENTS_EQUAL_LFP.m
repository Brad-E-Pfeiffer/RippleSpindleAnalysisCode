function [] = Plot_Spectrum_Events_Equal_LFP(Electrode_ID,State_file,Epoch_var,Epoch_num,equal)

%Purpose: to compute the average power spectrum for a series of epochs or trials
%using the Chronux mutitaper method 
%Inputs: 

%   Electrode_ID
%   State_File = n x 2 array with start and end times for epochs
%   Epoch_var = variable within State_File to analyze
%   movingwin = [window winstep] i.e length of moving
%              window and step size. Note that units here have
%              to be consistent with units of Fs. If Fs=1 (ie normalized)
%              then [window winstep]should be in samples, or else if Fs is
%              unnormalized then they should be in time (secs). 
%   sMarkers = N x 2 array of segment start & stop marks. sMarkers(n, 1) = start
%           sample index; sMarkers(n,2) = stop sample index for the nth segment
%  Epoch_num = number of Epoch_var in state_file
%Freq_range = desired frequency range 
% equal - if equal length desired 0, if unequal then 1
   

 %Output:

 %      S       frequency x channels
 %      f       frequencies x 1
  %     Serr    (error bars) only for err(1)>=1




%% 
Load_Label=sprintf('CSC%d',Electrode_ID);
load(Load_Label);
eval(sprintf('Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

y = find(Data(:,1));
y(:,2) = y/3200;
y(:,4) = y(:,2)*(1/60);
z = find(floor(y(:,4)) == y(:,4));
Data = Data(1:z(end),:);
dftfreq = [60-1*(1/10):(1/10):60+1*(1/10)];
[filtlfp1] = ft_preproc_dftfilter(Data(:,2)',3200,dftfreq,'dftreplace','neighbour');% remove 60 cycle
%[filtlfp2] = ft_preproc_dftfilter(lfp2(:,2)',3200,[59 60 61]);%,'dftreplace','neighbour');% remove 60 cycle
%[S,f,Serr]=mtspectrumc(filtlfp(16000:32000)',params);
Data=horzcat(Data(:,1),filtlfp1');



%% %% Firsst will remove timepoints with saturated signal from the filtered data

LFP1_Name=sprintf('CSC%d.ncs',Electrode_ID);
LFP1_Frequency=Nlx2MatCSC(LFP1_Name,[0 0 1 0 0],0,3,1);
LFP_Frequency=LFP1_Frequency;
clear LFP1_Frequency;

LFP1_Samples=Nlx2MatCSC(LFP1_Name,[0 0 0 0 1],0,1);
LFP1_Samples=LFP1_Samples(:);
%LFP_Samples=LFP_Samples(:)*(Max_Range/Max_Value);

%If the recording frequency and total sample number are the same, the program assumes the timepoint of each sample is the same, so it only loads the timestamps of the first electrode and uses that for both 
LFP_Times=Nlx2MatCSC(LFP1_Name,[1 0 0 0 0],0,1)/1000000;
Times=zeros(512,size(LFP_Times,2));
for B=1:length(LFP_Times)-1
    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';   
end
 clear B;   
Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
LFP_Times=Times(:);
clear Times;

LFP1_Header=Nlx2MatCSC(LFP1_Name,[0 0 0 0 0],1,1,0);
for Header_Line=1:length(LFP1_Header)
    Header_Info=cell2mat(LFP1_Header(Header_Line));
    if length(Header_Info)>12
        if strcmp(Header_Info(1:11),'-ADMaxValue')
            LFP1_Max_Value=str2num(Header_Info(13:end));
        end
        if strcmp(Header_Info(1:11),'-InputRange')
            LFP1_Max_Range=str2num(Header_Info(13:end));
        end
    end
end

%This identifies segments of the recording where either the signal or the reference electrode is clipped (above or below the maximum recording value) 
%These segments aren't removed yet because it would interfere with the filtering to append two distant segments, so these are removed after filtering 
Timepoints_To_Remove=LFP_Times(LFP1_Samples==LFP1_Max_Value | LFP1_Samples==(-LFP1_Max_Value)); %| LFP2_Samples==LFP2_Max_Value | LFP2_Samples==(-LFP2_Max_Value));
Timepoints_To_Remove=[Timepoints_To_Remove-1,Timepoints_To_Remove+1];
Timepoints_To_Remove(:,3)=1;
for N=1:(size(Timepoints_To_Remove,1)-1)
    if Timepoints_To_Remove((N+1),1)<=Timepoints_To_Remove(N,2)
        Timepoints_To_Remove(N,3)=0;
        Timepoints_To_Remove((N+1),1)=Timepoints_To_Remove(N,1);
    end
end
Timepoints_To_Remove=Timepoints_To_Remove(Timepoints_To_Remove(:,3)==1,1:2);

for N=1:size(Timepoints_To_Remove,1)
    Data=Data(Data(:,1)<Timepoints_To_Remove(N,1) | Data(:,1)>Timepoints_To_Remove(N,2),:);      
end
%% 

%State_file = 'TimesSession';
%Epoch_var = 'Times(1,:)';
%Epoch_num = 1;
for z = 1:Epoch_num
% for each epoch load the epoch variable from State_File

load(sprintf('%s',State_file))%,sprintf('%s%d',Epoch_var,z))
eval(sprintf('Epochs=%s%d;',Epoch_var,z));
Epochs=Epochs(Epochs(:,2)<Data(end,1),:);

%add min durations for equal length...
      
        if strcmp(State_file,'Immobility_1')==1
            %if ~isempty(find(Epochs(:,3)>=3))
            Epochs = Epochs(find(Epochs(:,3)>=3 & Epochs(:,3)<60),:);%min duration 3 sec
            %end
        elseif strcmp(State_file,'Active')==1
            if max(Epochs(:,3))>=2
             Epochs = Epochs(find(Epochs(:,3)>=2),:);
            end
        elseif strcmp(State_file,'Altactive_2')==1
            if max(Epochs(:,3))>=3
             Epochs = Epochs(find(Epochs(:,3)>=3),:);
            end
        elseif strcmp(State_file,'SWSepochsPreExp')==1
            if max(Epochs(:,3))>=20
             Epochs = Epochs(find(Epochs(:,3)>=20),:);
            end
        elseif strcmp(State_file,'SWSepochsPostExp')==1
            if max(Epochs(:,3))>=20
             Epochs = Epochs(find(Epochs(:,3)>=20),:);
            end
            
       end 
    if ~isempty(Epochs)
%Data = [];
    for i=1:size(Epochs,1)
        %Ripple_Peak = Detected_Ripples(i,3);
        if equal==1
           if strcmp(State_file,'Immobility_1')==1
               Start = Epochs(i,1);
                End = Start + 3;
            elseif strcmp(State_file,'Active')==1
               Start = Epochs(i,1);
                End = Start + 2;
            elseif strcmp(State_file,'Altactive_2')==1
                Start = Epochs(i,1);
                End = Start + 3;
            elseif strcmp(State_file,'SWSepochsPreExp')==1
                End = Start + 10;
             elseif strcmp(State_file,'SWSepochsPostExp')==1
                End = Start + 10;
            elseif strcmp(State_file,'REMepochsPreExp')==1
                End = Start + 5;
            elseif strcmp(State_file,'REMepochsPostExp')==1
                End = Start + 5;
           end
      

        idx = find(Data(:,1)>= Start & Data(:,1)<=End);
        LFP_Data =  Data(idx,2);

        clearvars Start End
        elseif equal==0  
            LFP_Data = Data(Data(:,1)>=Epochs(i,1) & Data(:,1)<=Epochs(i,2),1:2);
            
        end

        if exist('LFP_Data','var') 
        eval(sprintf('LFP_Data%d=LFP_Data;',i));
        clearvars LFP_Data
        
        end
    end
   

clear LFP_Data
varnames = who('LFP_Data*');
B = regexp(varnames,'\d*','Match');
for ii= 1:length(B)
    if ~isempty(B{ii})
        Num(ii,1)=str2double(B{ii}(end));
    else
        Num(ii,1)=0;
    end
        Num=(ii~=NaN);
        %Num=(ii~NaN);try ~isnan(ii) or isnan(ii)==0
end
%test = [B{:}]
test = cellfun(@str2double,B'); %Need to examine and make sure these are pasted in right direction 

test = sort(test);

if equal==1
    LFP_Data_Cat = [];
    for k = [test]
     if length(eval(sprintf('LFP_Data%d;',k))) >= length(LFP_Data1)
    eval(sprintf('LFP_Data_Cat=[LFP_Data_Cat,LFP_Data%d(1:length(LFP_Data1));];',k));
     end
    end
end

%Ripple_LFP_Data = [];
if equal==0
LFP_Data_Cat = [];
    for k = [test]
        if size(eval(sprintf('LFP_Data%d;',k)),1)>0
        eval(sprintf('LFP_Data_Cat=[LFP_Data_Cat;LFP_Data%d;];',k));
        end
    end
    for i=1:size(Epochs,1)
        if size(eval(sprintf('LFP_Data%d;',i)),1)>0
        %if Epochs(i,1)==0
        %else
        [~,idx] = min(abs(LFP_Data_Cat(:,1)-Epochs(i,1)));
        %Epoch_Start = find(LFP_Data_Cat(:,1)==Epochs(i,1));
        Epoch_Start = idx;
        [~,idx] = min(abs(LFP_Data_Cat(:,1)-Epochs(i,2)));
        Epoch_End = idx;

        sMarkers(i,1:2) = [Epoch_Start,Epoch_End];
        else
        sMarkers(i,1:2) = [0,0];
        end
    end
    sMarkers = sMarkers(find(sMarkers(:,1)>0),:);
end 
    
 
params.Fs=3200;
%Here we will define the frequency range for the power spectrum
params.fpass=[.5 140];
params.tapers = [5 9];
params.trialave=1; p=0.05; 
params.err=[2 p]; 
%movingwin = [1 1];

if equal==1
    [S,f,Serr]= mtspectrumc(LFP_Data_Cat,params);
end
% This function from Chronux will generate the spectrum(S) and frequency
% range(f)
if equal==0
movingwin = [.5 .5];
[S,f,Serr]= mtspectrumc_unequal_length_trials(LFP_Data_Cat(:,2),movingwin,params,sMarkers);
end


%Plot data with jacknife error confidence bounds

figure
%plot(f,10*log10(Serr(1,:)),'r');
%hold on
%plot(f,10*log10(Serr(2,:)),'r');
%hold on
%plot(f,10*log10(S));

if ~exist(sprintf('./Power_Spectrum/LFP_Spectrum/New/%s',State_file),'dir')
    mkdir(sprintf('./Power_Spectrum/LFP_Spectrum/New/%s',State_file))
    cd(sprintf('./Power_Spectrum/LFP_Spectrum/New/%s',State_file))
else
    cd(sprintf('./Power_Spectrum/LFP_Spectrum/New/%s',State_file))
end 

ha = shadedplot(f,10*log10(Serr(1,:)),10*log10(Serr(2,:)),[0.7 0.7 1], 'b');
ylim([min(10*log10(S))-5 max(10*log10(S))+5])
hold on
plot(f ,10*log10(S),'-w','LineWidth',.25)

hold on
title(sprintf('Spectrum_%s_%d',State_file,z))
ylabel('Power','FontSize',14)
xlabel('Frequency Hz','FontSize',14)
%PeakFreq = f(find(S == max(S)));
%txt = ['Peak Frequency= ' num2str(PeakFreq) 'Hz'];
%text(median(f),max(10*log10(S))+1.5,txt,'horizontalalignment','center')
savefig(sprintf('Spectrum-%s-Elec%d-%d-EQ(%d)',Epoch_var,Electrode_ID,z,equal))
%saveas(gcf,sprintf('Ripple_Spectrum%d.fig',i)); % will create FIG1, FIG2,...
close
%save(sprintf('%s-Elec%d-E%d-EQ(%d)=Epochs',State_file,Electrode_ID,z,equal),'S','f','Serr','LFP_Data_Cat')
save(sprintf('%s%d-EQ(%d)',Epoch_var,z,equal),'S','f','Serr','LFP_Data_Cat')
%'Spectrum_Data'
cd ..
cd ..
cd ..
cd ..
clearvars -except LFP_Electrodes D Data State_file Epoch_var Epoch_num z equal Electrode_ID
   end

end

