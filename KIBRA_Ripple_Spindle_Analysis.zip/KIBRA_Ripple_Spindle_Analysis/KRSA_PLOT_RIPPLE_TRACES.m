function [] = Plot_Ripple_Traces_for_fig(start_time,Electrode_ID,Ripple_Data_Cat,nsec)
%Plot Ripple Traces
%
% 
% Assign variable for electrode ID

% Define start and end 

end_time = start_time+nsec;

%load Raw LFP data and extract 2 seconds
Load_Label=sprintf('CSC%d',Electrode_ID);
load(Load_Label);
eval(sprintf('LFP_Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

[~,startidx] = min(abs(LFP_Data(:,1)-start_time));
%startidx = find(LFP_Data(:,1)==start_time)
endidx = startidx+(3200*nsec);

% extract 2 seconds of this data
LFP_Subset = LFP_Data(startidx:endidx,:);
LFP_Subset(:,1) = LFP_Subset(:,1)-LFP_Data(startidx,1);

% plot this 2 seconds of LFP data as a function of time 
subplot(2,1,1)
plot(LFP_Subset(:,1),LFP_Subset(:,2),'k');
set(gca,'XLim',[0 nsec]);
set(gca,'YLim',[-1000 1000]);


Ripples = Ripple_Data_Cat(find(Ripple_Data_Cat(:,1)>=start_time & Ripple_Data_Cat(:,2)<=end_time),:);

hold on
for i = 1:size(Ripples,1)
    Data = LFP_Data(find(LFP_Data(:,1)>=Ripples(i,1) & LFP_Data(:,1)<=Ripples(i,2)),:)
    Data(:,1) = Data(:,1)-LFP_Data(startidx,1);
    plot(Data(:,1),Data(:,2),'r')
    clearvars Data
end


%load Ripple data and extract 2 seconds
Load_Label=sprintf('Ripple_CSC%d',Electrode_ID);
load(Load_Label);
eval(sprintf('Ripple_Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

% extract 2 seconds of this data
Ripple_Subset = Ripple_Data(startidx:endidx,:);
Ripple_Subset(:,1) = Ripple_Subset(:,1)-Ripple_Data(startidx,1);
% plot this 2 seconds of LFP data as a function of time 
subplot(2,1,2)
plot(Ripple_Subset(:,1),Ripple_Subset(:,2),'k');
set(gca,'XLim',[0 nsec]);
set(gca,'YLim',[-300 300]);


%load Low Gamma data and extract 2 seconds
%Load_Label=sprintf('LowGamma_CSC%d',Electrode_ID);
%load(Load_Label);
%eval(sprintf('LowGamma_Data=%s;',Load_Label));
%eval(sprintf('clear %s;',Load_Label));

% extract 2 seconds of this data
%LowGamma_Subset = LowGamma_Data(start_time:end_time,:);
%LowGamma_Subset(:,1) = LowGamma_Subset(:,1)-LowGamma_Data(start_time,1);
% plot this 2 seconds of LFP data as a function of time 
%subplot(4,1,2)
%plot(LowGamma_Subset(:,1),LowGamma_Subset(:,2),'g');


end
