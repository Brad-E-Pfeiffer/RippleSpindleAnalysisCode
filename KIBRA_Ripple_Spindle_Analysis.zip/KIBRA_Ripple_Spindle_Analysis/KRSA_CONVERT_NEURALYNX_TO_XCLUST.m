function KRSA_CONVERT_NEURALYNX_TO_XCLUST

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This program will load the Neuralynx tetrode spike data and video
% position data and convert this into a file that Xclust can load.
%
% Tetrodes_To_Convert is a numerical list of the tetrode numbers.
% Video_String is a string that names the raw position data from Neuralynx.
% Start_Time and End_Time are single numbers that mark the start and end
% timepoints (in seconds) to pull the spikes from.
%
% Example:  CONVERT_NEURALYNX_TO_XCLUST(1:10,'VT1.nvt',5600,8745);
%    This would convert tetrodes 1 through 10 using the VT1.nvt file for
%    position data, and would only convert spikes that happen between times
%    5600 and 8745 (the times are in seconds even though Neuralynx records
%    in microseconds -- this will be accounted for later in the program).
%
% To convert all of the timepoints, use the following line:
%          CONVERT_NEURALYNX_TO_XCLUST(1:10,'VT1.nvt','start','end');
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

for Genotype=1:2
    for Mouse=1:6
        if Genotype==1
            cd WT
        else
            cd KO
        end
        if Genotype==1 && Mouse==1 %WT-KcAug19-2 was already converted using the program below
            cd WTMouse1
        elseif Genotype==1 && Mouse==2
            cd WT2Mouse
        elseif Genotype==1 && Mouse==3
            cd WTMouse3
        elseif Genotype==1 && Mouse==4
            cd WTMouse4
        elseif Genotype==1 && Mouse==5
            cd WTMouse5
        elseif Genotype==1 && Mouse==6
            cd WTMouse6
        elseif Genotype==2 && Mouse==1
            cd KOMouse1
        elseif Genotype==2 && Mouse==2
            cd KOMouse2
        elseif Genotype==2 && Mouse==3
            cd KOMouse3
        elseif Genotype==2 && Mouse==4
            cd KOMouse4
        elseif Genotype==2 && Mouse==5
            cd KOMouse5
        elseif Genotype==2 && Mouse==6
            cd KOMouse6
        end            

        % If the user did not fully define the input variables, the most likely
        % values are either searched for or automatically provided.
        Tetrodes_To_Convert=[2,3,6,7];
        Start_Timepoint='start';
        End_Timepoint='end';
        Interpolation=0;

        % This section loads the position information so that this informaton can
        % be attributed to the spikes prior to clustering.  If the
        % Load_Raw_Position_Information function has been run, there will be a
        % variable called "Position_Data", otherwise, the program will load the raw
        % position information and process it a little before attributing these
        % values to the spikes.
        load Raw_Position_Data;

        for Tetrode_Number=Tetrodes_To_Convert

            % This next section is just setting up the names of files and directories
            % to write the data to once it's been converted.  It also makes sure that
            % the tetrode file exists and has some real data in it.
            Tetrode_Name=sprintf('TT%d.ntt',Tetrode_Number);
            Tetrode_Directory=sprintf('Converted/tt%d',Tetrode_Number);
            Tetrode_File_Name=sprintf('tt%d.xclust',Tetrode_Number);
            if ~isfile(Tetrode_Name)
                continue
            end
            Directory_List=dir;

            %This section finds the file that matches the name of the tetrode to load
            for T=1:size(Directory_List,1)
                if strcmp(Directory_List(T).name,Tetrode_Name)
                    break
                end
            end

            %If the tetrode file is 20kb or smaller, don't bother loading it
            %because it might be completely empty and this will break the program
            if Directory_List(T).bytes<20000
                continue
            end
            clear Directory_List;
            clear T;

            % This next section pulls up the Neuralynx header information to determine
            % the parameters under which the data was stored.  This will give a value
            % termed "Bit_Conversion."  If you divide the amplitude of any response by
            % this value, you will get the actual uV of the response.
            [Header]=Nlx2MatSpike(Tetrode_Name,[0 0 0 0 0],1,3,1);
            for Header_Line=1:length(Header)
                Header_Info=cell2mat(Header(Header_Line));
                if length(Header_Info)>12
                    if strcmp(Header_Info(1:11),'-ADMaxValue')
                        Max_Value=str2num(Header_Info(13:end));
                    end
                    if strcmp(Header_Info(1:11),'-InputRange')
                        Max_Range=str2num(Header_Info(13:end));
                    end
                end
            end
            clear Header_Line
            clear Header_Info
            clear Header

            % This next section loads up the spike data using a program that Neuralynx
            % made called 'Nlx2MatSpike.'  It loads the spike times and the spike
            % parameters (eight values per spike that represent the max height and
            % minimum valley for each of the four tetrodes during that particular
            % spike).  You can read more about the Nlx2MatVT program in its help file.
            % The beginning and end of the spike times are "corrected" so that there
            % are no timepoints before the first position timepoint or after the
            % last position timepoint.
            %
            % This is now done below as the program loads the spike waveforms.
            %
            % This next section loads the spike waveforms using the same file as above,
            % Nlx2MatSpike.  The spike waveforms are each written as 32 data points.

            clear Spike_Times;
            clear Max_Height;
            clear Max_Width;
            clear Spike_Parameters;
            %Spike_Times is the timestamp of each spike, Spike_Parameters lists the peaks and minima of each spike on all four tetrodes
            [Spike_Times,Spike_Waves]=Nlx2MatSpike(Tetrode_Name,[1 0 0 0 1],0,1);

            %Convert the times from microseconds to seconds
            Spike_Times=Spike_Times/1000000;

            %Find the max and min and duration (max to min)
            [Spike_Maximums,Spike_Maximum_Index]=max(Spike_Waves(1:round(size(Spike_Waves,1)/1.6),:,:));
            Spike_Maximums=permute(Spike_Maximums,[3,2,1]);
            Spike_Maximum_Index=permute(Spike_Maximum_Index,[3,2,1]);
            [Spike_Minimums,Spike_Minimum_Index]=min(Spike_Waves(round(size(Spike_Waves,1)/4):round(size(Spike_Waves,1)/1.28),:,:));
            Spike_Minimums=permute(Spike_Minimums,[3,2,1]);
            Spike_Minimum_Index=permute(Spike_Minimum_Index+7,[3,2,1]);
            Spike_Durations=Spike_Minimum_Index-Spike_Maximum_Index;  %in bins, not in ms
            clear Spike_Minimum_Index;
            clear Spike_Maximum_Index;
            Max_Height=max((Spike_Maximums-Spike_Minimums)')';
            Max_Width=max(Spike_Durations')';

            % The following section looks for any "dislocated" spikes. A dislocated
            % spike is one that has a timestamp that appears "out of order"
            % relative to the other spikes. I don't delete these data points.  This
            % happens occasionally when the hard drive is too full or too much data
            % is being written at once.
            Dislocated_Spike_Times=sum(diff(Spike_Times)<=0);
            Single_Dislocations=0;
            Multiple_Dislocations=0;
            if Dislocated_Spike_Times>0
                fprintf('Found %d single time dislocations and %d multiple time dislocations in the spike data for directory %d.\n',Single_Dislocations,Multiple_Dislocations,Data_Directory)
            end
            clear Single_Dislocations;
            clear Multiple_Dislocations;
            clear N;
            clear Temp_Max_Width;
            clear Temp_Max_Height;
            clear Max_Value;
            clear Max_Index;
            clear Min_Value;
            clear Min_Index;
            clear Temp_Spike_Times;
            clear Temp_Spike_Parameters;
            clear String;
            clear Dislocated_Spike_Times;

            % The following section determines the X- and Y-position information for
            % each spike by determining the closest timestamp in the position data and
            % pulling out the X- and Y-position data based on that timestamp.  This is
            % only used in the xclust2 program -- not in the actual analysis to
            % determine place fields.  This will just help you to see where your
            % cluster fires on the track, but this data won't be used later on in
            % subsequent analysis programs to actually calculate place fields.  I use a
            % more accurate algorithm for that.

            Histogram=histc(Position_Data(:,1),Spike_Times(1,:));
            Spike_Times_In_Position_Time=cumsum(Histogram);
            Spike_Times_In_Position_Time(Spike_Times_In_Position_Time==0)=1;
            Matched_Spike_Times=Position_Data(Spike_Times_In_Position_Time,1);
            Spike_X_Positions=Position_Data(Spike_Times_In_Position_Time,2);
            Spike_Y_Positions=Position_Data(Spike_Times_In_Position_Time,3);
            clear Spike_Times_In_Position_Times;
            clear Matched_Spike_Times;

            % This section writes the information to the file that Xclust can read.
            Current_Directory=pwd;
            if ~isfolder(Tetrode_Directory)
                mkdir(Tetrode_Directory);
            end
            cd(Tetrode_Directory);
            File_ID=fopen(Tetrode_File_Name,'w');
            File_String=sprintf('%%%%BEGINHEADER\n%% File type:    Binary\n%% Fields:     id,3,4,1     t_px,2,2,1     t_py,2,2,1     t_pa,2,2,1     t_pb,2,2,1     t_maxwd,2,2,1     t_maxht,2,2,1     time,5,8,1     pos_x,2,2,1     pos_y,2,2,1     velocity,4,4,1\n%%%%ENDHEADER\n');
            Count=fwrite(File_ID,File_String);
            for I=1:size(Spike_Times,2)
                Count=fwrite(File_ID,I,'uint32');
                Count=fwrite(File_ID,int16(Spike_Maximums(I,1)),'uint16'); %peak1
                Count=fwrite(File_ID,int16(Spike_Maximums(I,2)),'uint16'); %peak2
                Count=fwrite(File_ID,int16(Spike_Maximums(I,3)),'uint16'); %peak3
                Count=fwrite(File_ID,int16(Spike_Maximums(I,4)),'uint16'); %peak4
                Count=fwrite(File_ID,int16(Max_Width(I)),'uint16');  %max width
                Count=fwrite(File_ID,int16(Max_Height(I)),'uint16'); %max height
                Count=fwrite(File_ID,Spike_Times(1,I),'float64');  %time
                Count=fwrite(File_ID,Spike_X_Positions(I),'uint16'); %X-position
                Count=fwrite(File_ID,Spike_Y_Positions(I),'uint16'); %Y-positions
                Count=fwrite(File_ID,0,'float32'); %blank
            end
            fclose(File_ID);
            cd(Current_Directory)
            disp(sprintf('Finished tetrode %d of %d',Tetrode_Number,length(Tetrodes_To_Convert)));
        end

        cd ..
        cd ..

    end
end

end







