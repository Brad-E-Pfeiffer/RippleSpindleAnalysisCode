% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This routine assumes you have clustered your spike data and and 
% and detected ripple events and performs analysis of cell spiking
% during ripple events
% Inputs:
% All_Spike_Data
% Ripple_Data_Pre
% Ripple_Data_Post
% Times
%
% Outputs: 
% Ripple_Spiking_Analysis_Cells
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

clear all;

%==========================================================================
% Loading Spikes Manually Clustered
%==========================================================================

load All_Spike_Data

%==========================================================================
% Loading Ripple Events
%==========================================================================

load Times

load Ripple_Data_Pre
Pre_Ripple_Events=Ripple_Data_Pre(:,1:3);
clear Ripple_Data_Pre;
load Ripple_Data_Post
Post_Ripple_Events=Ripple_Data_Post(:,1:3);
clear Ripple_Data_Post;

% Pre/Post_Ripple_Participation
% |       1       |               2            |                    3               ||
% | Ripple Number | Percent Cell Participation | Firing Rate of Participating Cells ||

Pre_Ripple_Participation=zeros(size(Pre_Ripple_Events,1),3);
Post_Ripple_Participation=zeros(size(Post_Ripple_Events,1),3);

Total_Number_Of_Cells=length(unique(Spike_Data(:,2)));
for Current_Ripple=1:size(Pre_Ripple_Events,1)
    Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=Pre_Ripple_Events(Current_Ripple,1) & Spike_Data(:,1)<=Pre_Ripple_Events(Current_Ripple,2),:);
    if ~isempty(Ripple_Spike_Data)
        Ripple_Duration=Pre_Ripple_Events(Current_Ripple,2)-Pre_Ripple_Events(Current_Ripple,1);
        Number_Of_Participating_Cells=length(unique(Ripple_Spike_Data(:,2)));
        Pre_Ripple_Participation(Current_Ripple,:)=[Current_Ripple,Number_Of_Participating_Cells/Total_Number_Of_Cells,(size(Ripple_Spike_Data,1)/Number_Of_Participating_Cells)/Ripple_Duration];
    else
        Pre_Ripple_Participation(Current_Ripple,:)=[Current_Ripple,0,NaN];
    end
end
for Current_Ripple=1:size(Post_Ripple_Events,1)
    Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=Post_Ripple_Events(Current_Ripple,1) & Spike_Data(:,1)<=Post_Ripple_Events(Current_Ripple,2),:);
    if ~isempty(Ripple_Spike_Data)
        Ripple_Duration=Post_Ripple_Events(Current_Ripple,2)-Post_Ripple_Events(Current_Ripple,1);
        Number_Of_Participating_Cells=length(unique(Ripple_Spike_Data(:,2)));
        Post_Ripple_Participation(Current_Ripple,:)=[Current_Ripple,Number_Of_Participating_Cells/Total_Number_Of_Cells,(size(Ripple_Spike_Data,1)/Number_Of_Participating_Cells)/Ripple_Duration];
    else
        Post_Ripple_Participation(Current_Ripple,:)=[Current_Ripple,0,NaN];
    end
end

% Per_Cell_Mean_Firing_Rate
% |    1    |               2                 |                        3                   |                          4                         |                   5              |                  6               |                       7                      |                           8                         ||
% | Cell ID | Mean Firing Rate In Pre Ripples | Liklihood of Participating in a Pre Ripple | Mean Firing Rate When Participating in Pre Ripples | Mean Firing Rate During Behavior | Mean Firing Rate In Post Ripples | Likelihood of Participating in a Post Ripple | Mean Firing Rate When Participating In Post Ripples ||
Per_Cell_Mean_Firing_Rate=zeros(length(Total_Number_Of_Cells),8);
Cell_List=unique(Spike_Data(:,2));
for Current_Cell=1:Total_Number_Of_Cells
    Cell_Spike_Data=Spike_Data(Spike_Data(:,2)==Cell_List(Current_Cell),:);
    Pre_Cell_Spike_Data=Cell_Spike_Data(Cell_Spike_Data(:,1)>=Times(1,1) & Cell_Spike_Data(:,1)<=Times(1,2),:);
    Post_Cell_Spike_Data=Cell_Spike_Data(Cell_Spike_Data(:,1)>=Times(6,1) & Cell_Spike_Data(:,1)<=Times(6,2),:);
    On_Task_Cell_Spike_Data=Cell_Spike_Data(Cell_Spike_Data(:,1)>=Times(2,1) & Cell_Spike_Data(:,1)<=Times(5,2),:);
    Pre_Ripple_Firing_Rates=zeros(size(Pre_Ripple_Events,1),1);
    Post_Ripple_Firing_Rates=zeros(size(Post_Ripple_Events,1),1);
    On_Task_Mean_Firing_Rate=size(On_Task_Cell_Spike_Data,1)/(Times(5,2)-Times(2,1));
    for R=1:size(Pre_Ripple_Events,1)
        Ripple_Spikes=Pre_Cell_Spike_Data(Pre_Cell_Spike_Data(:,1)>=Pre_Ripple_Events(R,1) & Pre_Cell_Spike_Data(:,1)<=Pre_Ripple_Events(R,2),:);
        if ~isempty(Ripple_Spikes)
            Pre_Ripple_Firing_Rates(R,1)=size(Ripple_Spikes,1)/(Pre_Ripple_Events(R,2)-Pre_Ripple_Events(R,1));
        else
            Pre_Ripple_Firing_Rates(R,1)=0;
        end
    end
    for R=1:size(Post_Ripple_Events,1)
        Ripple_Spikes=Post_Cell_Spike_Data(Post_Cell_Spike_Data(:,1)>=Post_Ripple_Events(R,1) & Post_Cell_Spike_Data(:,1)<=Post_Ripple_Events(R,2),:);
        if ~isempty(Ripple_Spikes)
            Post_Ripple_Firing_Rates(R,1)=size(Ripple_Spikes,1)/(Post_Ripple_Events(R,2)-Post_Ripple_Events(R,1));
        else
            Post_Ripple_Firing_Rates(R,1)=0;
        end
    end
    Per_Cell_Mean_Firing_Rate(Current_Cell,:)=[Cell_List(Current_Cell),mean(Pre_Ripple_Firing_Rates,'omitnan'),sum(Pre_Ripple_Firing_Rates>0)/length(Pre_Ripple_Firing_Rates),mean(Pre_Ripple_Firing_Rates(Pre_Ripple_Firing_Rates>0)),On_Task_Mean_Firing_Rate,mean(Post_Ripple_Firing_Rates,'omitnan'),sum(Post_Ripple_Firing_Rates>0)/length(Post_Ripple_Firing_Rates),mean(Post_Ripple_Firing_Rates(Post_Ripple_Firing_Rates>0)),];
end

save('Ripple_Spiking_Analysis_Cells','Pre_Ripple_Participation','Post_Ripple_Participation','Per_Cell_Mean_Firing_Rate')
