% This program assumes that you have already calculated interregional
% gamma coherence during ripples. It then  loads up the phase offset data
% and generates rotated plots for individual subjects, calculates ISPCs and,
% generates aggregated polar histograms
%
% INPUT: 
%  Mean_Gamma_Coherence_Per_SWR_2to1 = mean phase offset for each SWR
%  All_ISPCs= ISPC calculated for each ripple
% OUTPUT: 
%
% LDQ 01/2022
% Volk Lab & Friends

%==========================================================================

WT_ISPC_Pre = [];
WT_ISPC_Post = [];

WT_Rotated_Pre = [];
WT_Rotated_Post = [];

%Set working directory
D = dir('G:\Current_Kc_Analysis\WT'); % Change to directory containing lfp data for each subject  
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));
for k = 1:numel(D)
    currD = D(k).name;
    cd(currD);
       
    % Navigate to folder with low Gamma phase coherence data
        cd ./Phase_Coherence
        cd ./RipplesPreExp
        
        load('LowGamma_Coherence_During SWRs.mat', 'Mean_Gamma_Coherence_Per_SWR_2to1')
        bins = 36;
        WT_Ripple_LowG_Coherence_Angle_Pre = Mean_Gamma_Coherence_Per_SWR_2to1;
        
        %Calculate Peak Phase
         %[Weighted_Mean,Peak_Phase] = get_weightedmean_pk(WT_Ripple_LowG_Coherence_Angle_Pre,36);
         Data = rad2deg(WT_Ripple_LowG_Coherence_Angle_Pre);

         [H,edges]=histcounts(Data,-180:360/bins:180);
         centers = -175:10:175;
        
         [Max_Value,Max_Index]=max(H);
         Peak_Phase = centers(Max_Index);
         Peak_Phase(Peak_Phase<0)=Peak_Phase(Peak_Phase<0)+360;
         
       
         Offset = 0-Peak_Phase
           if (abs(Offset)>=15 && abs(Offset)<=345) || (abs(Offset)<=345 && abs(Offset)>=15)
         %[H,edges]=histcounts(Data,-180:360/bins:180)
       % polarhistogram('Bincounts',H,'Binedges',deg2rad(edges))
           WT_Ripple_LowG_Coherence_Angle_Pre = Data + Offset;
         else 
          WT_Ripple_LowG_Coherence_Angle_Pre = Data;
           end

       
        WT_Rotated_Pre = [WT_Rotated_Pre;WT_Ripple_LowG_Coherence_Angle_Pre];
         %deg2rad(WT_Rotated_Pre) = [deg2rad(WT_Rotated_Pre)+H];
         
        phaseDiffs = exp(1i*deg2rad(WT_Ripple_LowG_Coherence_Angle_Pre));
        ispc = abs(mean(phaseDiffs));
        WT_ISPC_Pre = [WT_ISPC_Pre;ispc];
        clearvars ispc Mean_Gamma_Coherence_Per_SWR_2to1
           
       % Plot histograms 
        figure
        subplot(1,3,1);
        polarhistogram(deg2rad(WT_Ripple_LowG_Coherence_Angle_Pre),deg2rad(-180:10:180),'Normalization','Probability','FaceColor','k');      
        set(gca,'FontSize',12);
        set(gca,'FontWeight','bold');
        r1 = rlim
        rlim([0 r1(1,2)])
        %thetaticklabels('')
        %rticklabels('')
        hold on

        subplot(1,3,2);
        polarhistogram(deg2rad(WT_Ripple_LowG_Coherence_Angle_OnTask),deg2rad(-180:10:180),'Normalization','Probability','FaceColor',[.8 .8 .8]);        
        set(gca,'FontSize',12);
        set(gca,'FontWeight','bold');
        %thetaticklabels('')
        %rticklabels('')
    
       % rlim([0 .1])
        hold on
        
        subplot(1,3,3);
        polarhistogram(deg2rad(WT_Ripple_LowG_Coherence_Angle_Post),deg2rad(-180:10:180),'Normalization','Probability','FaceColor','k');
          r3 = rlim;
          if r1(1,2)> r3(1,2)
         rlim([0 r1(1,2)])
          else
              rlim([0 r3(1,2)])
          end
        set(gca,'FontSize',12);
        set(gca,'FontWeight','bold');
        %thetaticklabels('')
        %rticklabels('')
        %close
        cd ..
        savefig('Mean_Low_Gamma_Per_SWR_Individual_Polar_Rotated ')
        cd ..
        clearvars -except D k WT*
      
       
       cd ..

 end
%% Plot Combined Polar Histogram

figure 

polarhistogram(deg2rad(WT_Rotated_Pre),deg2rad(0:10:360),'Normalization', 'Probability','FaceColor','k')
hold on 
polarhistogram(deg2rad(KO_Rotated_Pre),deg2rad(0:10:360),'Normalization', 'Probability', 'FaceColor',[0.4940, 0.1840, 0.5560])
set(gca,'FontSize',14);
set(gca,'FontWeight','bold');
rlim([0 .1])
  %thetaticklabels('')
  %rticklabels('')

figure 

%polarhistogram('BinEdges',deg2rad(0:10:360),'BinCounts',WT_Rotated, 'Normalization', 'Probability','FaceColor','k')
polarhistogram(deg2rad(WT_Rotated_Post),deg2rad(0:10:360), 'Normalization', 'Probability','FaceColor','k')
hold on 
%polarhistogram('BinEdges',deg2rad(0:10:360),'BinCounts',KO_Rotated, 'Normalization', 'Probability', 'FaceColor',[0.4940, 0.1840, 0.5560])
polarhistogram(deg2rad(KO_Rotated_Post),deg2rad(0:10:360), 'Normalization', 'Probability', 'FaceColor',[0.4940, 0.1840, 0.5560])
set(gca,'FontSize',14);
set(gca,'FontWeight','bold');
rlim([0 .1])
%

%% Calculate ISPCs For Individual SWRs

WT_ISPC_Pre = [];
WT_ISPC_Post = [];


D = dir('G:\Current_Kc_Analysis\WT');
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));
for k = 1:numel(D)
    currD = D(k).name;
    cd(currD);
       
        cd ./Phase_Coherence
        cd ./RipplesPreExp
        load('LowGamma_Coherence_During SWRs.mat', 'All_IPSCs')
        WT_ISPC_Pre = [WT_ISPC_Pre;mean(All_IPSCs)];
        
         cd ..
        cd ./RipplesPostExp
        load('LowGamma_Coherence_During SWRs.mat', 'All_IPSCs')
        WT_ISPC_Post = [WT_ISPC_Post;mean(All_IPSCs)];

cd ..
cd ..


       cd ..
       clearvars -except D k WT*
 end


%% Calculate ISPCs For All SWRs 

WT_ISPC_Pre = [];
WT_ISPC_Post = [];


D = dir('G:\Current_Kc_Analysis\WT');
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));
for k = 1:numel(D)
    currD = D(k).name;
    cd(currD);
       
        cd ./Phase_Coherence
        cd ./RipplesPreExp
        load('LowGamma_Coherence_During SWRs.mat', 'Mean_Gamma_Coherence_Per_SWR_2to1')
        phaseDiffs = exp(1i*Mean_Gamma_Coherence_Per_SWR_2to1);
        ispc = abs(mean(phaseDiffs));
        WT_ISPC_Pre = [WT_ISPC_Pre;ispc];
        
         cd ..
        cd ./RipplesPostExp
        load('LowGamma_Coherence_During SWRs.mat', 'Mean_Gamma_Coherence_Per_SWR_2to1')
        phaseDiffs = exp(1i*Mean_Gamma_Coherence_Per_SWR_2to1);
        ispc = abs(mean(phaseDiffs));
        WT_ISPC_Post = [WT_ISPC_Post;ispc];

cd ..
cd ..

      
       cd ..
       clearvars -except D k WT*
end



% [pval1, k, K] = circ_kuipertest(deg2rad(WT_Rotated_Pre),WT_Rotated_Post)
% [pval2, k, K] = circ_kuipertest(KO_Rotated_Pre,KO_Rotated_Post)
% 
% [pval3, k, K] = circ_kuipertest(deg2rad(WT_Rotated_Pre),KO_Rotated_Pre)
% [pval4, k, K] = circ_kuipertest(WT_Rotated_Post,KO_Rotated_Post)

% %% 
% 
% figure
% subplot(1,3,1);
% polarhistogram(WT_Ripple_LowG_Coherence_Angle_Pre,36,'Normalization','Probability','FaceColor','k');
% set(gca,'FontSize',12);
% set(gca,'FontWeight','bold');
% hold on
% rlim([0 .08])
% 
% subplot(1,3,2);
% polarhistogram(WT_Ripple_LowG_Coherence_Angle_Post,36,'Normalization','Probability','FaceColor',[.8 .8 .8]);
% set(gca,'FontSize',12);
% set(gca,'FontWeight','bold');
% rlim([0 .08])
% 
% subplot(1,3,3);
% polarhistogram(WT_Ripple_LowG_Coherence_Angle_OnTask,36,'Normalization','Probability','FaceColor','k');
% set(gca,'FontSize',12);
% set(gca,'FontWeight','bold');
% rlim([0 .08])

% 
% figure
% polarhistogram(KO_Ripple_LowG_Coherence_Angle_Pre,36,'Normalization','Probability','FaceColor',[0.4940, 0.1840, 0.5560]);
% hold on
% polarhistogram(KO_Ripple_LowG_Coherence_Angle_Post,36,'Normalization','Probability','FaceColor',[.8 .8 .8]);
% set(gca,'FontSize',14);
% set(gca,'FontWeight','bold');
% rlim([0 .08])
% 
% figure
% polarhistogram(KO_Ripple_LowG_Coherence_Angle_OnTask,36,'Normalization','Probability','FaceColor',[0.4940, 0.1840, 0.5560]);
% set(gca,'FontSize',14);
% set(gca,'FontWeight','bold');
% rlim([0 .08])
% 
% figure
% polarhistogram(WT_Ripple_LowG_Coherence_Angle_QWPre,36,'Normalization','Probability','FaceColor','k');
% hold on
% polarhistogram(WT_Ripple_LowG_Coherence_Angle_QWPost,36,'Normalization','Probability','FaceColor',[.8 .8 .8]);
% set(gca,'FontSize',12);
% set(gca,'FontWeight','bold');
% rlim([0 .08])
% 
% figure
% polarhistogram(KO_Ripple_LowG_Coherence_Angle_QWPre,36,'Normalization','Probability','FaceColor',[0.4940, 0.1840, 0.5560]);
% hold on
% polarhistogram(KO_Ripple_LowG_Coherence_Angle_QWPost,36,'Normalization','Probability','FaceColor',[.8 .8 .8]);
% set(gca,'FontSize',12);
% set(gca,'FontWeight','bold');
% rlim([0 .08])
% 
% %Statistics
% [pval,z] =circ_rtest(WT_Ripple_LowG_Coherence_Angle_OnTask)
% 
% circ_cmtest(WT_Ripple_LowG_Coherence_Angle_OnTask)
% 
% %%
% figure
% polarhistogram(WT_Ripple_LowG_Coherence_Angle_Pre,36,'Normalization','Probability','FaceColor','k');
% hold on
% polarhistogram(KO_Ripple_LowG_Coherence_Angle_Pre,36,'Normalization','Probability','FaceColor',[0.4940, 0.1840, 0.5560]);
% set(gca,'FontSize',14);
% set(gca,'FontWeight','bold');
% 
% figure
% polarhistogram(WT_Ripple_LowG_Coherence_Angle_Post,36,'Normalization','Probability','FaceColor','k');
% hold on
% polarhistogram(KO_Ripple_LowG_Coherence_Angle_Post,36,'Normalization','Probability','FaceColor',[0.4940, 0.1840, 0.5560]);
% set(gca,'FontSize',14);
% set(gca,'FontWeight','bold');
% rlim([0 .08])
% 
% 

