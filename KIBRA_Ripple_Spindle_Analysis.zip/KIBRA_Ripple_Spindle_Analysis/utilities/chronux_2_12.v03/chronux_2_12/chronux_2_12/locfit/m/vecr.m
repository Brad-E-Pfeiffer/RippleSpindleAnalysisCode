function z=vecr(fit)

z = fit.fit_points.kappa;

return;
