function segment=KRSA_IDENTIFY_PERIODS_IMMOBILITY(velocity,time,velocity_cutoff,min_duration)
% this program is to determine low-velocity periods of animals. 
% Input: 
% velocity: is a vector where each value represents the animal's velocity at each sampled moment.
% time: is a vector which has the same number of data with "velocity". Each value represents each sampled time point and pairs with the velocity value in the corresponding order.
% velocity_cutoff: a value. Animal is defined as immobile if its velocity is lower than this cutoff. 
% min_duration: a value. Minimal time length of immobile periods. All identified periods should be longer than this cutoff to bee thought as meaningful. 
% Output:
% segment: a n-by-3 matrix which consists of all identified periods. Here each row corresponds to one period and total number of periods is n.
% fisrt column: time that one period starts;
% second column: time that one period ends;
% third column: total time duration of correponding period
%------------------------------------------------------------------------------------
if sum(size(velocity)==1)==1
    velocity=velocity(:);
    indcut=find(velocity>velocity_cutoff);segment=[];
    segment(:,1)=[1;indcut(:)+1];
    segment(:,2)=[indcut(:)-1;size(velocity,1)];
    segment(:,3)=segment(:,2)-segment(:,1)+1;
    segment=segment(segment(:,3)>0,:);
    segment(:,1)=time(segment(:,1));
    segment(:,2)=time(segment(:,2));
    segment(:,3)=segment(:,2)-segment(:,1);
    segment=segment(segment(:,3)>=min_duration,:);
else
    disp('input velocity should be a one-dimensional vector!');
end
