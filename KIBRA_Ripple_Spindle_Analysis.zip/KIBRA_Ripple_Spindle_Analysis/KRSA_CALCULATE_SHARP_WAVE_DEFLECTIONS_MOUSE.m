function KRSA_CALCULATE_SHARP_WAVE_DEFLECTIONS_MOUSE(Ripple_Events,LFP_Data,LFP_Frequency)
% %% FUNCTION:
% This function looks at the LFP for every electrode and calculates the
% mean phase offset for the slow gamma oscillation.  For any session with
% more than one behavior period (including some linear track experiments),
% this program only analyses the first run and the first post-behavior
% period.  It is assumed that things won't change meaningfully across the
% subsequent sessions.  Only sharp waves with SD peak amplitude of 5 S.D.
% above the mean and longer than 150 ms are used for this to ensure a
% strong, measurable sharp-wave component.
%
% The raw LFP is normalized by subtracting the mean LFP 100-200 ms prior to
% ripple onset.  The deflection is measured as the mean 50-150 ms after
% ripple onset.  The dataset that this program was written to analyze was
% recorded with the values inverted, so this program flips them.
% Method from Berndt et al. 2023
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Ripple_Events_Sharp_Wave_Deflections (each page is a tetrode)
% |       1       |                   2                  |                      3                   |                   4                |                         5                      |                           6                        |                       7                      ||
% | Ripple Number | Sharp-Wave Amplitude at Ripple Start | Sharp-Wave Amplitude at Max Ripple Power | Sharp-Wave Amplitude at Ripple End | Mean LFP Amplitude (+/- 10 ms) at Ripple Start | Mean LFP Amplitude (+/- 10 ms) at Max Ripple Power | Mean LFP Amplitude (+/- 10 ms) at Ripple End ||
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% INPUT: 
%  Ripple_Events = n x 7 matrix containing Start, end and peak times
 % 
    % |     1      |    2     |     3     |        4       |              5             |                    6                     |
    % | Start Time | End Time | Peak Time | Peak Raw Power | Peak Global Z-Scored Power | Peak Z-Scored Power From That Epoch Only |
    % |     7      |
    %   Duration 
    
   %LFP_Data = n x 2 matrix containing [times, signal] 


% OUTPUT: 
%  
% Volk Lab & Pfeiffer Lab

%==========================================================================

% -------------------------------------------------------------------------


 if 1%~isfile('Combined_Ripple_LFP_Data.mat')

    % Find ripples that occur during defined epochs in the experiment
    
    % Move to folder with raw LFP Data
    %Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
    disp('Calculating Sharp-Wave Deflections For Each Electrode.')

    LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes);
    LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1);  %This assumes that the recording frequency is the same for all LFPs, so it just grabs the frequency from the first LFP trace
    clearvars M;
    clearvars N;
    clearvars Directory_List;
    %clearvars LFP_Electrodes;
    %clearvars LFP_Filename;

    Ripple_Stop_Low=100;%Changing to match detection from 130 to 100
    Ripple_Pass_Low=125; %150 to 125            % Most papers use between 150 and 250 Hz to identify ripples
    Ripple_Pass_High=300;%250 to 300
    Ripple_Stop_High=325;%275 to 325
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Ripple=fdesign.bandpass(Ripple_Stop_Low, Ripple_Pass_Low, Ripple_Pass_High, Ripple_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
    Ripple_Filter=design(Filter_Design_For_Ripple,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

    Sharp_Wave_Stop_Low=4;
    Sharp_Wave_Pass_Low=5;
    Sharp_Wave_Pass_High=15;
    Sharp_Wave_Stop_High=20;
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Sharp_Wave=fdesign.bandpass(Sharp_Wave_Stop_Low, Sharp_Wave_Pass_Low, Sharp_Wave_Pass_High, Sharp_Wave_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
    Sharp_Wave_Filter=design(Filter_Design_For_Sharp_Wave,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

   % Ripple_Events_Sharp_Wave_Deflections=zeros(size(Ripple_Events,1),7,length(Tetrode_List));
        Ripple_Events_Sharp_Wave_Deflections=zeros(size(Ripple_Events,1),7);


                    Ripple_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
                    Ripple_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,LFP_Data(:,2));
                    Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                    Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Ripple_Filtered_LFP_Data(:,2));
                    Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);
                    Ripple_Filtered_LFP_Data(:,3)=abs(hilbert(Ripple_Filtered_LFP_Data(:,2)));
                    Ripple_Gaussian_Filter=fspecial('gaussian',[round(7*(12.5/((1/LFP_Frequency)*1000))),1],round(12.5/((1/LFP_Frequency)*1000)));  %sigma of 12.5 ms

                    Sharp_Wave_Filtered_LFP_Data=zeros(size(LFP_Data,1),2);
                    Sharp_Wave_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Sharp_Wave_Filtered_LFP_Data(:,2)=filter(Sharp_Wave_Filter,LFP_Data(:,2));
                    Sharp_Wave_Filtered_LFP_Data(:,2)=Sharp_Wave_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                    Sharp_Wave_Filtered_LFP_Data(:,2)=filter(Sharp_Wave_Filter,Sharp_Wave_Filtered_LFP_Data(:,2));
                    Sharp_Wave_Filtered_LFP_Data(:,2)=Sharp_Wave_Filtered_LFP_Data(end:-1:1,2);

%                 
                    %Find and average the raw LFP across all ripples (rather than use the actual ripple duration, we just grab 400 ms before the ripple starts and 400 ms after the peak ripple power
                    Average_All_Ripple_LFP_Data=(-0.25:1/3200:0.25)';
                    Average_All_Ripple_LFP_Data(:,2:(size(Ripple_Events,1)+1))=NaN;
                    Average_All_Ripple_Sharp_Wave_LFP_Data=Average_All_Ripple_LFP_Data;
                    for Current_Ripple=1:size(Ripple_Events,1)
                        if min(LFP_Data(:,1))<(Ripple_Events(Current_Ripple,1)-1) && max(LFP_Data(:,1))>(Ripple_Events(Current_Ripple,2)+1) %only use ripple events more than 1 second from the start/end of the recording to avoid truncation artifacts
                            Start=Ripple_Events(Current_Ripple,1);
                            End=Ripple_Events(Current_Ripple,2);
                            Peak=Ripple_Events(Current_Ripple,3);
                            if 1%Ripple_Events(Current_Ripple,6)>=5 && Ripple_Events(Current_Ripple,7)>=0.15 %limit analysis by ripple criteria (z-score power >= 5; duration >= 150 ms)
                                Current_Ripple_LFP_Data=LFP_Data(LFP_Data(:,1)>=(Start-1) & LFP_Data(:,1)<=(End+1),:); %grab raw LFP 1000 ms before start and 1000 ms after end of each ripple
                                Current_Ripple_Sharp_Wave_Filtered_LFP_Data=Sharp_Wave_Filtered_LFP_Data(Sharp_Wave_Filtered_LFP_Data(:,1)>=(Start-1) & Sharp_Wave_Filtered_LFP_Data(:,1)<=(End+1),:); %grab sharp-wave filtered LFP 1000 ms before start and 1000 ms after end of each ripple
                                Ripple_Events_Sharp_Wave_Deflections(Current_Ripple,:)=[Current_Ripple,Current_Ripple_Sharp_Wave_Filtered_LFP_Data(find(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=Start,1,'first'),2),Current_Ripple_Sharp_Wave_Filtered_LFP_Data(find(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=Peak,1,'first'),2),Current_Ripple_Sharp_Wave_Filtered_LFP_Data(find(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=End,1,'first'),2),mean(Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=(Start-0.005) & Current_Ripple_LFP_Data(:,1)<=(Start+0.005),2),'omitnan'),mean(Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=(Peak-0.005) & Current_Ripple_LFP_Data(:,1)<=(Peak+0.005),2),'omitnan'),mean(Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=(End-0.005) & Current_Ripple_LFP_Data(:,1)<=(End+0.005),2),'omitnan')];
                                Peak_Index=find(Current_Ripple_LFP_Data(:,1)>=Peak,1,'first');
                                % Re-assign times based on ripple peak power timepoint and normalize by baseline 400-500 ms before ripple start
                                Current_Ripple_LFP_Data(:,1)=Current_Ripple_LFP_Data(:,1)-Current_Ripple_LFP_Data(Peak_Index,1);
                                Current_Ripple_LFP_Data(:,2)=Current_Ripple_LFP_Data(:,2)-mean(Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=-0.5 & Current_Ripple_LFP_Data(:,1)<=-0.4,2),'omitnan');
                                Current_Ripple_LFP_Data=Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=-0.25 & Current_Ripple_LFP_Data(:,1)<=0.25,:);
                                Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)=Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)-Current_Ripple_Sharp_Wave_Filtered_LFP_Data(Peak_Index,1);
                                Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,2)=Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,2)-mean(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=-0.5 & Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)<=-0.4,2),'omitnan');
                                Current_Ripple_Sharp_Wave_Filtered_LFP_Data=Current_Ripple_Sharp_Wave_Filtered_LFP_Data(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=-0.25 & Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)<=0.25,:);
                                
                                %Average_All_Ripple_LFP_Data(:,i)=Current_Ripple_LFP_Data(:,2);
                                % Combine into a single average trace
                                Integration_Index=round(interp1(Current_Ripple_LFP_Data(:,1),1:size(Current_Ripple_LFP_Data,1),Average_All_Ripple_LFP_Data(:,1),'nearest'));
                                Integration_Index(Integration_Index==0)=1;
                                Integration_Index(Integration_Index>size(Current_Ripple_LFP_Data,1))=size(Current_Ripple_LFP_Data,1);
                                Average_All_Ripple_LFP_Data(~isnan(Integration_Index),(Current_Ripple+1))=Current_Ripple_LFP_Data(Integration_Index(~isnan(Integration_Index)),2);
                               % Average_All_Ripple_LFP_Data(~isnan(Integration_Index),Current_Ripple+1)=Current_Ripple_LFP_Data(:,2);
                              Average_All_Ripple_Sharp_Wave_LFP_Data(~isnan(Integration_Index),(Current_Ripple+1))=Current_Ripple_Sharp_Wave_Filtered_LFP_Data(Integration_Index(~isnan(Integration_Index)),2);
                                clearvars Integration_Index;
                            end
                        end
                    end
                    % Average across all ripples for this tetrode
                    if exist('Combined_All_Ripple_LFP_Data','var')
                        Combined_All_Ripple_LFP_Data(:,end+1)=(mean((Average_All_Ripple_LFP_Data(:,2:end)'),'omitnan')');
                        Combined_All_Ripple_Sharp_Wave_Filtered_LFP_Data(:,end+1)=(mean((Average_All_Ripple_Sharp_Wave_LFP_Data(:,2:end)'),'omitnan')');

                    else
                        Combined_All_Ripple_LFP_Data=[Average_All_Ripple_LFP_Data(:,1),(mean((Average_All_Ripple_LFP_Data(:,2:end)'),'omitnan')')];
                        
                        Combined_All_Ripple_Sharp_Wave_Filtered_LFP_Data=[Average_All_Ripple_Sharp_Wave_LFP_Data(:,1),(mean((Average_All_Ripple_Sharp_Wave_LFP_Data(:,2:end)'),'omitnan')')];

                    end
               % end
            %end
        %end
        %disp(sprintf('Finished quantifying sharp-wave deflection for tetrode %d of %d.',max(Tetrode_Cell_IDs(:,1))));
         disp(sprintf('Finished quantifying sharp-wave deflection for tetrode %d.',LFP_Electrodes));
    
%     cd(Current_Working_Directory);
% 
%     clear Raw_LFP_Directory;
%     clear Current_Directory;
 end
    save('Sharp_Wave_Deflection_Per_Tetrode','Ripple_Events_Sharp_Wave_Deflections');
    save('Combined_Ripple_LFP_Data','Combined_*','-v7.3');

 end
% 
% 
% end

