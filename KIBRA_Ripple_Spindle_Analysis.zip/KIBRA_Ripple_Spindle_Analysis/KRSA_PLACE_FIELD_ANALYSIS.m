% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This routine assumes the spike data has been clustered and position data
% has been quantified. It loads and processes position data output from DLC 
% and then processes the position data, assigns positions to each spike, 
% calculates place fields, and quantifies place field properties.
%
%
% 
%
% Volk & Pfeiffer Lab 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------


%==========================================================================
% Loading and Processing Position Data
%==========================================================================

Bin_Size=1; %Spatial bin size, in cm
%Session=3;  %Which behavioral session to analyze (i.e., which line on Times to use)
Velocity_Cutoff=5;  %in cm/s
Place_Field_Firing_Rate_Cutoff=1; %in Hz

%This loads the position data
%load TimesSession;
 LFP_Times=Nlx2MatCSC('CSC1.ncs',[1 0 0 0 0],0,1)/1000000;
 Recording_Start=min(LFP_Times);
 Recording_End=max(LFP_Times);
 %clear LFP_Times;
load DLC_Position_Data;
Raw_Position_Data=Position_Data;
Raw_Position_Data(:,2:3)=Raw_Position_Data(:,2:3)/Pixel_Conversion;
clear Position_Data;
load Processed_Position_Data_Smoothed;
Smoothed_Position_Data=Position_Data;
clear Position_Data;

%This finds the times for each value in the raw position data
Step_Size=mode(diff(Smoothed_Position_Data(:,1)));
if sum(isnan(Raw_Position_Data(:,4)))>0
    Total_NaN_Values=sum(isnan(Raw_Position_Data(:,4)));
    Raw_Position_Data=Raw_Position_Data(~isnan(Raw_Position_Data(:,4)),:);
    fprintf('Removed %d Position Data Points Due to NaN Probability Values.\n',Total_NaN_Values);
end
Raw_Position_Data(:,5)=0;
Raw_Position_Data(1,5)=Recording_Start;
Raw_Position_Data(end,5)=Recording_End;
if 1  % This is for KcJan21 recordings, where the video data is not perfectly synchronized with the LFP recording
    Raw_Position_Data(end,5)=Recording_Start+((size(Raw_Position_Data,1)-1)*(1001/30000));  %30,000/1,001 is the actual frame rate for 29.97 Hz
end
Raw_Position_Data(:,5)=interp1([1,size(Raw_Position_Data,1)],[Recording_Start,Recording_End],1:size(Raw_Position_Data,1));
Position_Data=Raw_Position_Data(:,[5,2,3]);
save('Raw_Position_Data','Position_Data');
clear Position_Data;

Raw_Position_Data(Raw_Position_Data(:,4)<0.95,2:3)=NaN;
Raw_Position_Data(Raw_Position_Data(:,4)<0.95,6:7)=NaN;
Raw_Position_Data(:,6:7)=Raw_Position_Data(:,2:3);
[FilterA,FilterB]=butter(2,0.2); %This smooths the raw position data to eliminate artificial jumps
Raw_Position_Data(~isnan(Raw_Position_Data(:,6)),6)=filtfilt(FilterA,FilterB,Raw_Position_Data(~isnan(Raw_Position_Data(:,6)),6));
Raw_Position_Data(~isnan(Raw_Position_Data(:,7)),7)=filtfilt(FilterA,FilterB,Raw_Position_Data(~isnan(Raw_Position_Data(:,7)),7));
Time_Per_Step=diff(Raw_Position_Data(:,5));
Movement=sqrt(diff(Raw_Position_Data(:,6)).^2+diff(Raw_Position_Data(:,7)).^2);
Velocity=Movement./Time_Per_Step;
Total_Duration_Of_Movement=sum(Time_Per_Step(Velocity>Velocity_Cutoff));
[FilterA,FilterB]=butter(2,0.2); %This smooths the velocity data to eliminate artificial oscillations
Velocity(~isnan(Velocity))=filtfilt(FilterA,FilterB,Velocity(~isnan(Velocity)));
Position_Data=[Raw_Position_Data(:,[5,6,7]),[Velocity;Velocity(end)]];
Position_Data(:,2)=Position_Data(:,2)-min(Position_Data(:,2))+0.001;
Position_Data(:,3)=Position_Data(:,3)-min(Position_Data(:,3))+0.001;
Position_Data(:,5)=ceil(Position_Data(:,2)/Bin_Size);
Position_Data(:,6)=ceil(Position_Data(:,3)/Bin_Size);
Position_Data(:,7)=[diff(Position_Data(:,1));Position_Data(end,1)-Position_Data(end-1,1)];

clearvars -except Position_Data Mouse_ID Times Bin_Size Session Velocity_Cutoff Place_Field_Firing_Rate_Cutoff Total_Duration_Of_Movement

%==========================================================================
% Loading Spike Data and Assigning Positions To Each Spike
%==========================================================================

load All_Spike_Data

%Find Closest Position Data for Each Spike
Spike_Data(:,3:6)=[interp1(Position_Data(:,1),Position_Data(:,5),Spike_Data(:,1),'nearest'),interp1(Position_Data(:,1),Position_Data(:,6),Spike_Data(:,1),'nearest'),interp1(Position_Data(:,1),Position_Data(:,4),Spike_Data(:,1),'nearest'),interp1(Position_Data(:,1),Position_Data(:,1),Spike_Data(:,1),'nearest')];

%Remove spikes and position data for which position or velocity data is unavailable
Spike_Data=Spike_Data(~isnan(Spike_Data(:,3)) & ~isnan(Spike_Data(:,4)) & ~isnan(Spike_Data(:,5)),:);
Position_Data=Position_Data(~isnan(Position_Data(:,3)) & ~isnan(Position_Data(:,4)) & ~isnan(Position_Data(:,5)),:);

%==========================================================================
% Calculating Place Fields
%==========================================================================

%This limits analysis to the appropriate session and to periods of running
All_Spike_Data=Spike_Data;
All_Spike_Data=All_Spike_Data(All_Spike_Data(:,1)>=Times(Session,1) & All_Spike_Data(:,1)<=Times(Session,2),:);
Spike_Data=Spike_Data(Spike_Data(:,1)>=Times(Session,1) & Spike_Data(:,1)<=Times(Session,2) & Spike_Data(:,5)>=Velocity_Cutoff,:);
Position_Data=Position_Data(Position_Data(:,1)>=Times(Session,1) & Position_Data(:,1)<=Times(Session,2) & Position_Data(:,4)>=Velocity_Cutoff,:);

% The total time spent moving in each position bin is calculated
Time_In_Position=zeros(max(Position_Data(:,6)),max(Position_Data(:,5)));
for N=1:size(Position_Data,1)
    Time_In_Position(Position_Data(N,6),Position_Data(N,5))=Time_In_Position(Position_Data(N,6),Position_Data(N,5))+Position_Data(N,7);
end

% The number of spikes in each position bin is calculated for each cell
Cell_List=unique(Spike_Data(:,2));
Spikes_In_Position=zeros(max(Position_Data(:,6)),max(Position_Data(:,5)),length(Cell_List));
for N=1:length(Cell_List)
    Cell_Spike_Data=Spike_Data(Spike_Data(:,2)==Cell_List(N),:);
    for M=1:size(Cell_Spike_Data,1)
        Spikes_In_Position(Cell_Spike_Data(M,4),Cell_Spike_Data(M,3),N)=Spikes_In_Position(Cell_Spike_Data(M,4),Cell_Spike_Data(M,3),N)+1;
    end
end

% Calculate the actual firing rate (spikes/time) and save it as Field_Data
Firing_Rate_In_Position=zeros(size(Spikes_In_Position,1),size(Spikes_In_Position,2),size(Spikes_In_Position,3));
for N=1:size(Spikes_In_Position,3)
    Firing_Rate_In_Position(:,:,N)=Spikes_In_Position(:,:,N)./Time_In_Position;
end
Firing_Rate_In_Position(isnan(Firing_Rate_In_Position))=0;
Firing_Rate_In_Position(isinf(Firing_Rate_In_Position))=0;
Smoothed_Firing_Rate=Firing_Rate_In_Position;
Two_D_Filter=fspecial('gaussian',[30 30],3);  %This is a gaussian filter with a kernel St. Dev. of 2 bins that filters out to 10 bins in all directions
for N=1:size(Firing_Rate_In_Position,3)
    Smoothed_Firing_Rate(:,:,N)=filter2(Two_D_Filter,Firing_Rate_In_Position(:,:,N));
end
Smoothed_Firing_Rate(isnan(Smoothed_Firing_Rate))=0;
Smoothed_Firing_Rate(Smoothed_Firing_Rate<0)=0;
for Z=1:size(Smoothed_Firing_Rate,3)
    % This eliminates fields with a peak firing rate beneath the cutoff defined above.
    if max(max(max(Smoothed_Firing_Rate(:,:,Z))))<Place_Field_Firing_Rate_Cutoff
        Smoothed_Firing_Rate(:,:,Z)=0;
    end
end
Field_Data=Smoothed_Firing_Rate;
save('Field_Data','Field_Data','Cell_List')

%==========================================================================
% Quantifying Place Fields
%==========================================================================

load L_Ratios

Normalized_Time_In_Position=Time_In_Position/sum(sum(Time_In_Position));
if ~isempty(Excitatory_Neurons)
    for N=1:length(Excitatory_Neurons)
        Place_Field=Field_Data(:,:,Excitatory_Neurons(N));
        if max(max(Place_Field))>0
            L_Ratio=L_Ratios(Excitatory_Neurons(N),1);
            Peak_Firing_Rate=max(max(Place_Field));
            Mean_Firing_Rate=sum(All_Spike_Data(:,2)==Excitatory_Neurons(N) & All_Spike_Data(:,5)>=Velocity_Cutoff)/(Times(Session,2)-Times(Session,1));
            Information_Field=Normalized_Time_In_Position.*(Place_Field/Mean_Firing_Rate).*log2((Place_Field/Mean_Firing_Rate));
            Information_Field=Information_Field(Normalized_Time_In_Position>0); %Limit analysis only to parts of the track where the rat explored
            Information_Field(isnan(Information_Field))=0;
            Information_Per_Spike=sum(sum(Information_Field));
            Number_Of_Fields=0;
            Contiguous_Place_Fields=zeros(size(Place_Field,1),size(Place_Field,2));
            Place_Field=double(Place_Field>=Peak_Firing_Rate*0.3); %Place field boundary defined as 30% of max firing rate
            Place_Field_Sizes=0;
            [Y_Index,X_Index]=find(Place_Field==1);
            for M=1:length(Y_Index)
                if Contiguous_Place_Fields(Y_Index(M),X_Index(M))==0 && Place_Field(Y_Index(M),X_Index(M))==1
                    This_Place_Field=grayconnected(Place_Field,Y_Index(M),X_Index(M),0);
                    if sum(sum(This_Place_Field))>=20  %Place field requires at least 20 contiguous bins to be considered a "true" place field
                        Number_Of_Fields=Number_Of_Fields+1;
                        Contiguous_Place_Fields(This_Place_Field)=Number_Of_Fields;
                        Place_Field_Sizes=[Place_Field_Sizes;sum(sum(This_Place_Field))];
                    end
                end
                clear This_Place_Field;
            end
            [Y,X]=find(Contiguous_Place_Fields>0);
            Mean_InField_Firing_Rate=mean(mean(Field_Data(Y,X,Excitatory_Neurons(N)),'omitnan'),'omitnan');
            clear M;
            clear X;
            clear Y;
            clear X_Index;
            clear Y_Index;
            if length(Place_Field_Sizes)>1
                Place_Field_Sizes=Place_Field_Sizes(2:end);
            end
            %Might still need to quantify place fields for place field size and place field number
            % Place_Field_Properties
            % |       1        |              2               |            3           |        4         |         5        |              6              |    7    |            8              ||
            % | Cell ID Number | Mean Place Field Size (bins) | Number Of Place Fields | Peak Firing Rate | Mean Firing Rate | Informaton Per Spike (bits) | L-Ratio | Mean In-Field Firing Rate ||
            if exist('Place_Field_Properties','var')==1
                Place_Field_Properties=[Place_Field_Properties;[Excitatory_Neurons(N),mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,L_Ratio,Mean_InField_Firing_Rate]];
            else
                Place_Field_Properties=[Excitatory_Neurons(N),mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,L_Ratio,Mean_InField_Firing_Rate];
            end
            clear L_Ratio
            clear Peak_Firing_Rate;
            clear Mean_Firing_Rate;
            clear Mean_InField_Firing_Rate;
            clear Information_Per_Spike;
            clear Information_Field;
            clear Place_Field_Size;
            clear Number_Of_Fields;
            clear Contiguous_Place_Fields;
            clear Place_Field_Sizes;
        end
        clear Place_Field;
    end
end
save('Place_Field_Properties','Place_Field_Properties');



