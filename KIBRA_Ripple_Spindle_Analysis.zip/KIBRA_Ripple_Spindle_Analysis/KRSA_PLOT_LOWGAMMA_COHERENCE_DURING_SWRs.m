% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This routine assumes that interregional gamma coherence during SWRs
% has already been calculated and plots for group data
% loads vector of mean phase offset during each SWR, for all detected SWRs
% and generates a polar histogram 
% 
% Inputs:
% LowGamma_Coherence_During SWRs

% Outputs: 
%
% Volk & Pfeiffer Lab 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%% WT
tic
D = dir('G:\Current_Kc_Analysis\WT'); %Input Data directory 
dirFlags = [D.isdir];
D = D(dirFlags);
D = D(~ismember({D.name}, {'.', '..'}));
for k = 1:numel(D)
    currD = D(k).name;
    cd(currD)
% Calculate coherence 
      
    % create variables      
        if k==1 || ~exist('WT_Ripple_LowG_Coherence_Angle_Pre')
        WT_Ripple_LowG_Coherence_Angle_Pre = [];     
        WT_Ripple_LowG_Coherence_Angle_Post = [];
        end 
       
       % aggregate pre experience data
            cd ./Phase_Coherence/RipplesPreExp
            %load('Phase_Phase_Coherence.mat')
            load('LowGamma_Coherence_During SWRs.mat')
                 
       WT_Ripple_LowG_Coherence_Angle_Pre = [WT_Ripple_LowG_Coherence_Angle_Pre;Mean_Gamma_Coherence_Per_SWR_2to1]; 
      clearvars -except D k WT*
       cd ..
       cd ./RipplesPostExp
       
       load('LowGamma_Coherence_During SWRs.mat')
       WT_Ripple_LowG_Coherence_Angle_Post = [WT_Ripple_LowG_Coherence_Angle_Post;Mean_Gamma_Coherence_Per_SWR_2to1]; 
       clearvars -except D k WT*
       cd ..
       cd ..
       
    
     clearvars -except D k WT*
     cd .. 
end


%% Plot Polar Histograms
figure
%polarhistogram('BinEdges',deg2rad(0:10:360),'BinCounts',WT_Mobility_Distributions, 'Normalization', 'Probability','FaceColor','k')
polarhistogram(WT_Ripple_LowG_Coherence_Angle_Pre,36, 'Normalization', 'Probability','FaceColor','k')
hold on
polarhistogram(KO_Ripple_LowG_Coherence_Angle_Pre,36, 'Normalization', 'Probability', 'FaceColor',[0.4940, 0.1840, 0.5560])
set(gca,'FontSize',14);
set(gca,'FontWeight','bold');
rlim([0 .08])

figure
%polarhistogram('BinEdges',deg2rad(0:10:360),'BinCounts',WT_Mobility_Distributions, 'Normalization', 'Probability','FaceColor','k')
polarhistogram(WT_Ripple_LowG_Coherence_Angle_Post,36, 'Normalization', 'Probability','FaceColor','k')

hold on
polarhistogram(KO_Ripple_LowG_Coherence_Angle_Post,36, 'Normalization', 'Probability', 'FaceColor',[0.4940, 0.1840, 0.5560])
set(gca,'FontSize',14);
set(gca,'FontWeight','bold');
rlim([0 .08])


%% 
%Run raleigh test 
p_alpha1 = circ_rtest(WT_Ripple_LowG_Coherence_Angle_Pre);
p_alpha2 = circ_rtest(WT_Ripple_LowG_Coherence_Angle_Post);
p_alpha3 = circ_rtest(KO_Ripple_LowG_Coherence_Angle_Pre);
p_alpha4 = circ_rtest(KO_Ripple_LowG_Coherence_Angle_Post);

pvals = sort([p_alpha1 p_alpha2 p_alpha3 p_alpha4],'descend')

[corrected_p, h]=bonf_holm(pvals)

%% Kuiper test
[pval1, k, K] = circ_kuipertest(WT_Ripple_LowG_Coherence_Angle_Pre,WT_Ripple_LowG_Coherence_Angle_Post)
[pval2, k, K] = circ_kuipertest(KO_Ripple_LowG_Coherence_Angle_Pre,KO_Ripple_LowG_Coherence_Angle_Post)
[pval3, k, K] = circ_kuipertest(WT_Ripple_LowG_Coherence_Angle_Pre,KO_Ripple_LowG_Coherence_Angle_Pre)
[pval4, k, K] = circ_kuipertest(WT_Ripple_LowG_Coherence_Angle_Post,KO_Ripple_LowG_Coherence_Angle_Post)


pvals = sort([pval1 pval2 pval3 pval4],'descend')
[corrected_p, h]=bonf_holm(pvals)


