function KRSA_LOAD_CLUSTERED_SPIKE_DATA
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This program loads the clustered data files from the xclust2 program.
% 
% Tetrodes_To_Load is the list of tetrodes to load (eg, 1:40). Location is
% a string that defines the subfolders that hold the clustered data.
% 
% This function assumes the clustered spikes are named cl-X-Y, where X is
% the clustering division and Y is the cell ID number.  For example,
% cl-001-4 would be cell 4 from cluster division 001.  
% 
% 
% The following section creates a complete list of the files that Xclust
% created.  It loads the clustered spikes into one giant array named
% "Spike_Data" with the following structure:
%      1           2
% |        |               |
% |  Time  |  Cell Number  |
%
% The cells are not in any particular order with respect to location on the
% track -- they will be re-arranged later in the analysis program.  The
% spikes are all in chronological order.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

clear all;
Tetrodes_To_Load=[2,3,6,7];
Location=sprintf('Converted/');

Cell_Number=0;
Tetrode_Cell_IDs=[0,0];
clear Spike_Data;
clear Cluster_Width;
for Tetrode=1:length(Tetrodes_To_Load)
    Current_Tetrode=Tetrodes_To_Load(Tetrode);
    Tetrode_String=sprintf('tt%d',Current_Tetrode);
    for Putative_Cell=1:100  %This assumes a maximum of 100 possible cells identified per tetrode -- this should be more than enough
        Directory_String=sprintf('%s%s/*cl-%d',Location,Tetrode_String,Putative_Cell);
        Directory_List=dir(Directory_String);
        if ~isempty(Directory_List)
            Cell_Number=Cell_Number+1;
            Tetrode_Cell_IDs(end+1,:)=[Tetrodes_To_Load(Tetrode),Cell_Number];
            for File=1:length(Directory_List)
                Filename=sprintf('%s%s/%s',Location,Tetrode_String,Directory_List(File).name);
                Loaded_Spike_Data=load(char(Filename));
                clear Temporary_Spike_Data;
                if ~isempty(Loaded_Spike_Data)
                    clear Temporary_Spike_Data;
                    clear Temporary_Run_Spike_Data;
                    clear Temporary_Sleep_Spike_Data;
                    clear Temporary_Run_Cluster_Width;
                    Temporary_Spike_Data=zeros(size(Loaded_Spike_Data,1),3);
                    Temporary_Spike_Data(:,1)=Loaded_Spike_Data(:,8); %This is the timestamp of each spike
                    Temporary_Spike_Data(:,2)=Cell_Number;            %This is the cell number of each spike
                    %Temporary_Spike_Data(:,3)=Current_Tetrode;        %This is the tetrode of each spike
                    %Temporary_Spike_Data(:,4)=Loaded_Spike_Data(:,1); %This is the spike ID of each spike
                    Temporary_Spike_Data(:,3)=Loaded_Spike_Data(:,6); %This is the max width of each spike

                    if exist('Spike_Data','var')
                        Spike_Data=[Spike_Data;Temporary_Spike_Data];
                    else
                        Spike_Data=Temporary_Spike_Data;
                    end

                end
                clear Loaded_Spike_Data;
                clear Filelist;
            end
            fprintf('--Loaded spikes from cell %d on tetrode %d from %d sections.\n',Cell_Number,Current_Tetrode,length(Directory_List));
            clear File;
        end
        clear Directory_List;
        clear Directory_String;
    end
    fprintf('Finished loading Tetrode %d of %d.\n',Current_Tetrode,Tetrodes_To_Load(end));
end
Tetrode_Cell_IDs=Tetrode_Cell_IDs(2:end,:);
Spike_Data=sortrows(Spike_Data,1);

% This next bit separates inhibitory neurons from excitatory neurons
if max(Spike_Data(:,2))>1
    Cell_Determination_Matrix=zeros(max(Spike_Data(:,2)),3);
    for Current_Cell=1:max(Spike_Data(:,2))
        Cell_Determination_Matrix(Current_Cell,1)=Current_Cell;
        Cell_Determination_Matrix(Current_Cell,2)=mean(Spike_Data(Spike_Data(:,2)==Current_Cell,3));
        Cell_Determination_Matrix(Current_Cell,3)=sum(Spike_Data(:,2)==Current_Cell);
    end
    Cell_Determination_Matrix=Cell_Determination_Matrix(Cell_Determination_Matrix(:,3)>0,:);
    Cell_Determination_Matrix(:,4)=kmeans(Cell_Determination_Matrix(:,2:3),2);
    if mean(Cell_Determination_Matrix(Cell_Determination_Matrix(:,4)==1,3))<mean(Cell_Determination_Matrix(Cell_Determination_Matrix(:,4)==2,3))
        Inhibitory_Neurons=Cell_Determination_Matrix(Cell_Determination_Matrix(:,4)==2,1);
        Excitatory_Neurons=Cell_Determination_Matrix(Cell_Determination_Matrix(:,4)==1,1);
    else
        Inhibitory_Neurons=Cell_Determination_Matrix(Cell_Determination_Matrix(:,4)==1,1);
        Excitatory_Neurons=Cell_Determination_Matrix(Cell_Determination_Matrix(:,4)==2,1);
    end
    Spike_Data=Spike_Data(:,1:2);
    if ~isempty(Inhibitory_Neurons)
        for X=1:length(Inhibitory_Neurons)
            if sum(Spike_Data(:,2)==Inhibitory_Neurons(X))/(max(Spike_Data(:,1))-min(Spike_Data(:,1)))<10
                Excitatory_Neurons=[Excitatory_Neurons;Inhibitory_Neurons(X)];
            else
                if exist('Real_Inhibitory_Neurons','var')
                    Real_Inhibitory_Neurons=[Real_Inhibitory_Neurons;Inhibitory_Neurons(X)];
                else
                    Real_Inhibitory_Neurons=Inhibitory_Neurons(X);
                end
            end
        end
        if exist('Real_Inhibitory_Neurons','var')
            Inhibitory_Neurons=Real_Inhibitory_Neurons;
        else
            Inhibitory_Neurons=[];
        end
        Excitatory_Neurons=sortrows(Excitatory_Neurons);
        clear Real_Inhibitory_Neurons;
    end
else
    Excitatory_Neurons=1;
    Inhibitory_Neurons=[];
end
fprintf('Finished loading spikes.  Loaded a total of %d cells (%d excitatory).\n',max(Spike_Data(:,2)),length(Excitatory_Neurons));
save('All_Spike_Data','Spike_Data','Tetrode_Cell_IDs','Inhibitory_Neurons','Excitatory_Neurons');


end