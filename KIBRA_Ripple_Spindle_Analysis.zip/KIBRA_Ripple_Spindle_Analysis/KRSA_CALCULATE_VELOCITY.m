function [Velocity]=KRSA_CALCULATE_VELOCITY(Position_Data)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This program takes the Position_Data input, which is a two-dimensional
% matrix in which each row is a timepoint, the first column is time, the
% second column is the X-position, and the third column is the Y-position.
% 
% The output, Velocity, is the same length as Position_Data, and provides a
% single velocity for every timepoint in Position_Data.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------


% This section calculates various qualities, like velocity, from the
% position data.
Time_Change=diff(Position_Data(:,1));
Time_Change(end+1)=Time_Change(end);
Time_Change(find(Time_Change>(10*median(Time_Change))))=median(Time_Change); %This removes large time jumps (from sleep sessions)
% This filter smooths out the timepoints -- Neuralynx position timepoints
% aren't perfectly at a fixed rate, and I'm not sure if this is because the
% actual data isn't recorded at a fixed rate or if Neuralyx simply doesn't
% put the correct timestamp on the data. Without this smoothing step, the
% resulting velocities show significant artifactual oscillations.
[FilterA,FilterB]=butter(2,0.02);
Time_Change=filtfilt(FilterA,FilterB,Time_Change);
Time_Change(find(Time_Change<=0))=min(Time_Change(find(Time_Change>0)))/10;
X_Movement=diff(Position_Data(:,2));
X_Movement(end+1)=X_Movement(end);
Y_Movement=diff(Position_Data(:,3));
Y_Movement(end+1)=Y_Movement(end);
Distance_Moved=sqrt((X_Movement.^2)+(Y_Movement.^2));
Velocity=abs(Distance_Moved./Time_Change);
Velocity(find(Velocity<0))=0;
clear FilterA;
clear FilterB;
clear Distance Moved;
clear Time_Change;

end

