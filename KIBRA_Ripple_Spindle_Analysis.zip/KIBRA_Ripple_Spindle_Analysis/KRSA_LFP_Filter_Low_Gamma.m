
function LFP_ANALYSIS_LOW_GAMMA(Start_Time,End_Time,Load_Label,Save_Label,Load_Directory,Save_Directory)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This program loads the LFP data saved by the LOAD_RAW_LFP_DATA function.
% It then filters this raw LFP trace in the ripple band and saves that
% information for every electrode in the directory.
% 
% Low_Gamma_Data
% 
% |   1  |          2         |          3         |     4     |  5
% | Time | Low-Gamma-Filtered |      Low-Gamma     | Low-Gamma |  Z-Scored Low-Gamma
% |      |        Trace       |      Amplitude     |   Phase   |  Amplitude 
% 
% Start_Time and End_Time are the timepoints (in seconds) that you want the
% function to analyze.  If these are left empty or are given the value
% 'start' and 'end', respectively, the function will load the entire
% experimental dataset from the file defined by Save_Label.
% 
% Load_Label is a string that is attached to the beginning of the filename
% for the previously saved LFP Data (the data to be loaded prior to
% analysis).  Save_Label is a string that is attached to the beginning of
% the filename for the current date prior to saving it.
% 
% Load_Directory is a string that defines the drive location of the raw
% Neuralynx.ncs files, such as 'G:\Experiments\_Data\Rat1'. Save_Directory
% is a string that defines the drive location where the user wants the
% MatLab files saved.  If these values arent entered, the load and save
% directory is assumed to be the current directory.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------


% If the user did not fully define the input variables, the most likely
% values are either searched for or automatically provided.
if nargin<5,
    Load_Directory=pwd;
    Save_Directory=pwd;
elseif nargin<6,
    Save_Directory=pwd;
end

cd(Load_Directory)

if exist('Load_Label','var'),
    Load_Label=sprintf('%sCSC',Load_Label);
else
    Load_Label='CSC';
end

if exist('Save_Label','var')
    Save_Label=sprintf('%sLowGamma_CSC',Save_Label);
else
    Save_Label='LowGamma_CSC';
end

% This identifies the list of electrodes in the load directory that will be analyzed
Directory_List=dir;
for N=1:size(Directory_List,1),
    for M=1:160,
        Comparison_String=sprintf('%s%d.mat',Load_Label,M);
        if strcmp(Directory_List(N).name,Comparison_String),
            if exist('LFP_Electrodes','var'),
                LFP_Electrodes=[LFP_Electrodes,M];
            else
                LFP_Electrodes=M;
            end
        end
        clear Comparison_String;
    end
end
clear Directory_List;
clear N;
clear M;
LFP_Electrodes=unique(LFP_Electrodes);
LFP_Filename=sprintf('%s%d',Load_Label,LFP_Electrodes(1));
load(LFP_Filename,'LFP_Frequency');
clear LFP_Filename;

% This defines the Start_Time and End_Time arguments if the user did not
% define them already
Load_String=sprintf('%s%d',Load_Label,LFP_Electrodes(1));
load(Load_String,Load_String);
eval(sprintf('LFP_Data=%s;',Load_String));
eval(sprintf('clear %s;',Load_String));
clear Load_String;
if ~exist('Start_Time','var') || strcmp(Start_Time,'start'),
    Start_Time=min(LFP_Data(find(LFP_Data(:,1)>0),1));
end
if ~exist('End_Time','var') || strcmp(End_Time,'end'),
    End_Time=max(LFP_Data(find(LFP_Data(:,1)>0),1));
end
clear LFP_Data;
Start_Time=Start_Time(:);
End_Time=End_Time(:);
if length(Start_Time)~=length(End_Time),
    error('ERROR! The number of start and end times must be the same.')
end
for N=1:length(Start_Time),
    if End_Time(N)-Start_Time(N)<=0,
        error('ERROR! At least one defined time window to extract the LFP data is a negative value.')
    end
end


% The following values are used to build the bandpass filter for low gamma detection
Low_Gamma_Stop_Low=20;               
Low_Gamma_Pass_Low=25;                % 25 Hz as the low cutoff
Low_Gamma_Pass_High=50;               % 50 Hz as the high cutoff
Low_Gamma_Stop_High=55;              
Stop_Band_Attenuation_One=60;         % This was the default, I think.  
Pass_Band=1;                          % This was the default, I think.
Stop_Band_Attenuation_Two=80;         % This was the default, I think.
Filter_Design_For_Low_Gamma=fdesign.bandpass(Low_Gamma_Stop_Low, Low_Gamma_Pass_Low, Low_Gamma_Pass_High, Low_Gamma_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Low_Gamma_Filter=design(Filter_Design_For_Low_Gamma,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

% This begins the actual low gamma filtering function
for N=1:length(LFP_Electrodes),
    if exist(sprintf('%s%d.mat',Save_Label,LFP_Electrodes(N)),'file'),
        disp(sprintf('Skipping analysis of electrode %d (%d of %d).  There was already a file saved with the name %s%d.mat.',LFP_Electrodes(N),N,length(LFP_Electrodes),Save_Label,LFP_Electrodes(N)));
        continue  % This skips the current electrode if the program finds something already saved with the current save name.
    end
    Load_String=sprintf('%s%d',Load_Label,LFP_Electrodes(N));
    load(Load_String,Load_String);
    eval(sprintf('LFP_Data=%s;',Load_String));
    eval(sprintf('clear %s;',Load_String));
    clear Load_String;
    for L=1:length(Start_Time),
        if exist('Final_LFP_Data','var')
            Final_LFP_Data=[Final_LFP_Data;LFP_Data(find(LFP_Data(:,1)>=Start_Time(L) & LFP_Data(:,1)<=End_Time(L)),:)];
        else
            Final_LFP_Data=LFP_Data(find(LFP_Data(:,1)>=Start_Time(L) & LFP_Data(:,1)<=End_Time(L)),:);
        end
    end
    LFP_Data=Final_LFP_Data;
    clear Final_LFP_Data;
    LowGamma_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
    LowGamma_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
    LowGamma_Filtered_LFP_Data(:,2)=filter(Low_Gamma_Filter,LFP_Data(:,2));
    clear LFP_Data;
    LowGamma_Filtered_LFP_Data(:,2)=LowGamma_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
    LowGamma_Filtered_LFP_Data(:,2)=filter(Low_Gamma_Filter,LowGamma_Filtered_LFP_Data(:,2));
    LowGamma_Filtered_LFP_Data(:,2)=LowGamma_Filtered_LFP_Data(end:-1:1,2);
    for M=1:2000000:size(LowGamma_Filtered_LFP_Data,1),  % The program crashes if much more than about 2000000 samples are transformed at once
        LowGamma_Filtered_LFP_Data(M:min([size(LowGamma_Filtered_LFP_Data,1),M+2000000]),3)=hilbert(LowGamma_Filtered_LFP_Data(M:min([size(LowGamma_Filtered_LFP_Data,1),M+2000000]),2));
    end
    LowGamma_Filtered_LFP_Data(:,4)=(angle(LowGamma_Filtered_LFP_Data(:,3))*180/pi)+180;
    LowGamma_Filtered_LFP_Data(:,3)=abs(LowGamma_Filtered_LFP_Data(:,3));
    % The following gaussian filter has a sigma of 85 ms
    LowGamma_Gaussian_Filter=fspecial('gaussian',[round(7*(85/((1/LFP_Frequency)*1000))),1],round(85/((1/LFP_Frequency)*1000)));
    LowGamma_Filtered_LFP_Data(:,3)=filtfilt(LowGamma_Gaussian_Filter,1,LowGamma_Filtered_LFP_Data(:,3));
    clear LowGamma_Gaussian_Filter;
    % The following z-scores the filtered trace
    LowGamma_Filtered_LFP_Data(:,5)=zscore(LowGamma_Filtered_LFP_Data(:,3));
    eval(sprintf('%s%d=LowGamma_Filtered_LFP_Data;',Save_Label,LFP_Electrodes(N)));
    clear LowGamma_Filtered_LFP_Data;
    cd(Save_Directory)
    eval(sprintf('save(''%s%d'',''%s%d'');',Save_Label,LFP_Electrodes(N),Save_Label,LFP_Electrodes(N)));
    cd(Load_Directory)
    eval(sprintf('clear %sCSC%d;',Save_Label,LFP_Electrodes(N)));
    disp(sprintf('Finished low gamma frequency processing for electrode %d (%d of %d).',LFP_Electrodes(N),N,length(LFP_Electrodes)))
end

end