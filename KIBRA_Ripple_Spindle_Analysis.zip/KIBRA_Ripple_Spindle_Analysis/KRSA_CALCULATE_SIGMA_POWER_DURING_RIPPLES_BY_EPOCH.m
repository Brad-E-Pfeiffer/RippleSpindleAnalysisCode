function KRSA_CALCULATE_SIGMA_POWER_DURING_RIPPLES_BY_EPOCH(Velocity_Cutoff,Electrode_ID,Ripples,Dirname)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This program calculates the z-scored s-Sigma power during all SWRs.
%
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%Velocity_Cutoff by default should be 3

load TimesSession.mat

Load_Label=sprintf('CSC%d',Electrode_ID);
%This loads the filtered data.
load(Load_Label);
Complete_Sigma_Data = sigmafilt(eval(sprintf('CSC%d',Electrode_ID)),3200);

 if Velocity_Cutoff>0
        LFP_Velocity=[];
        load('Processed_Position_Data_Smoothed','Position_Data')
        Velocity=CALCULATE_VELOCITY(Position_Data);Velocity=Velocity(:);
        %Added 6/8/2020
        Velocity = smoothdata(Velocity);
        template=Complete_Sigma_Data(:,1);ruler=Position_Data(:,1);[outputindex,error]=match(template,ruler,0);
        LFP_Velocity(:,1:2)=[Velocity(outputindex),abs(error)];
        if 0
            for N=1:size(Complete_Sigma_Data,1)
                LFP_Velocity(N,1)=Velocity(find(abs(Position_Data(:,1)-Complete_Sigma_Data(N,1))==min(abs(Position_Data(:,1)-Complete_Sigma_Data(N,1))),1,'first'));
            end
        end
        Sigma_Data=Complete_Sigma_Data( (LFP_Velocity(:,1)<=Velocity_Cutoff & LFP_Velocity(:,2)<0.5),:);
 end
        HCidx1 = find(Sigma_Data(:,1)>=Times(1,1) & Sigma_Data(:,1)<=Times(1,2));
        %HCidx2 = find(Sigma_Data(:,1)>=Times(6,1) & Sigma_Data(:,1)<=Times(6,2));
        Sigma_Data = [Sigma_Data(HCidx1,:)];%;Sigma_Data(HCidx2,:)];
        
        Mean_Sigma_Amplitude = mean(Sigma_Data(:,3)); % changing to column 5 for power env
        STD_Sigma_Amplitude=std(Sigma_Data(:,3));
        
        Complete_Sigma_Data(:,3) = (Complete_Sigma_Data(:,3)-Mean_Sigma_Amplitude)/(STD_Sigma_Amplitude);
         

%clear all;
Bin_Size=0.1;           % The size of each time bin (in seconds)
Start_Time=-0.450;        % The time (in seconds) from the start of each event to start calculating Sigma power
End_Time=0.450;           % The time (in seconds) from the start of each even to stop calculating Sigma power
Time_Bins=Start_Time:Bin_Size:End_Time;


Sigma_Power_Per_SWR=zeros(size(Ripples,1),length(Time_Bins)-1);

Mean_Sigma_Power_Per_SWR=zeros(size(Ripples,1),1);
Peak_Sigma_Power_Per_SWR=zeros(size(Ripples,1),1);


            for Ripple=1:size(Ripples,1)    
                    Ripple_Sigma_Power=Complete_Sigma_Data(find(Complete_Sigma_Data(:,1)>=(Ripples(Ripple,1)+Start_Time) & Complete_Sigma_Data(:,1)<=(Ripples(Ripple,1)+End_Time)),[1,3]);

                    Just_The_Ripple_Sigma_Power=Ripple_Sigma_Power(find(Ripple_Sigma_Power(:,1)>=Ripples(Ripple,1) & Ripple_Sigma_Power(:,1)<=Ripples(Ripple,2)),:);
                    Ripple_Sigma_Power(:,1)=Ripple_Sigma_Power(:,1)-Ripples(Ripple,1);
                    Mean_Sigma_Power_Per_SWR(Ripple,1)=Mean_Sigma_Power_Per_SWR(Ripple,1)+mean(Just_The_Ripple_Sigma_Power(:,2));
                    Peak_Sigma_Power_Per_SWR(Ripple,1)=Peak_Sigma_Power_Per_SWR(Ripple,1)+max(Just_The_Ripple_Sigma_Power(:,2));

                  for Current_Bin=1:(length(Time_Bins)-1)
                        Sigma_Power_Per_SWR(Ripple,Current_Bin)=Sigma_Power_Per_SWR(Ripple,Current_Bin)+mean(Ripple_Sigma_Power(find(Ripple_Sigma_Power(:,1)>=Time_Bins(Current_Bin) & Ripple_Sigma_Power(:,1)<=Time_Bins(Current_Bin+1)),2));                     
                  end
             end
               
    if ~exist(sprintf('./Power_Data/Sigma_Power_Ripples_New_%s',Dirname),'dir')
        mkdir(sprintf('./Power_Data/Sigma_Power_Ripples_New_%s',Dirname))
    end
    cd(sprintf('./Power_Data/Sigma_Power_Ripples_New_%s',Dirname))
%cd(Dir);

save('New_Sigma_Power_Per_SWR','Sigma_Power_Per_SWR','Mean_Sigma_Power_Per_SWR','Peak_Sigma_Power_Per_SWR');
clearvars -except  D
cd ..
cd ..
end