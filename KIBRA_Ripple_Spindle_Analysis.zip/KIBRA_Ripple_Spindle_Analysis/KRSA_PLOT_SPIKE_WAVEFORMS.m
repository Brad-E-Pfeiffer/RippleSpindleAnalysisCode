function KRSA_PLOT_SPIKE_WAVEFORMS

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This program pulls up all of the clusters for this session and calculates
% plots spike waveforms
%
% Inputs:
%  Clustered Spike Data
%  Times - n x 2 matrix [start end] of each session 
%  Tetrodes_To_Examine - vector with tetrode numbers of interest
%  
% Outputs: 
%  Plots of Spike Waveforms
% 
% Volk & Pfeiffer Lab 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

clear all;
load Times;
Cluster_Directory='D:\ClusteringData\KO\KcSep19-1\Converted';   %This is the full name of the directory in which the xclust2 cluster files are located
Raw_Directory='D:\ClusteringData\KO\KcSep19-1';                 %This is the full name of the directory where the raw Neuralynx spike data (the *.ntt files) are located
Number_Of_Cluster_Divisions=3;                                  %If you clustered the entire session as one, this number would be 1; if you clustered pre-sleep, run, and post-sleep as three separate pieces, this number would be 3
Cluster_Name='*cl-*';

%L_Ratios
%|    1    |           2           |             3           |            4            |
%| L_Ratio | Total Spikes In Noise | Total Spikes In Cluster | Total Spikes On Tetrode |

load Tetrodes_To_Examine;
Current_Directory=pwd;
mkdir('SpikeWaveformFigures');

for Current_Tetrode=Tetrodes_To_Examine
    cd(Cluster_Directory);
    if eval(sprintf('exist(''tt%d'',''dir'')',Current_Tetrode))==7
        eval(sprintf('cd(''tt%d'');',Current_Tetrode));
        Directory_List=dir(Cluster_Name);        %This finds all files with "cl-" in the file name.  If you named your clusters something else, change this accordingly
        if ~isempty(Directory_List)
            cd(Raw_Directory);
            eval(sprintf('[Spike_Waves]=(Nlx2MatSpike(''TT%d.ntt'',[0 0 0 0 1],0,1));',Current_Tetrode));
            cd(Cluster_Directory);
            eval(sprintf('cd(''tt%d'');',Current_Tetrode));
            Number_Of_Clusters=length(Directory_List)/Number_Of_Cluster_Divisions;
            if Number_Of_Clusters~=round(Number_Of_Clusters)
                error('Number of actual clusters is not compatible with number of cluster divisions.')
            end
            for Current_Cluster=1:Number_Of_Clusters
                clear Loaded_Spike_Data;
                for Current_Cluster_Division=1:Number_Of_Cluster_Divisions
                    Temp_Loaded_Spike_Data=load(Directory_List(Current_Cluster+((Current_Cluster_Division-1)*Number_Of_Clusters)).name);
                    if ~isempty(Temp_Loaded_Spike_Data)
                        if exist('Loaded_Spike_Data','var')
                            Loaded_Spike_Data=[Loaded_Spike_Data;Temp_Loaded_Spike_Data(:,[1:5,8])];
                        else
                            Loaded_Spike_Data=Temp_Loaded_Spike_Data(:,[1:5,8]);
                        end
                        clear Temp_Loaded_Spike_Data;
                    end
                end
                Loaded_Spike_Data=Loaded_Spike_Data(Loaded_Spike_Data(:,6)>=Times(3,1) & Loaded_Spike_Data(:,6)<=Times(3,2),:); %Restrict the data to only during the behavior portion to keep the image a little cleaner
                Cluster_Waves=Spike_Waves(:,:,Loaded_Spike_Data(:,1));
                cd(Current_Directory)
                cd SpikeWaveformFigures
                Min_Max=[0,0];
                for Wire=1:4
                    figure;
                    hold on;
                    subplot('Position',[0 0 1 1]);
                    hold on;
                    for N=1:size(Cluster_Waves,3)
                        plot(Cluster_Waves(:,Wire,N),'k');
                    end
                    plot(mean(Cluster_Waves(:,Wire,:),3,'omitnan'),'r','LineWidth',3);
                    Y_Lim=ylim;
                    if Y_Lim(1)<Min_Max(1,1)
                        Min_Max(1,1)=Y_Lim(1);
                    end
                    if Y_Lim(2)>Min_Max(1,2)
                        Min_Max(1,2)=Y_Lim(2);
                    end
                    set(gca,'XTick',[]);
                    set(gca,'YTick',[]);
                    set(gca,'XLim',[1 32]);
                    eval(sprintf('print(''-djpeg'',''Tetrode_%d_Cluster_%d_Electrode_%d_(Y=%dto%d).jpg'');',Current_Tetrode,Current_Cluster,Wire,Y_Lim(1),Y_Lim(2)));
                    close
                end
                for Wire=1:4
                    figure;
                    hold on;
                    subplot('Position',[0 0 1 1]);
                    hold on;
                    for N=1:size(Cluster_Waves,3)
                        plot(Cluster_Waves(:,Wire,N),'k');
                    end
                    plot(mean(Cluster_Waves(:,Wire,:),3,'omitnan'),'r','LineWidth',3);
                    set(gca,'XTick',[]);
                    set(gca,'YTick',[]);
                    set(gca,'XLim',[1 32]);
                    set(gca,'YLim',[Min_Max(1) Min_Max(2)]);
                    eval(sprintf('print(''-djpeg'',''Scaled_Tetrode_%d_Cluster_%d_Electrode_%d_(Y=%dto%d).jpg'');',Current_Tetrode,Current_Cluster,Wire,Min_Max(1),Min_Max(2)));
                    close
                end
                clear Cluster_Waves;
                cd(Cluster_Directory)
                eval(sprintf('cd(''tt%d'');',Current_Tetrode));
            end
            clear Current_Cluster;
            clear Spike_Waves;
        end
        clear Directory_List
    end
end
cd(Current_Directory)
        
        
end
