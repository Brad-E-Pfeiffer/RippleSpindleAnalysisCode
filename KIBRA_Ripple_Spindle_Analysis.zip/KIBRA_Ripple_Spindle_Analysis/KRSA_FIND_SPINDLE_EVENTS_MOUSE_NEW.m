function [Spindle_Events,Spindle_Power,Spindle_Freq,RMS_thresh_min,RMS_thresh_max]=KRSA_FIND_SPINDLE_EVENTS_MOUSE_NEW(Electrode_ID,Velocity_Cutoff,Sleep)
%PURPOSE:  This function identifies peaks in the processed sigma power to   
% detect spindle events. It finds the mean cubed RMS sigma power of the selected
% electrode and any time the power is greater than the mean
%times the Minimum_Peak_Height_Multiplier, the event is
% considered to be a candidate Spindle event.
% 
% The program looks for Spindles using a range of
% Minimum_Peak_Height_Multipliers.
% Electrode_ID is the number of the CSC channel that you want to analyze.
% For example, entering 12 would analyze Spindle_CSC12.mat.   
%Minimum_Peak_Height_Multiplier=1.2;
%INPUT: 
%       Velocity_Cutoff = cutoff value for calculating mean
%       Sleep - nx3 file containing sleep periods start,end,duration
%       Electrode_ID - Electrode used for calculation of periods

% OUTPUT: 

%Authors/origin creds
% LD Quigley
% 03/2022
% Volk & Pfeiffer Lab
%Methods adapted from Uygun Sleep, 2020
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------


Maximum_Spindle_Time_Length=10;       %The maximum time (in seconds) that a Spindle can last for and still be considered a real Spindle
Minimum_Spindle_Time_Length=0.5;    %The minimum time (in seconds) that a Spindle must last for to be counted as a real Spindle
Minimum_Peak_Separation=0.05;        %The minimum time (in seconds) that two Spindles have to be apart to be counted as separate Spindles -- otherwise they are concatenated as one Spindle
Load_Label=sprintf('CSC%d',Electrode_ID);

%This loads the Electrode data.
load(Load_Label);
eval(sprintf('Data=%s;',Load_Label));
eval(sprintf('clear %s;',Load_Label));

if ~exist('Velocity_Cutoff','var')
    Velocity_Cutoff=0;
end


%This loads the Times variable that lists the various experimental time epochs
load TimesSession

Complete_Sigma_Data = Filter_Sigma_Spindle(Data,3200);

%Next will remove timepoints with saturated signal from the filtered data

LFP1_Name=sprintf('CSC%d.ncs',Electrode_ID);
LFP1_Frequency=Nlx2MatCSC(LFP1_Name,[0 0 1 0 0],0,3,1);
LFP_Frequency=LFP1_Frequency;
clear LFP1_Frequency;

LFP1_Samples=Nlx2MatCSC(LFP1_Name,[0 0 0 0 1],0,1);
LFP1_Samples=LFP1_Samples(:);
%LFP_Samples=LFP_Samples(:)*(Max_Range/Max_Value);

%If the recording frequency and total sample number are the same, the program assumes the timepoint of each sample is the same, so it only loads the timestamps of the first electrode and uses that for both 
LFP_Times=Nlx2MatCSC(LFP1_Name,[1 0 0 0 0],0,1)/1000000;
Times=zeros(512,size(LFP_Times,2));
for B=1:length(LFP_Times)-1
    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';   
end
 clear B;   
Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
LFP_Times=Times(:);
clear Times;

LFP1_Header=Nlx2MatCSC(LFP1_Name,[0 0 0 0 0],1,1,0);
for Header_Line=1:length(LFP1_Header)
    Header_Info=cell2mat(LFP1_Header(Header_Line));
    if length(Header_Info)>12
        if strcmp(Header_Info(1:11),'-ADMaxValue')
            LFP1_Max_Value=str2num(Header_Info(13:end));
        end
        if strcmp(Header_Info(1:11),'-InputRange')
            LFP1_Max_Range=str2num(Header_Info(13:end));
        end
    end
end

%This identifies segments of the recording where either the signal or the reference electrode is clipped (above or below the maximum recording value) 
%These segments aren't removed yet because it would interfere with the filtering to append two distant segments, so these are removed after filtering 
Timepoints_To_Remove=LFP_Times(LFP1_Samples==LFP1_Max_Value | LFP1_Samples==(-LFP1_Max_Value)); %| LFP2_Samples==LFP2_Max_Value | LFP2_Samples==(-LFP2_Max_Value));
Timepoints_To_Remove=[Timepoints_To_Remove-1,Timepoints_To_Remove+1];
Timepoints_To_Remove(:,3)=1;
for N=1:(size(Timepoints_To_Remove,1)-1)
    if Timepoints_To_Remove((N+1),1)<=Timepoints_To_Remove(N,2)
        Timepoints_To_Remove(N,3)=0;
        Timepoints_To_Remove((N+1),1)=Timepoints_To_Remove(N,1);
    end
end
Timepoints_To_Remove=Timepoints_To_Remove(Timepoints_To_Remove(:,3)==1,1:2);

for N=1:size(Timepoints_To_Remove,1)
    Complete_Sigma_Data=Complete_Sigma_Data(Complete_Sigma_Data(:,1)<Timepoints_To_Remove(N,1) | Complete_Sigma_Data(:,1)>Timepoints_To_Remove(N,2),:);      
end

%This loads the Times variable that lists the various experimental time epochs
load TimesSession

%This section was added to calculate the mean Sigma amplitude  for all
%Epochs, when the mouse was moving less than Velocity_Cutoff
 %This applies the velocity cutoff so that only Sigma data when the rat is moving below a certain threshold is analyzed.
    if Velocity_Cutoff>0
        LFP_Velocity=[];
        load('Processed_Position_Data_Smoothed','Position_Data')
        Velocity=CALCULATE_VELOCITY(Position_Data);Velocity=Velocity(:);
        %Added 6/8/2020
        Velocity = smoothdata(Velocity);
        template=Complete_Sigma_Data(:,1);ruler=Position_Data(:,1);[outputindex,error]=match(template,ruler,0);
        LFP_Velocity(:,1:2)=[Velocity(outputindex),abs(error)];
        if 0,
            for N=1:size(Complete_Sigma_Data,1)
                LFP_Velocity(N,1)=Velocity(find(abs(Position_Data(:,1)-Complete_Sigma_Data(N,1))==min(abs(Position_Data(:,1)-Complete_Sigma_Data(N,1))),1,'first'));
            end
        end
        Sigma_Data=Complete_Sigma_Data( (LFP_Velocity(:,1)<=Velocity_Cutoff & LFP_Velocity(:,2)<0.5),:);
    end
    

 %Find mean and standard deviation of Sigma amplitude during baseline period  
        %Sigma_Data = [Sigma_Data((Sigma_Data(:,1)>=Times(1,1) & Sigma_Data(:,1)<=Times(1,2)),:); Sigma_Data((Sigma_Data(:,1)>=Times(6,1) & Sigma_Data(:,1)<=Times(6,2)),:)];
        Sigma_Data1 = Sigma_Data((Sigma_Data(:,1)>=Times(1,1) & Sigma_Data(:,1)<=Times(1,2)),:);
        Sigma_Data2 = Sigma_Data((Sigma_Data(:,1)>=Times(6,1) & Sigma_Data(:,1)<=Times(6,2)),:);
        
        Sigma_Subset = [Sigma_Data1];%;Sigma_Data2];
        Mean_Sigma_RMS = mean(Sigma_Subset(:,3)); % 
        STD_Sigma_RMS=std(Sigma_Subset(:,3));
        
        Sigma_Subset = [Sigma_Data1];
        Mean_Sigma_Amplitude = mean(Sigma_Subset(:,5)); % 
        STD_Sigma_Amplitude=std(Sigma_Subset(:,5));
        Complete_Sigma_Data(:,6) = (Complete_Sigma_Data(:,5)-Mean_Sigma_Amplitude)/(STD_Sigma_Amplitude);
        %Sigma_Data(:,6) = (Sigma_Data(:,5)-Mean_Sigma_Amplitude)/(STD_Sigma_Amplitude);
       
        %find column 6 when times in Complete Sigma data match
        %
        %Mean_Sigma_Amplitude = mean(Sigma_Data(:,6)); % 
        %STD_Sigma_Amplitude=std(Sigma_Data(:,6));
        
        
         clear Sigma_Data;
        clear LFP_Velocity;
        clear template;
    %RMS_cubed=Complete_Sigma_Data(:,3);
    RMS_thresh_min = 1.2*Mean_Sigma_RMS; 
    RMS_thresh_max = 3.5*Mean_Sigma_RMS; 
for Epoch=1:size(Sleep,1)
    %This restricts the analyis to the current epoch only
    Spindle_Data=Complete_Sigma_Data((Complete_Sigma_Data(:,1)>=Sleep(Epoch,1) & Complete_Sigma_Data(:,1)<=Sleep(Epoch,2)),:);
% This next section finds all of the peaks in the Spindle amplitude data.
    %
    % Spindle_Events
    % |     1      |    2     |         3        |
    % | Start Time | End Time | Center Peak Time |
    %
    %
    % Spindle_Power(Sigma Power)
    % |        1          |          2           |
    % | Mean Spindle Power | Maximum Spindle Power |
    

    % Next, it finds peaks in the RMS amplitude greater than a threshold of
    % 1.2*mean cubed RMS
    % this analysis.  It defines the start and stop of each event as when the
    % amplitude crosses back below the mean.  
    %Once it's found all of the
    % events, it combines events in which the peaks are less than X sec from
    % one another (X is defined at the start of this function as the
    % "Minimum_Peak_Distance").
    %for Minimum_Peak_Height_Multiplier=2:7,
    %if max(Spindle_Data(:,3))>=Mean_Spindle_Amplitude+(STD_Spindle_Amplitude*Minimum_Peak_Height_Multiplier),
    %% Create envelope from the peaks of rectified signal (peaks found using zero-crossing of the derivative)
    datader = diff(Spindle_Data(:,3)); % x(2)-x(1), x(3)-x(2), ... + at increase, - at decrease
    posder = zeros(length(datader),1);
    posder(datader>0) = 1; % index of all points at which the rectified signal is increasing in amplitude
    diffder = diff(posder); % -1 going from increase to decrease, 1 going from decrease to increase, 0 no change
    envelope_peaks = find(diffder==-1)+1; % peak index of rectified signal
    
    %% Finds peaks of the envelope
    envelope_peaks_amp = Spindle_Data(envelope_peaks,3); % peak amplitude of Envelope signal
    
    %% Finds troughs of the envelope
    envelope_troughs = find(diffder==1)+1; % trough index of Envelope signal
    envelope_troughs_amp = Spindle_Data(envelope_troughs,3); % peak trough of Envelope signal
    
    %% Find where peaks are higher/lower than threshold
    below_troughs = envelope_troughs(envelope_troughs_amp<RMS_thresh_min); % lower threshold corresponding to 4* the power of the most numerous bin
    %above_peaks=envelope_peaks(envelope_peaks_amp>RMS_thresh_max & sleepsamp(envelope_peaks)<=-2); % Use this line insted of no. 60 if spindles should only be detected in S2+S3+S4
    above_peaks = envelope_peaks(envelope_peaks_amp>RMS_thresh_max);
    
    %% For each of peaks above threshold
    spistart = NaN(length(above_peaks),1); % start of spindle (in 100Hz samples)
    spiend = NaN(length(above_peaks),1); % end of spindle (in 100Hz samples)
    spipeak= NaN(length(above_peaks),1);
    nspi=0; % spindle count
    % for all indexes of peaks (peaks of peaks)
    i = 1;
    while i <= length(above_peaks)
        current_peak = above_peaks(i);
        % find troughs before and after current peak
        trough_before = below_troughs(find(below_troughs > 1 & below_troughs < current_peak,1,'last'));
        trough_after  = below_troughs(find(below_troughs < length(Spindle_Data) & below_troughs > current_peak,1,'first'));
        
        if ~isempty(trough_before) && ~isempty(trough_after)  % only count spindle if it has a start and end
            nspi=nspi+1;
            spistart(nspi)=find(Spindle_Data(1:current_peak,3)<RMS_thresh_min,1,'last');
            spiend(nspi)=find(Spindle_Data(1:trough_after,3)>RMS_thresh_min,1,'last')+1;
            if spistart(nspi)<trough_before||spiend(nspi)>trough_after
                i;
            end
            
            % if there are multiple peaks, pick the highest and skip the rest
            potential_peaks = above_peaks(above_peaks > trough_before & above_peaks < trough_after);
            [~, maxpki]=max(Spindle_Data(potential_peaks,3));
            current_peak=potential_peaks(maxpki); 
            spipeak(nspi)=current_peak;
            i = i+length(potential_peaks); % adjust the index to account for different max
        else
            i = i+1;
        end
    end
    
    spistart = spistart(~isnan(spistart));
    spiend = spiend(~isnan(spiend));
    spipeak = spipeak(~isnan(spipeak));
    
    Spindle_Events = [Spindle_Data(spistart,1) Spindle_Data(spiend,1) Spindle_Data(spipeak,1)];
    
        
        for N=2:size(Spindle_Events,1)
            if Spindle_Events(N,1)-Spindle_Events(N-1,2)<=Minimum_Peak_Separation
                Spindle_Events(N,1)=Spindle_Events(N-1,1);
                Spindle_Events(N-1,1)=0;
            end
        end
        Spindle_Events=Spindle_Events((Spindle_Events(:,1)>0),:);
        Spindle_Events=Spindle_Events(((Spindle_Events(:,2)-Spindle_Events(:,1))>=Minimum_Spindle_Time_Length & (Spindle_Events(:,2)-Spindle_Events(:,1))<=Maximum_Spindle_Time_Length),:);
        
        fs = 3200
           spiHz=[];      
     if ~isempty(Spindle_Events)
    for n = 1:size(Spindle_Events,1)
        a = (Data(find(Data(:,1)>=Spindle_Events(n,1) & Data(:,1)<=Spindle_Events(n,2)),2));
        [PSD(n,:), Freq] = pspectrum(a,fs);
        spiHzMethod='pspectrum';
        spiHzRange=[10 15];
        spiindex = find(Freq>=spiHzRange(1)&Freq<=spiHzRange(2));
        [M,I] = max(PSD(n,spiindex));
        spiHz(n) = Freq(spiindex(1)+I-1);
    end
     end
    %spiHz_State=spiHz(spStatePos);     
        
        % This finds the mean power for each Spindle event
        if size(Spindle_Events,1)>0,
            Spindle_Power=zeros(size(Spindle_Events,1),2);
            for N=1:size(Spindle_Events,1),
                Spindle_Subset_Data=Spindle_Data((Spindle_Data(:,1)>=Spindle_Events(N,1) & Spindle_Data(:,1)<=Spindle_Events(N,2)),[3 5 6]);
                Mean_Power=mean(Spindle_Subset_Data(:,1));
                Max_Power=max(Spindle_Subset_Data(:,1));
                Mean_Power_Env=mean(Spindle_Subset_Data(:,2));
                Max_Power_Env=max(Spindle_Subset_Data(:,2));               
                Mean_Power_Z=mean(Spindle_Subset_Data(:,3));
                Max_Power_Z=max(Spindle_Subset_Data(:,3));
                Spindle_Power(N,1:6)=[Mean_Power,Max_Power,Mean_Power_Env,Max_Power_Env,Mean_Power_Z,Max_Power_Z];
                clear Spindle_Subset_Data;
            end
            eval(sprintf('Spindle_Events_Epoch%d=Spindle_Events;Spindle_Power_Epoch%d=Spindle_Power;Spindle_Freq_Epoch%d=spiHz',Epoch,Epoch,Epoch));
      
        end
     
        
        clear Spindle_Events;
        clear Spindle_Power;
        clear Spindle_Freq
end

Spindle_Events = [];
for k=1:size(Sleep,1);
    if exist(sprintf('Spindle_Events_Epoch%d',k),'var')
 eval(sprintf('Spindle_Events=[Spindle_Events;Spindle_Events_Epoch%d];',k));
    end
end

Spindle_Power = []
for k=1:size(Sleep,1);
    if exist(sprintf('Spindle_Power_Epoch%d',k),'var')
 eval(sprintf('Spindle_Power=[Spindle_Power;Spindle_Power_Epoch%d];',k));
    end
end

Spindle_Freq= []
for k=1:size(Sleep,1);
    if exist(sprintf('Spindle_Freq_Epoch%d',k),'var')
 eval(sprintf('Spindle_Freq=[Spindle_Freq Spindle_Freq_Epoch%d];',k));
    end
end
    save('Spindle_Events','Spindle_Events','Spindle_Power','Complete_Sigma_Data','RMS_thresh_min','RMS_thresh_max','Spindle_Freq');
end

%Sigma Frequency:10-15Hz
%Duration of Spindle: 0.5-10s
%Always proceeds K-complex, which are usually greater than 100 �V, followed by a slower positive complex around 350 and 550 ms and at 900 ms a final negative peak
