function [MeanFreq,PeakFreq] = KRSA_CALCULATE_THETA_FREQUENCY(Epoch_Times,Filtered_LFP_Data)
% %% FUNCTION:
%Quantifies frequency at peak power, mean frequency for filtered data
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% INPUT: 
%  Epoch_Times = n x 3 file containing Start, end and peak times
%  Filtered_LFP_Data


% OUTPUT: 
%  MeanFreq - average frequency of filtered oscillation 
%  PeakFreq - average frequency at peak power
%
% 
% Volk Lab & Pfeiffer Lab

%==========================================================================

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%


Epoch_Times = Epoch_Times(find(Epoch_Times(:,3)>.5),:);
ThetaFreqMean = zeros(size(Epoch_Times,1),1);
ThetaFreqPeak = zeros(size(Epoch_Times,1),1);
for Epoch = 1:size(Epoch_Times,1)
    
    %isolate Theta Data for each epoch 
    Theta_Data=Filtered_LFP_Data((Filtered_LFP_Data(:,1)>=Epoch_Times(Epoch,1) & Filtered_LFP_Data(:,1)<=Epoch_Times(Epoch,2)),:);
    %[~,Locations]=findpeaks(Theta_Data(:,3),'minpeakheight',..));
    
    %Find Peaks in Theta-Filtered signal
    [~,Locations]=findpeaks(Theta_Data(:,2));
    
    %Find the time at each peak in the filtered signal 
    Peaks = Theta_Data(Locations,1);
    
    %Theta_Power(N,1:4)=[Peaks; Peaks(Theta)];
    %timeBetweenPeaks = diff(loc) * 3200; 
    
    %Find Peaks in Power 
    [~,LocationsB]=findpeaks(Theta_Data(:,2));
    Power_Peaks = length(LocationsB);
    
    timeBetweenPeaks = diff(Peaks);
    %Frequency = 1./timeBetweenPeaks;
    
    [M,peakpoweridx] = max(Theta_Data(:,3));
    v = Theta_Data(peakpoweridx,1);
   
    [~,P] = (min(abs(Peaks - v)));%Gives you the index closest to value of interest
    
    if P>1 && P<length(timeBetweenPeaks)
    PeakFreq = 1/((timeBetweenPeaks(P-1)+timeBetweenPeaks(P))/2); % inverse of average of neighboring peaks
  
    elseif P>length(timeBetweenPeaks)
        PeakFreq = 1/timeBetweenPeaks(P-1);
    else
        PeakFreq = 1/timeBetweenPeaks(P);
       
    end
    
    MeanFreq = 1./timeBetweenPeaks;
    MeanFreq = mean(MeanFreq);


ThetaFreqMean(Epoch,1) = MeanFreq;
ThetaFreqPeak(Epoch,1) = PeakFreq;

clearvars PeakFreq MeanFreq


end

% Get an average for all epochs
MeanFreq = mean(ThetaFreqMean);
PeakFreq = mean(ThetaFreqPeak);

clearvars 

end


